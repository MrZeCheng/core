package com.yhglobal.bee.oss.common.configure;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.constant.oss.YhOssBaseI;
import com.yhglobal.bee.oss.common.entity.YhOssObject;
import com.yhglobal.bee.oss.common.properties.YhOssProperties;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.*;

/**
 *
 *
 * @author weizecheng
 */
@Configuration
@EnableConfigurationProperties(YhOssProperties.class)
@ConditionalOnProperty(prefix = "yh.oss", name = "enable",havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
public class YhOssAutoConfigure {

    private final YhOssProperties yhOssProperties;

    @Bean(name = "oss")
    @ConditionalOnMissingBean(name = "oss")
    public OSS oss(){
        if (StringUtils.isBlank(yhOssProperties.getUrl())) {
            throw new RuntimeException("yh.oss.url The parameter is not set!");
        }
        if (StringUtils.isBlank(yhOssProperties.getBucket())) {
            throw new RuntimeException("yh.oss.bucket The parameter is not set!");
        }
        if (StringUtils.isBlank(yhOssProperties.getKeyId())) {
            throw new RuntimeException("yh.oss.key-id The parameter is not set!");
        }
        if (StringUtils.isBlank(yhOssProperties.getKeySecret())) {
            throw new RuntimeException("yh.oss.key-secret The parameter is not set!");
        }
        return new OSSClientBuilder().build(yhOssProperties.getUrl(), yhOssProperties.getKeyId(), yhOssProperties.getKeySecret());
    }

    @Bean
    @ConditionalOnBean(name = "oss")
    public OSSUtil ossUtil(OSS oss) {
        return new OSSUtil(yhOssProperties,oss);
    }

    @Bean
    @ConditionalOnMissingBean(name = "ossMultipleUtil")
    public OSSMultipleUtil ossMultipleUtil() {
        if (yhOssProperties.getConfigs() != null && yhOssProperties.getConfigs().size() > 0) {
            Set<String> set = getOssType();
            if (set.size() > 0) {
                Map<String, YhOssObject> ossObjectMap = new HashMap<>((int)(yhOssProperties.getConfigs().size() / .75f) + 1);
                yhOssProperties.getConfigs().forEach( o ->{
                    if (set.contains(o.getOssType())) {
                        if (StringUtils.isBlank(o.getUrl())) {
                            throw new RuntimeException("yh.oss.url The parameter is not set!");
                        }

                        if (StringUtils.isBlank(o.getBucket())) {
                            throw new RuntimeException("yh.oss.bucket The parameter is not set!");
                        }

                        if (StringUtils.isBlank(o.getKeyId())) {
                            throw new RuntimeException("yh.oss.key-id The parameter is not set!");
                        }

                        if (StringUtils.isBlank(o.getKeySecret())) {
                            throw new RuntimeException("yh.oss.key-secret The parameter is not set!");
                        }

                        YhOssObject yhOssObject = new YhOssObject();
                        yhOssObject.setOssAfterKey(o.getOssAfterKey());
                        yhOssObject.setOssBeforeKey(o.getOssBeforeKey());
                        yhOssObject.setOss(new OSSClientBuilder().build(o.getUrl(), o.getKeyId(), o.getKeySecret()));
                        yhOssObject.setBucket(o.getBucket());
                        ossObjectMap.put(o.getOssType(), yhOssObject);
                    }
                });
                return new OSSMultipleUtil(ossObjectMap);
            }
        }
        return new OSSMultipleUtil(new HashMap<>(1));
    }

    private Set<String> getOssType(){
        // 可以做成配置扫描制定路径配置
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<? extends YhOssBaseI>> set =  reflections.getSubTypesOf(YhOssBaseI.class);
        Set<String> strings = new HashSet<>();
        set.forEach(key ->{
            // 只处理枚举类型
            if (key.isEnum()) {
                YhOssBaseI[] yhOssBase = key.getEnumConstants();
                for (YhOssBaseI i : yhOssBase) {
                    strings.add(i.getOssType());
                }
            }
        });
        return strings;
    }

}
