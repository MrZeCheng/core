package com.yhglobal.bee.oss.common.entity;

import com.aliyun.oss.OSS;

/**
 * 阿里云oss对象
 *
 * @author zecheng.wei
 * @Date 2023/6/6 14:36
 */
public class YhOssObject {

    /**
     * bucket
     */
    private String bucket;

    /**
     * oss对象
     */
    private OSS oss;

    /**
     * url 替换前的key
     */
    private String ossBeforeKey;

    /**
     *  url 替换后的key
     */
    private String ossAfterKey;

    public String getOssBeforeKey() {
        return ossBeforeKey;
    }

    public void setOssBeforeKey(String ossBeforeKey) {
        this.ossBeforeKey = ossBeforeKey;
    }

    public String getOssAfterKey() {
        return ossAfterKey;
    }

    public void setOssAfterKey(String ossAfterKey) {
        this.ossAfterKey = ossAfterKey;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public OSS getOss() {
        return oss;
    }

    public void setOss(OSS oss) {
        this.oss = oss;
    }
}
