package com.yhglobal.bee.oss.common.configure;

import com.aliyun.oss.OSS;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.ObjectMetadata;
import com.aliyun.oss.model.PutObjectRequest;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.bee.common.constant.oss.YhOssBaseI;
import com.yhglobal.bee.oss.common.entity.YhOssObject;
import com.yhglobal.bee.oss.common.properties.YhOssProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
public class OSSMultipleUtil {

    private final Map<String, YhOssObject> ossObjectMap;

    public YhResponse uploadFile(String objectName, byte[] array, YhOssBaseI yhOssBaseI){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            String bucket = oss.getBucket();
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, objectName, new ByteArrayInputStream(array));
            oss.getOss().putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return YhResponse.buildFailure(ErrorCode.UPLOAD_FAILED);
        }
    }

    public InputStream getFileInputStream(String objectName,YhOssBaseI yhOssBaseI){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            String bucket = oss.getBucket();
            OSSObject ossObject = oss.getOss().getObject(bucket,objectName);
            return ossObject.getObjectContent();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            throw new BusinessException(ErrorCode.EXCEL_FAIL);
        }
    }

    /**
     * 上传
     *
     * @author weizecheng
     * @date 2020/11/10 16:46
     */
    public  YhResponse uploadFile(String objectName, InputStream in,YhOssBaseI yhOssBaseI){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            String bucket = oss.getBucket();
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, objectName,in);
            oss.getOss().putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 上传
     *
     * @author weizecheng
     * @date 2020/11/10 16:46
     */
    public  YhResponse uploadFile(String objectName,String fileName,YhOssBaseI yhOssBaseI){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            String bucket = oss.getBucket();
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucket, objectName,new File(fileName));
            oss.getOss().putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 获取访问路径
     * 默认授权时间为1小时
     *
     * 3600 * 1000
     *
     * @author weizecheng
     * @date 2020/11/11 11:10
     */
    public  SingleResponse<String> getUrlAddress(String objectName,YhOssBaseI yhOssBaseI){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            String bucket = oss.getBucket();
            Date expiration = new Date(System.currentTimeMillis() + 3600 * 1000);
            URL url = oss.getOss().generatePresignedUrl(bucket, objectName, expiration);
            String ossAddress = url.toString();
            if (StringUtils.isNotBlank(oss.getOssBeforeKey()) && StringUtils.isNotBlank(oss.getOssAfterKey())) {
                ossAddress = ossAddress.replace(oss.getOssBeforeKey(), oss.getOssAfterKey());
            }
            return SingleResponse.of(ossAddress);
        }catch (Exception e){
            log.info("getUrlAddress = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 自行设置授权时间
     *
     * @author weizecheng
     * @date 2020/11/11 11:11
     */
    public SingleResponse<String> getUrlAddress(String objectName, long time,YhOssBaseI yhOssBaseI){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            String bucket = oss.getBucket();
            Date expiration = new Date(System.currentTimeMillis() + time);
            URL url = oss.getOss().generatePresignedUrl(bucket, objectName, expiration);
            String ossAddress = url.toString();
            if (StringUtils.isNotBlank(oss.getOssBeforeKey()) && StringUtils.isNotBlank(oss.getOssAfterKey())) {
                ossAddress = ossAddress.replace(oss.getOssBeforeKey(), oss.getOssAfterKey());
            }
            return SingleResponse.of(ossAddress);
        }catch (Exception e){
            log.info("getUrlAddress = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 从OSS上获取文件。bucket取入参，确保API账号拥有访问该bucket的权限
     * @param objectName 文件目录 + 文件名
     * @param yhOssBaseI API账号信息
     * @param bucketName bucket
     * @return
     */
    public InputStream getFileInputStream(String objectName,YhOssBaseI yhOssBaseI, String bucketName){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            OSSObject ossObject = oss.getOss().getObject(bucketName, objectName);
            return ossObject.getObjectContent();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            throw new BusinessException(ErrorCode.DOWNLOAD_EXCEPTION, e.toString());
        }
    }

    /**
     * 上传文件。bucket取入参，确保API账号拥有访问该bucket的权限
     * @param objectName 文件目录 + 文件名
     * @param in 输入流
     * @param yhOssBaseI API账号信息
     * @param bucketName bucket
     * @param forbidOverwrite 禁止覆盖同名文件。默认为false允许覆盖
     * @return
     */
    public  YhResponse uploadFile(String objectName, InputStream in, YhOssBaseI yhOssBaseI, String bucketName, boolean forbidOverwrite){
        try {
            YhOssObject oss = getOss(yhOssBaseI);
            ObjectMetadata objectMetadata = new ObjectMetadata();
            objectMetadata.setHeader("x-oss-forbid-overwrite", forbidOverwrite);
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, objectName, in, objectMetadata);
            oss.getOss().putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_EXCEPTION.getCode(),ErrorCode.UPLOAD_EXCEPTION.getMessage(e.toString()));
        }
    }

    /**
     * 获取oss
     *
     * @author zecheng.wei
     * @Date 2023/6/6 14:50
     */
    private YhOssObject getOss(YhOssBaseI yhOssBaseI){
        YhOssObject oss = ossObjectMap.get(yhOssBaseI.getOssType());
        if (oss == null) {
            throw new RuntimeException(yhOssBaseI.getOssType() + " is not OSS !");
        }
        return oss;
    }

}
