package com.yhglobal.bee.oss.common.entity;

public class YhOssListObject {

    private String ossType;

    private String url;

    private String keyId;

    private String keySecret;

    private String bucket;

    private String ossBeforeKey;

    private String ossAfterKey;

    public String getOssBeforeKey() {
        return ossBeforeKey;
    }

    public void setOssBeforeKey(String ossBeforeKey) {
        this.ossBeforeKey = ossBeforeKey;
    }

    public String getOssAfterKey() {
        return ossAfterKey;
    }

    public void setOssAfterKey(String ossAfterKey) {
        this.ossAfterKey = ossAfterKey;
    }

    public String getOssType() {
        return ossType;
    }

    public void setOssType(String ossType) {
        this.ossType = ossType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getKeyId() {
        return keyId;
    }

    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    public String getKeySecret() {
        return keySecret;
    }

    public void setKeySecret(String keySecret) {
        this.keySecret = keySecret;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    @Override
    public String toString() {
        return "YhOssListObject{" +
                "url='" + url + '\'' +
                ", keyId='" + keyId + '\'' +
                ", keySecret='" + keySecret + '\'' +
                ", bucket='" + bucket + '\'' +
                '}';
    }
}
