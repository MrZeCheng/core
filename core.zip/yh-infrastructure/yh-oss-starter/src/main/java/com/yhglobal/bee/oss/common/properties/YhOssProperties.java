package com.yhglobal.bee.oss.common.properties;

import com.yhglobal.bee.oss.common.entity.YhOssListObject;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

/**
 * Oss配置
 *
 * @author zecheng.wei
 * @Date 2023/6/6 14:23
 */
@ConfigurationProperties(prefix = "yh.oss")
public class YhOssProperties {

    private Boolean enable = true;

    private String url;

    private String keyId;

    private String keySecret;

    private String bucket;

    private String ossBeforeKey;

    private String ossAfterKey;

    private List<YhOssListObject> configs;

    public String getOssBeforeKey() {
        return ossBeforeKey;
    }

    public void setOssBeforeKey(String ossBeforeKey) {
        this.ossBeforeKey = ossBeforeKey;
    }

    public String getOssAfterKey() {
        return ossAfterKey;
    }

    public void setOssAfterKey(String ossAfterKey) {
        this.ossAfterKey = ossAfterKey;
    }

    public List<YhOssListObject> getConfigs() {
        return configs;
    }

    public void setConfigs(List<YhOssListObject> configs) {
        this.configs = configs;
    }

    public Boolean getEnable() {
        return enable;
    }

    public YhOssProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public YhOssProperties setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getKeyId() {
        return keyId;
    }

    public YhOssProperties setKeyId(String keyId) {
        this.keyId = keyId;
        return this;
    }

    public String getKeySecret() {
        return keySecret;
    }

    public YhOssProperties setKeySecret(String keySecret) {
        this.keySecret = keySecret;
        return this;
    }

    public String getBucket() {
        return bucket;
    }

    public YhOssProperties setBucket(String bucket) {
        this.bucket = bucket;
        return this;
    }
}
