package com.yhglobal.bee.oss.common.configure;

import com.aliyun.oss.OSS;
import com.aliyun.oss.model.*;
import com.yhglobal.bee.common.constant.oss.YhOssBaseI;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.bee.oss.common.properties.YhOssProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;

@Slf4j
@RequiredArgsConstructor
public class OSSUtil {

    private final YhOssProperties yhOssProperties;

    private final OSS oss;

    public YhResponse uploadFile(String objectName, byte[] array){
        try {
            PutObjectRequest putObjectRequest = new PutObjectRequest(yhOssProperties.getBucket(), objectName, new ByteArrayInputStream(array));
            oss.putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return YhResponse.buildFailure(ErrorCode.UPLOAD_FAILED);
        }
    }

    public InputStream getFileInputStream(String objectName){
        try {
            OSSObject ossObject = oss.getObject(yhOssProperties.getBucket(),objectName);
            return ossObject.getObjectContent();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            throw new BusinessException(ErrorCode.EXCEL_FAIL);
        }
    }

    /**
     * 上传
     *
     * @author weizecheng
     * @date 2020/11/10 16:46
     */
    public  YhResponse uploadFile(String objectName, InputStream in){
        try {
            PutObjectRequest putObjectRequest = new PutObjectRequest(yhOssProperties.getBucket(), objectName,in);
            oss.putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 上传
     *
     * @author weizecheng
     * @date 2020/11/10 16:46
     */
    public  YhResponse uploadFile(String objectName,String fileName){
        try {
            PutObjectRequest putObjectRequest = new PutObjectRequest(yhOssProperties.getBucket(), objectName,new File(fileName));
            oss.putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 获取访问路径
     * 默认授权时间为1小时
     *
     * 3600 * 1000
     *
     * @author weizecheng
     * @date 2020/11/11 11:10
     */
    public  SingleResponse<String> getUrlAddress(String objectName){
        try {
            Date expiration = new Date(System.currentTimeMillis() + 3600 * 1000);
            URL url = oss.generatePresignedUrl(yhOssProperties.getBucket(), objectName, expiration);
            String ossAddress = url.toString();
            if (StringUtils.isNotBlank(yhOssProperties.getOssBeforeKey()) && StringUtils.isNotBlank(yhOssProperties.getOssAfterKey())) {
                ossAddress = ossAddress.replace(yhOssProperties.getOssBeforeKey(), yhOssProperties.getOssAfterKey());
            }
            return SingleResponse.of(ossAddress);
        }catch (Exception e){
            log.info("getUrlAddress = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }


    /**
     *
     *
     * @author zecheng.wei
     * @Date 2023/7/20 10:01
     */
    public  SingleResponse<String> getDownloadUrlAddress(String objectName){
        try {
            Date expiration = new Date(System.currentTimeMillis() + 3600 * 1000);
            GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(yhOssProperties.getBucket(), objectName);
            generatePresignedUrlRequest.setExpiration(expiration);
            ResponseHeaderOverrides responseHeaders = new ResponseHeaderOverrides();
            responseHeaders.setContentDisposition("attachment");
            generatePresignedUrlRequest.setResponseHeaders(responseHeaders);
            URL url = oss.generatePresignedUrl(generatePresignedUrlRequest);
            String ossAddress = url.toString();
            if (StringUtils.isNotBlank(yhOssProperties.getOssBeforeKey()) && StringUtils.isNotBlank(yhOssProperties.getOssAfterKey())) {
                ossAddress = ossAddress.replace(yhOssProperties.getOssBeforeKey(), yhOssProperties.getOssAfterKey());
            }
            return SingleResponse.of(ossAddress);
        }catch (Exception e){
            log.info("getUrlAddress = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }


    /**
     * 自行设置授权时间
     *
     * @author weizecheng
     * @date 2020/11/11 11:11
     */
    public SingleResponse<String> getUrlAddress(String objectName, long time){
        try {
            Date expiration = new Date(System.currentTimeMillis() + time);
            URL url = oss.generatePresignedUrl(yhOssProperties.getBucket(), objectName, expiration);
            String ossAddress = url.toString();
            if (StringUtils.isNotBlank(yhOssProperties.getOssBeforeKey()) && StringUtils.isNotBlank(yhOssProperties.getOssAfterKey())) {
                ossAddress = ossAddress.replace(yhOssProperties.getOssBeforeKey(), yhOssProperties.getOssAfterKey());
            }
            return SingleResponse.of(ossAddress);
        }catch (Exception e){
            log.info("getUrlAddress = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_FAILED.getCode(),ErrorCode.UPLOAD_FAILED.getMessage());
        }
    }

    /**
     * 上传文件。
     * @param objectName 文件目录 + 文件名
     * @param in 输入流
     * @param forbidOverwrite 禁止覆盖同名文件。默认为false允许覆盖
     * @return
     */
    public YhResponse uploadFile(String objectName, InputStream in, boolean forbidOverwrite){
        try {
            ObjectMetadata objectMetadata = new ObjectMetadata();
            objectMetadata.setHeader("x-oss-forbid-overwrite", forbidOverwrite);
            PutObjectRequest putObjectRequest = new PutObjectRequest(yhOssProperties.getBucket(), objectName, in, objectMetadata);
            oss.putObject(putObjectRequest);
            return YhResponse.buildSuccess();
        }catch (Exception e){
            log.info("uploadFile = {}",e.getMessage());
            return SingleResponse.ofFailure(ErrorCode.UPLOAD_EXCEPTION.getCode(),ErrorCode.UPLOAD_EXCEPTION.getMessage(e.toString()));
        }
    }

}
