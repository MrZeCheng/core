package com.yhglobal.bee.sts.common.api;

import com.yhglobal.bee.sts.common.entity.YhStsUser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 登录
 *
 * @author zecheng.wei
 * @Date 2022/9/19 15:04
 */
public interface StsLoginService {

    /**
     * 登录
     *
     * @author zecheng.wei
     * @Date 2022/9/19 15:13
     */
    Object toLogin(YhStsUser yhUser, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse);

}
