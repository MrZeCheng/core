package com.yhglobal.bee.sts.common.configure;

import com.yhglobal.bee.sts.common.properties.YhStsProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;


/**
 *
 *
 * @author weizecheng
 * @date 2021/2/25 9:46
 */
@Configuration
@EnableConfigurationProperties(YhStsProperties.class)
@ConditionalOnProperty(prefix = "yh.sts", name = "enable", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
@Slf4j
public class YhStsAutoConfigure {

}
