package com.yhglobal.bee.sts.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 唯一Id的配置
 *
 * @author zecheng.wei
 * @Date 2022/9/15 15:10
 */
@ConfigurationProperties(prefix = "yh.sts")
public class YhStsProperties {

    private Boolean enable = true;

    private String id;

    private String secret;

    private String ip;

    private String url;

    /**
     * 路径
     */
    private String path;

    private String signout;

    private String config;

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getSignout() {
        return signout;
    }

    public void setSignout(String signout) {
        this.signout = signout;
    }

}
