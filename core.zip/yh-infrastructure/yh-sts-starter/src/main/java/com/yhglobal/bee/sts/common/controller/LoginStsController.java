package com.yhglobal.bee.sts.common.controller;

import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.http.OkHttpManager;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.bee.sts.common.api.StsLoginService;
import com.yhglobal.bee.sts.common.entity.RefreshToken;
import com.yhglobal.bee.sts.common.entity.YhStsUser;
import com.yhglobal.bee.sts.common.properties.YhStsProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.Headers;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * sts 公用controller
 *
 * @author zecheng.wei
 * @Date 2022/9/19 11:52
 */
@RestController
@RequestMapping
@RequiredArgsConstructor
@Slf4j
public class LoginStsController {

    private final YhStsProperties yhStsProperties;

    @RequestMapping(value = "${yh.sts.path:/authority/sts/login}")
    public Object goStsLogin(String code, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
        if (StringUtils.isNotBlank(code)) {
            RefreshToken r = getAccessToken(code,
                    yhStsProperties.getIp(),
                    yhStsProperties.getId(),
                    yhStsProperties.getSecret(),
                    yhStsProperties.getUrl());
            String accessToken = r.getAccessToken();
            String idToken = r.getIdToken();
            log.info("sts login token = {}", idToken);
            YhStsUser yhUser = getUserInfo(accessToken, yhStsProperties.getIp());
            yhUser.setAccessToken(accessToken);
            yhUser.setExpiresIn(r.getExpiresIn());
            // 项目内部处理完用户信息后 重定向到系统首页
            StsLoginService stsLoginService = YhApplicationContext.getBean(yhStsProperties.getConfig(), StsLoginService.class);
            return stsLoginService.toLogin(yhUser, httpServletRequest, httpServletResponse);
        }
        return SingleResponse.ofFailure(ErrorCode.LOGIN_FAIL);
    }

    @RequestMapping(value = "${yh.sts.signout:/authority/sts/signout}")
    public Object goSignout(HttpServletRequest httpServletRequest) {
        String targetUrl = httpServletRequest.getParameter("state");
        log.info("goSignout state: " + targetUrl);
        return new ModelAndView("redirect:" + targetUrl);
    }


    private RefreshToken getAccessToken(String code, String ip,
                               String id, String secret,
                               String callBackUrl){
        log.info("getAccessToken code={},id={},secret = {},callBackUrl={}",code,id,secret,callBackUrl);
        FormBody formBody =  new FormBody.Builder()
                .add("grant_type","authorization_code")
                .add("client_id",id)
                .add("redirect_uri", callBackUrl)
                .add("code",code)
                .add("client_secret",secret)
                .build();
        try {
            return OkHttpManager.postForm(ip + "/connect/token", formBody, RefreshToken.class);
        } catch (IOException e) {
            throw new RuntimeException("http error :"+e.getMessage());
        }
    }

    private YhStsUser getUserInfo(String accessToken, String ip){
        Map<String,String> headerMap = new HashMap<>(4);
        headerMap.put("Authorization", "Bearer " + accessToken);
        Headers newHeaders = Headers.of(headerMap);
        try {
            return OkHttpManager.get(ip + "/connect/userinfo", newHeaders, YhStsUser.class);
        } catch (IOException e) {
            throw new RuntimeException("http error :"+e.getMessage());
        }
    }

}
