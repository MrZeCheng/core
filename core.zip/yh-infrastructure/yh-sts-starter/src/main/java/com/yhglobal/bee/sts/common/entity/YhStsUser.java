package com.yhglobal.bee.sts.common.entity;

public class YhStsUser {

	private String name;

	private String email;

	private String accessToken;

	private String expiresIn;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(String expiresIn) {
		this.expiresIn = expiresIn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "YhStsUser{" +
				"name='" + name + '\'' +
				", email='" + email + '\'' +
				", accessToken='" + accessToken + '\'' +
				", expiresIn='" + expiresIn + '\'' +
				'}';
	}
}
