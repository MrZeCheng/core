package com.yhglobal.bee.sts.common.entity;

import com.yhglobal.bee.common.dto.DTO;

/**
 *
 *
 * @author zecheng.wei
 * @Date 2022/9/19 14:17
 */

public class AuthorityStsReq extends DTO {

    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "AuthorityStsReq{" +
                "code='" + code + '\'' +
                '}';
    }
}
