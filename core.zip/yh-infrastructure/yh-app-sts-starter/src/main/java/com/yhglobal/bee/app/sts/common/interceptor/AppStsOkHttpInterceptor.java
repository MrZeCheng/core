package com.yhglobal.bee.app.sts.common.interceptor;

import com.yhglobal.bee.app.sts.common.configure.AppStsUtil;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http.HttpMethod;

import java.io.IOException;

public class AppStsOkHttpInterceptor implements Interceptor {

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        String url = request.url().url().toString();
        String str = url.contains("?") ? "&" : "?";
        // 传播是否来自老XPS
        Request newRequest = request
                .newBuilder()
                .url(url + str + "token=" + YhApplicationContext.getBean(AppStsUtil.class).getToken())
                .addHeader("Authorization", YhApplicationContext.getBean(AppStsUtil.class).getToken())
                .build();
        return chain.proceed(newRequest);
    }
}
