package com.yhglobal.bee.app.sts.common.http;

import com.yhglobal.bee.app.sts.common.interceptor.AppStsOkHttpInterceptor;
import com.yhglobal.bee.common.http.BaseOkHttpExecuteServiceI;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * app sts的实现
 *
 * @author zecheng.wei
 * @Date 2022/9/20 14:48
 */
public class AppStsOkHttpExecuteServiceImpl implements BaseOkHttpExecuteServiceI {

    private static final OkHttpClient M_OK_HTTP_CLIENT;

    static {
        M_OK_HTTP_CLIENT = new OkHttpClient.Builder()
                .connectTimeout(48, TimeUnit.SECONDS)
                .readTimeout(48, TimeUnit.SECONDS)
                .writeTimeout(48, TimeUnit.SECONDS)
                .addInterceptor(new AppStsOkHttpInterceptor())
                .build();
    }

    @Override
    public Response execute(Request request) throws IOException {
        return M_OK_HTTP_CLIENT.newCall(request).execute();
    }
}
