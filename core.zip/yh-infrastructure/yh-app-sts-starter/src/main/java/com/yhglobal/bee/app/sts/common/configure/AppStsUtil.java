package com.yhglobal.bee.app.sts.common.configure;


import com.yhglobal.bee.app.sts.common.entity.AppStsToken;
import com.yhglobal.bee.app.sts.common.entity.TokenObject;
import com.yhglobal.bee.app.sts.common.properties.YhAppStsProperties;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.http.OkHttpManager;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import lombok.RequiredArgsConstructor;
import okhttp3.FormBody;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@RequiredArgsConstructor
public class AppStsUtil {

    private final YhAppStsProperties yhAppStsProperties;

    private static final String APP_STS_REDIS_KEY = "app:sts:key";

    private static final Map<String, TokenObject> TOKEN_OBJECT_MAP = new ConcurrentHashMap<>(3);


    public String getToken() {
        if (StringUtils.isBlank(yhAppStsProperties.getId()) || StringUtils.isBlank(yhAppStsProperties.getSecret())) {
            return "";
        }
        long nowTime = System.currentTimeMillis();
        TokenObject tokenObject = TOKEN_OBJECT_MAP.get(APP_STS_REDIS_KEY);
        if (tokenObject != null) {
            if (nowTime < tokenObject.getTime()) {
                return tokenObject.getToken();
            }
        }
        FormBody formBody =  new FormBody.Builder()
                .add("grant_type","client_credentials")
                .add("client_id", yhAppStsProperties.getId())
                .add("client_secret", yhAppStsProperties.getSecret())
                .build();
        try {
            AppStsToken appStsToken = OkHttpManager.postForm(yhAppStsProperties.getUrl(), formBody, AppStsToken.class);
            // 减少十分钟
            Long time = appStsToken.getExpiresIn();
            if (time > 600L) {
                // 这里可以设置随机数 5-10的随机数
                time = time - 5 * 60;
            }
            TokenObject tokenObjectNew = new TokenObject();
            tokenObjectNew.setToken(appStsToken.getAccessToken());
            tokenObjectNew.setTime(nowTime + time * 1000);
            TOKEN_OBJECT_MAP.put(APP_STS_REDIS_KEY, tokenObjectNew);
            return appStsToken.getAccessToken();
        }catch (IOException ioException){
            throw new BusinessException(ErrorCode.HTTP_ERROR);
        }
    }
}
