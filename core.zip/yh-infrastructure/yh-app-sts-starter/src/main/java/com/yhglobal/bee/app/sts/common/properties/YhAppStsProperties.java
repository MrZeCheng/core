package com.yhglobal.bee.app.sts.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 唯一Id的配置
 *
 * @author zecheng.wei
 * @Date 2022/9/15 15:10
 */
@ConfigurationProperties(prefix = "yh.app.sts")
public class YhAppStsProperties {


    private Boolean enable = true;

    private String id;

    private String secret;

    private String url;

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
