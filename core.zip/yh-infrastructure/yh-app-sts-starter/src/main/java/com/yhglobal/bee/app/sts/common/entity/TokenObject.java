package com.yhglobal.bee.app.sts.common.entity;

import java.util.Date;

public class TokenObject {

    private String token;

    private Long time;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }
}
