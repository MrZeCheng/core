package com.yhglobal.bee.app.sts.common.configure;

import com.yhglobal.bee.app.sts.common.http.AppStsOkHttpExecuteServiceImpl;
import com.yhglobal.bee.app.sts.common.properties.YhAppStsProperties;
import com.yhglobal.bee.common.http.BaseOkHttpExecuteServiceI;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 *
 *
 * @author weizecheng
 * @date 2021/2/25 9:46
 */
@Configuration
@EnableConfigurationProperties(YhAppStsProperties.class)
@ConditionalOnProperty(prefix = "yh.sequence", name = "enable", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
@Slf4j
public class YhAppStsAutoConfigure {

    @Bean("appStsOkHttpExecuteServiceImpl")
    public BaseOkHttpExecuteServiceI appStsOkHttpExecuteServiceImpl(){
        return new AppStsOkHttpExecuteServiceImpl();
    };

}
