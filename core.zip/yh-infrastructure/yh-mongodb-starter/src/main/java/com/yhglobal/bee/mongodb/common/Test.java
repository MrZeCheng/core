package com.yhglobal.bee.mongodb.common;

public class Test {
}
