//package com.yhglobal.bee.mongodb.common.configure;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.mongodb.core.mapping.event.LoggingEventListener;
//
//
//@Configuration
//public class YhMongodbAutoConfigure {
//
////    public @Bean LoggingEventListener mongoEventListener() {
////        return new LoggingEventListener();
////    }
//
////    spring:
////    mongodb:
////    uri: mongodb://name:password@localhost:27017/test
//}
