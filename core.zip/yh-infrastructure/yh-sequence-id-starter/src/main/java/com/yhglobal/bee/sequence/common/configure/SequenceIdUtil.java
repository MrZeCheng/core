package com.yhglobal.bee.sequence.common.configure;

import com.yhglobal.bee.common.constant.appsts.YhAppStsHttpTypeEnum;
import com.yhglobal.bee.common.constant.sequence.id.BizNumberI;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.http.OkHttpManager;
import com.yhglobal.bee.common.util.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Slf4j
@RequiredArgsConstructor
public class SequenceIdUtil {

    private final String url;

    private final Boolean oath;

    public String nextId(String projectPrefix, BizNumberI bizNumberI) {
        try {
            String idGeneratorUrl = url + "/sequence/id/xps/segment?key=%s&dateFormat=%s&prefix=%s&suffix=%s";
            String sequenceUrl = String.format(idGeneratorUrl, projectPrefix + "_" + bizNumberI.getPrefix(), bizNumberI.getDateTimeFormatterEnum().name(), projectPrefix, bizNumberI.getPrefix());
            SingleResponse singleResponse = oath ? OkHttpManager.get(sequenceUrl, SingleResponse.class, YhAppStsHttpTypeEnum.APP_STS) : OkHttpManager.get(sequenceUrl, SingleResponse.class);
            if (!singleResponse.isSuccess()) {
                log.error("get nextId error = {}",singleResponse);
                return projectPrefix+"_"+bizNumberI.getPrefix()+DateUtil.date2str(new Date(),DateUtil.DATE_FORMAT_YYYY_MM_DD)+ System.currentTimeMillis();
            }
            return singleResponse.getData().toString();
        }catch (Exception e){
            log.error("nextId error = {}",e.getMessage());
            return projectPrefix+"_"+bizNumberI.getPrefix()+DateUtil.date2str(new Date(),DateUtil.DATE_FORMAT_YYYY_MM_DD)+ System.currentTimeMillis();
        }
    }

    public String nextId(String projectPrefix, BizNumberI bizNumberI, Date date) {
        try {
            String idGeneratorUrl = url + "/sequence/id/xps/segment?key=%s&dateFormat=%s&prefix=%s&suffix=%s&dateKey=%s";
            String sequenceUrl = String.format(idGeneratorUrl, projectPrefix + "_" + bizNumberI.getPrefix(), bizNumberI.getDateTimeFormatterEnum().name(), projectPrefix, bizNumberI.getPrefix(), DateUtil.date2str(date, bizNumberI.getDateTimeFormatterEnum().name()));
            SingleResponse singleResponse = oath ? OkHttpManager.get(sequenceUrl, SingleResponse.class, YhAppStsHttpTypeEnum.APP_STS) : OkHttpManager.get(sequenceUrl, SingleResponse.class);
            if (!singleResponse.isSuccess()) {
                log.error("get nextId error = {}",singleResponse);
                return   projectPrefix+"_"+bizNumberI.getPrefix()+DateUtil.date2str(date,DateUtil.DATE_FORMAT_YYYY_MM_DD)+ System.currentTimeMillis();
            }
            return singleResponse.getData().toString();
        }catch (Exception e){
            log.error("nextId error = {}",e.getMessage());
            return projectPrefix+"_"+bizNumberI.getPrefix()+DateUtil.date2str(date,DateUtil.DATE_FORMAT_YYYY_MM_DD)+ System.currentTimeMillis();
        }
    }

    public String nextIdNonProjectPrefix(BizNumberI bizNumberI) {
        try {
            String idGeneratorUrl = url + "/sequence/id/xps/segment?key=%s&dateFormat=%s&suffix=%s";
            String sequenceUrl = String.format(idGeneratorUrl, bizNumberI.getPrefix(), bizNumberI.getDateTimeFormatterEnum().name(), bizNumberI.getPrefix());
            SingleResponse singleResponse = oath ? OkHttpManager.get(sequenceUrl, SingleResponse.class, YhAppStsHttpTypeEnum.APP_STS) : OkHttpManager.get(sequenceUrl, SingleResponse.class);
            if (!singleResponse.isSuccess()) {
                log.error("get nextIdNonProjectPrefix error = {}",singleResponse);
                return bizNumberI.getPrefix()+DateUtil.date2str(new Date(),DateUtil.DATE_FORMAT_YYYY_MM_DD)+ System.currentTimeMillis();
            }
            return singleResponse.getData().toString();
        }catch (Exception e){
            log.error("nextIdNonProjectPrefix error = {}",e.getMessage());
            return  bizNumberI.getPrefix()+DateUtil.date2str(new Date(),DateUtil.DATE_FORMAT_YYYY_MM_DD)+ System.currentTimeMillis();
        }
    }

    public String nextIdNonProjectPrefix(BizNumberI bizNumberI, Date date) {
        try {
            String idGeneratorUrl = url + "/sequence/id/xps/segment?key=%s&dateFormat=%s&suffix=%s&dateKey=%s";
            String sequenceUrl = String.format(idGeneratorUrl, bizNumberI.getPrefix(), bizNumberI.getDateTimeFormatterEnum().name(), bizNumberI.getPrefix(), DateUtil.date2str(date, bizNumberI.getDateTimeFormatterEnum().name()));
            SingleResponse singleResponse = oath ? OkHttpManager.get(sequenceUrl, SingleResponse.class, YhAppStsHttpTypeEnum.APP_STS) : OkHttpManager.get(sequenceUrl, SingleResponse.class);
            if (!singleResponse.isSuccess()) {
                log.error("get nextIdNonProjectPrefix error = {}",singleResponse);
                return bizNumberI.getPrefix()+DateUtil.date2str(date,DateUtil.DATE_FORMAT_YYYY_MM_DD)+System.currentTimeMillis();
            }
            return singleResponse.getData().toString();
        }catch (Exception e){
            log.error("nextIdNonProjectPrefix error = {}",e.getMessage());
            return  bizNumberI.getPrefix()+DateUtil.date2str(date,DateUtil.DATE_FORMAT_YYYY_MM_DD)+System.currentTimeMillis();
        }
    }


    public static void main(String[] args) {
        System.out.println(DateUtil.date2str(new Date(),DateUtil.DATE_FORMAT_YYYY_MM_DD));
    }

}
