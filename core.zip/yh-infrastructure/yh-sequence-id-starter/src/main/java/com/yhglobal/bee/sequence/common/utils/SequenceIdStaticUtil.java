package com.yhglobal.bee.sequence.common.utils;

import com.yhglobal.bee.common.constant.sequence.id.BizNumberI;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.http.OkHttpManager;
import com.yhglobal.bee.sequence.common.configure.SequenceIdUtil;

import java.util.Date;

public class SequenceIdStaticUtil {

    private static volatile SequenceIdUtil sequenceIdUtil = null;

    public static String nextId(String projectPrefix, BizNumberI bizNumberI) {
        return getSequenceIdUtil().nextId(projectPrefix, bizNumberI);
    }

    public static String nextId(String projectPrefix, BizNumberI bizNumberI, Date date) {
        return getSequenceIdUtil().nextId(projectPrefix, bizNumberI, date);
    }

    public static String nextIdNonProjectPrefix(BizNumberI bizNumberI) {
        return getSequenceIdUtil().nextIdNonProjectPrefix(bizNumberI);
    }

    public static String nextIdNonProjectPrefix(BizNumberI bizNumberI, Date date) {
        return getSequenceIdUtil().nextIdNonProjectPrefix(bizNumberI, date);
    }

    private static SequenceIdUtil getSequenceIdUtil(){
        if (sequenceIdUtil == null) {
            synchronized (SequenceIdStaticUtil.class){
                if (sequenceIdUtil == null) {
                    sequenceIdUtil = YhApplicationContext.getBean(SequenceIdUtil.class);
                }
            }
        }
        return sequenceIdUtil;
    }
}
