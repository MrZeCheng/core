package com.yhglobal.bee.sequence.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 唯一Id的配置
 *
 * @author zecheng.wei
 * @Date 2022/9/15 15:10
 */
@ConfigurationProperties(prefix = "yh.sequence")
public class YhSequenceProperties {

    private Boolean enable = true;

    private String url;

    private Boolean oath = false;

    public Boolean getOath() {
        return oath;
    }

    public void setOath(Boolean oath) {
        this.oath = oath;
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
