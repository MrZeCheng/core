package com.yhglobal.bee.sequence.common.configure;

import com.yhglobal.bee.sequence.common.properties.YhSequenceProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 *
 *
 * @author weizecheng
 * @date 2021/2/25 9:46
 */
@Configuration
@EnableConfigurationProperties(YhSequenceProperties.class)
@ConditionalOnProperty(prefix = "yh.sequence", name = "enable", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
@Slf4j
public class YhSequenceAutoConfigure {

    private final YhSequenceProperties yhSequenceProperties;

    @Bean(name = "sequenceIdUtil")
    @ConditionalOnMissingBean(name = "sequenceIdUtil")
    public SequenceIdUtil sequenceIdUtil() {
        return new SequenceIdUtil(yhSequenceProperties.getUrl(), yhSequenceProperties.getOath());
    }
}
