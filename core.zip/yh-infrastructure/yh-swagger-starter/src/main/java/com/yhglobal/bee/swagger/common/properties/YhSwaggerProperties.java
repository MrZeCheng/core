package com.yhglobal.bee.swagger.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "yh.swagger")
public class YhSwaggerProperties {

    private Boolean enable = true;

    private String description;

    private String title;

    private String author;

    public Boolean getEnable() {
        return enable;
    }

    public YhSwaggerProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public YhSwaggerProperties setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public YhSwaggerProperties setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public YhSwaggerProperties setAuthor(String author) {
        this.author = author;
        return this;
    }
}
