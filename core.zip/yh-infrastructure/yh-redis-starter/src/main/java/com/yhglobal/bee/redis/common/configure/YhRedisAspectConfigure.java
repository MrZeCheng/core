//package com.yhglobal.bee.redis.common.configure;
//
//
//import YhRedisProperties;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.boot.context.properties.EnableConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.EnableAspectJAutoProxy;
//
//
///**
// * 开启切面注解问题
// *
// * @author weizecheng
// * @date 2021/2/7 10:37
// */
//@Configuration
//@EnableConfigurationProperties(YhRedisProperties.class)
//@ConditionalOnProperty(value = "yh.redis.annotation", havingValue = "true", matchIfMissing = true)
//@EnableAspectJAutoProxy
//public class YhRedisAspectConfigure {
//
//    /**
//     * 当加载 redisTemplate 时 才使用切面
//     *
//     * @author weizecheng
//     * @date 2021/2/7 10:38
//     */
//    @Bean
//    @ConditionalOnBean(name = "redisTemplate")
//    @ConditionalOnMissingBean(YhRedisAspect.class)
//    public YhRedisAspect catchLogAspect() {
//        System.out.println("加载3");
//        return new YhRedisAspect();
//    }
//}
