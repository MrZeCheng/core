package com.yhglobal.bee.redis.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "yh.redis")
public class YhRedisProperties {

    private Boolean enable = true;

    private Boolean annotation = true;

    public Boolean getEnable() {
        return enable;
    }

    public YhRedisProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    public Boolean getAnnotation() {
        return annotation;
    }

    public YhRedisProperties setAnnotation(Boolean annotation) {
        this.annotation = annotation;
        return this;
    }
}
