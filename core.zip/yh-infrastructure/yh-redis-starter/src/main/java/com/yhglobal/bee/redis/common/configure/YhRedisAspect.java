package com.yhglobal.bee.redis.common.configure;

import com.yhglobal.bee.common.annotation.redis.RedisDelete;
import com.yhglobal.bee.common.annotation.redis.RedisDeleteAll;
import com.yhglobal.bee.common.annotation.redis.RedisGet;
import com.yhglobal.bee.redis.common.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.common.TemplateParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

import javax.annotation.Resource;
import java.lang.reflect.Method;

/**
 * 切面注解
 *
 * @author weizecheng
 * @date 2021/2/7 11:27
 */
@Aspect
@Slf4j
public class YhRedisAspect {

    @Resource
    private RedisService redisService;

    @Pointcut("@within(com.yhglobal.bee.common.annotation.redis.Redis) && execution(public * *(..))")
    private void pointcutRedis(){

    }

    @Around(value = "pointcutRedis()")
    public Object aroundRedis(ProceedingJoinPoint joinPoint) throws Throwable{
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        // 情况1 获取注解
        RedisGet redisGet = method.getAnnotation(RedisGet.class);
        if (redisGet != null) {
            return aroundGet(joinPoint,redisGet,method);
        }
        // 情况2 删除注解
        RedisDelete redisDelete = method.getAnnotation(RedisDelete.class);
        if (redisDelete != null) {
            return aroundDelete(joinPoint,redisDelete);
        }
        // 情况3 删除所有注解
        RedisDeleteAll redisDeleteAll = method.getAnnotation(RedisDeleteAll.class);
        if (redisDeleteAll != null) {
            return afterDeleteAll(joinPoint,redisDeleteAll);
        }
        return joinPoint.proceed();
    }



    /**
     * 删除所有模糊查询的key
     *
     * @author weizecheng
     * @date 2021/3/26 10:41
     */

    private Object afterDeleteAll(ProceedingJoinPoint joinPoint,RedisDeleteAll redisDeleteAll)throws Throwable{
        Object object = joinPoint.proceed();
        try {
            Long num = redisService.deleteAll(redisDeleteAll.redisKey());
            log.info("afterDeleteAll key:{},num={}",redisDeleteAll.redisKey(),num);
        }catch (Exception e){
            log.error("error afterDeleteAll!", e);
        }
        return object;
    }



    private Object aroundDelete(ProceedingJoinPoint joinPoint,RedisDelete redisCache) throws Throwable{
        // 获取对象上的redis对象
        try {
            String redisKey = redisCache.redisKey();
            // 使用参数作为对象
            if (StringUtils.isBlank(redisCache.SPEL())) {
                if (redisCache.parameter()) {
                    // 潜在问题 数组越界
                    // 不考虑异常啥的 如果有问题 直接执行
                    if (joinPoint.getArgs().length > redisCache.parameterLocation()) {
                        redisKey = redisKey +":"+joinPoint.getArgs()[redisCache.parameterLocation()].toString();
                    }
                }
            }else {
                redisKey = redisKey +":"+getRedisSPEL(redisCache.SPEL(), joinPoint);
            }
            // 双删 方式执行
            try {
                redisService.del(redisKey);
            }catch (Exception e){
                log.error("redisCachePointCutError! first", e);
            }
            Object object = joinPoint.proceed();
            try {
                redisService.del(redisKey);
            }catch (Exception e){
                log.error("redisCachePointCutError! second", e);
            }
            return object;
        }catch (Exception e){
            log.error("redisCachePointCutError!", e);
            //异常直接执行方法
            throw e;
        }
    }



    private String getRedisSPEL(String spel,ProceedingJoinPoint joinPoint){
        Object[] objects = joinPoint.getArgs();
        MethodSignature methodSignature = (MethodSignature)joinPoint.getSignature();
        String[] strings = methodSignature.getParameterNames();

        StandardEvaluationContext context = new StandardEvaluationContext();
        if(objects.length == strings.length && objects.length > 0){
            for (int i = 0; i < strings.length;i++) {
                context.setVariable(strings[i],objects[i]);
            }
        }
        ExpressionParser parser = new SpelExpressionParser();
        return parser.parseExpression(spel.replaceAll("#\\{","#{#"),new TemplateParserContext()).getValue(context,String.class);
    }

    /**
     * 存入对象
     *
     * @param joinPoint
     * @param redisCache
     * @param method
     * @return
     * @throws Throwable
     */
    private Object aroundGet(ProceedingJoinPoint joinPoint,RedisGet redisCache, Method method) throws Throwable{
        // 获取对象上的redis对象
        boolean bool = false;
        try {
            String redisKey = redisCache.redisKey();
            // 使用参数作为对象
            // SPEL 为空 才执行下面的逻辑
            if (StringUtils.isBlank(redisCache.SPEL())) {
                if (redisCache.parameter()) {
                    // 潜在问题 数组越界
                    // 不考虑异常啥的 如果有问题 直接执行
                    if (joinPoint.getArgs().length > redisCache.parameterLocation()) {
                        redisKey = redisKey +":"+joinPoint.getArgs()[redisCache.parameterLocation()].toString();
                    }
                }
            }else {
                redisKey = redisKey +":"+getRedisSPEL(redisCache.SPEL(), joinPoint);
            }
            Object realValue = redisService.get(redisKey);
            if (realValue != null){
                return realValue;
            }else {
                // 直接执行方法 可能会发生异常
                bool = true;
                realValue = joinPoint.proceed();
                if (realValue != null) {
                    // 不等于空才存入缓存  这里可以增加配置 是否空值也要存入缓存
                    try {
                        redisService.set(redisKey,realValue,redisCache.expire());
                    }catch (Exception e){
                        log.info("redisService save error = {}",e.getMessage());
                    }
                }else {
                    // 增加空值传入逻辑
                    if (redisCache.isNull()) {
                        try {
                            redisService.set(redisKey,null,redisCache.expire());
                        }catch (Exception e){
                            log.info("redisService save error = {}",e.getMessage());
                        }
                    }

                }
                return realValue;
            }
        }catch (Exception e){
            log.error("redisCachePointCutError!", e);
            //异常直接执行方法
            if (bool) {
                // 代表是执行方法发生的异常
                throw e;
            }else {
                return joinPoint.proceed();
            }
        }
    }

}
