package com.yhglobal.bee.redis.common.configure;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yhglobal.bee.redis.common.properties.YhRedisProperties;
import com.yhglobal.bee.redis.common.service.RedisService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * redis 基本配置
 *
 * @author weizecheng
 * @date 2021/2/7 10:33
 */
@Configuration
@EnableConfigurationProperties(YhRedisProperties.class)
@ConditionalOnProperty(prefix = "yh.redis", name = "enable",havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
@EnableAspectJAutoProxy
public class YhRedisAutoConfigure {

    private final RedisConnectionFactory redisConnectionFactory;

//    spring:
//    redis:
//    database: 6  #Redis索引0~15，默认为0
//    host: 127.0.0.1
//    port: 6379
//    password:  #密码（默认为空）
//    lettuce: # 这里标明使用lettuce配置
//    pool:
//    max-active: 8   #连接池最大连接数（使用负值表示没有限制）
//    max-wait: -1ms  #连接池最大阻塞等待时间（使用负值表示没有限制）
//    max-idle: 5     #连接池中的最大空闲连接
//    min-idle: 0     #连接池中的最小空闲连接
//    timeout: 10000ms    #连接超时时间（毫秒）


    @Bean(name = "redisTemplate")
    @ConditionalOnMissingBean(name = "redisTemplate")
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        Jackson2JsonRedisSerializer<Object> jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer<>(Object.class);
        ObjectMapper mapper = new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        mapper.activateDefaultTyping(mapper.getPolymorphicTypeValidator(), ObjectMapper.DefaultTyping.NON_FINAL);
        jackson2JsonRedisSerializer.setObjectMapper(mapper);
        StringRedisSerializer stringRedisSerializer = new StringRedisSerializer();
        template.setKeySerializer(stringRedisSerializer);
        template.setHashKeySerializer(stringRedisSerializer);
        template.setValueSerializer(jackson2JsonRedisSerializer);
        template.setHashValueSerializer(jackson2JsonRedisSerializer);
        template.setEnableTransactionSupport(false);
        template.afterPropertiesSet();
        return template;
    }

    @Bean
    @ConditionalOnBean(name = "redisTemplate")
    public RedisService redisService(RedisTemplate<String, Object> redisTemplate) {
        return new RedisService(redisTemplate);
    }

    @Bean
    @ConditionalOnBean(name = "redisTemplate")
    @ConditionalOnMissingBean(YhRedisAspect.class)
    public YhRedisAspect redisAspect() {
        return new YhRedisAspect();
    }

//    public @PreDestroy
//    void flushTestDb() {
//        redisConnectionFactory.getConnection().flushDb();
//    }
}
