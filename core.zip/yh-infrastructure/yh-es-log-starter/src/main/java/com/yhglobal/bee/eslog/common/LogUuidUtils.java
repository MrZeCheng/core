package com.yhglobal.bee.eslog.common;

import com.fasterxml.uuid.EthernetAddress;
import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.impl.TimeBasedGenerator;

/**
 * 日志uuid的工具类 基于时间的和网卡
 *
 * @author zecheng.wei
 * @Date 2023/7/31 10:48
 */
public class LogUuidUtils {

    private static final TimeBasedGenerator UUID = Generators.timeBasedGenerator(EthernetAddress.fromInterface());

    public static String getUuid(){
        return UUID.generate().toString();
    }
}
