package com.yhglobal.bee.eslog.common;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * uuid的自定义字段
 *
 * @author zecheng.wei
 * @Date 2023/7/31 10:27
 */
public class UuidClassicConverter extends ClassicConverter {

    @Override
    public String convert(ILoggingEvent iLoggingEvent) {
        return LogUuidUtils.getUuid();
    }
}
