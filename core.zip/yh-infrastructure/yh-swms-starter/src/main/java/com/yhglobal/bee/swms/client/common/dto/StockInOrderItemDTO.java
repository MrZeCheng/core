package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author wangsheng
 */
@XmlRootElement(name = "stockInOrderItem")
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class StockInOrderItemDTO extends DTO {
    /**
     * 行号
     **/
    private String itemNo;
    /**
     * 商品编码  必选
     **/
    private String itemCode;
    /**
     * 商品名称
     **/
    private String itemName;
    /**
     * 库存类型  必选
     **/
    private Integer inventoryType;
    /**
     * 商品数量  必选
     **/
    private Integer itemQuantity;
    /**
     * 销售价格
     **/
    private BigDecimal itemPrice;
    /**
     * 吊牌价
     **/
    private BigDecimal tagPrice;
    /**
     * 采购价格
     **/
    private BigDecimal purchasePrice;
    /**
     * 商品生产日期
     **/
    private Date produceDate;
    /**
     * 商品过期日期
     **/
    private Date expireDate;
    /**
     * 商品版本
     **/
    private String itemVersion;
    /**
     * 批次号
     **/
    private String batchCode;
    /**
     *
     **/
    private String custCode;
    /**
     * wms实际以这个字段接收批次
     **/
    private String eRPBatchCode;
}
