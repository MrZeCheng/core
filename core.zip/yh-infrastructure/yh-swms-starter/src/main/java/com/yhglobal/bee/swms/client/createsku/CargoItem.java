package com.yhglobal.bee.swms.client.createsku;


import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;

/**
 * 商品的详情信息
 *
 * @author ：Wangsheng
 */
@Data
@Accessors(chain = true)
@NoArgsConstructor
public class CargoItem extends DTO {

    /**
     * 商品编码
     */
    private String CargoCode;

    /**
     * 商品名称
     */
    private String CargoName;

    /**
     *
     **/
    private String HsCode;

    /**
     * 英文名称
     **/
    private String EnglishName;

    /**
     * 规格型号
     **/
    private String Model;

    /**
     * 最小售卖单位
     **/
    private String Unit;

    /**
     * 商品条码
     **/
    private String Barcode;

    /**
     * 条码是否覆盖
     **/
    private Boolean IsBarcodeCover;

    /**
     * 毛重
     **/
    private BigDecimal Gwgt;
    /**
     * 是否有效期管理
     **/
    private Boolean IsExpControl;
    /**
     * 是否序列号管控
     **/
    private Boolean IsSnControl;

    private BigDecimal Length;

    private BigDecimal Width;

    private BigDecimal Height;
    /**
     * 保质期天数
     **/
    private Integer ExtDays;
    /**
     * 入库拒收期天数
     **/
    private Integer RejectionDays;
    /**
     * 库存预警期天数
     **/
    private Integer AlertDays;
    /**
     * 临期品售卖天数
     **/
    private Integer AdventSoldDays;

    /**
     * 禁售天数
     **/
    private Integer ForbidSaleDays;

    /**
     * 是否支持临期品售卖
     **/
    private Boolean IsAdventManage;

    /**
     * 是否工厂店
     **/
    private Boolean IsFactoryShop;

    /**
     * 包装耗材
     **/
    private String PackConsumables;

    /**
     * 分类列表
     **/
    private List<String> CategoryNameList;

    /**
     * 是否一类医疗器械
     **/
    private Integer IsLevle1MedicalInstrument;

    /**
     * 是否二类医疗器械
     **/
    private Integer IsLevle2MedicalInstrument;

    /**
     * 生产企业名称
     **/
    private String VendorName;

    /**
     * 生产企业生产许可证
     **/
    private String VendorProductionLicence;

    /**
     * 备案凭证编号
     **/
    private String VendorFilingForRecordNo;

    /**
     * 注册证号
     **/
    private String VendorRegistrationCertificate;

    /**
     * 包装说明
     **/
    private String MaterialDesc;

    /**
     * 原产国
     **/
    private String ProductionCountry;

    /**
     * 前置预包装类型 0无预包 1前置预包装 2后置预包装
     **/
    private Integer PrePackType;

    /**
     * 前置包装规则
     **/
    private String PrePackRule;
}
