package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 配送要求信息
 *
 * @author wangsheng
 */
@Data
@Accessors(chain = true)
public class DeliverRequirementsDTO extends DTO {

    /**
     * 投递时延要求 可选
     **/
    private Integer scheduleType;
    /**
     * 送达时间 可选
     **/
    private String scheduleDay;
    /**
     * 送达开始时间 可选
     **/
    private String scheduleStart;
    /**
     * 送达结束时间 可选
     **/
    private String scheduleEnd;

}