package com.yhglobal.bee.swms.client.common;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @author wangsheng
 */
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class NotifyWmsCommonRequest extends DTO {
    /**
     * 消息类型
     */
    private String messageType;
    /**
     * 报文
     */
    private String data;
}
