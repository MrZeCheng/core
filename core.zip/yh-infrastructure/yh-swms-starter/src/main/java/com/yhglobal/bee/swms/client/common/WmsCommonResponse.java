package com.yhglobal.bee.swms.client.common;

import com.yhglobal.bee.common.dto.DTO;
import com.yhglobal.bee.swms.client.common.dto.ErrorNotifyDTO;
import com.yhglobal.bee.swms.client.common.dto.WmsInventoryDTO;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * wms的统一响应实体
 *
 * @author wangsheng
 */
@Data
@Accessors(chain = true)
public class WmsCommonResponse extends DTO {

    private final static String REGEX = ";";

    /**
     * 是否成功标识
     */
    private Boolean isSuccess;

    /**
     *
     */
    private String message;

    /**
     *
     */
    private Boolean unAuthorizedRequest;

    /**
     * 业务处理结果的信息
     */
    private WmsInventoryDTO results;

    /**
     * 参数校验的信息
     */
    private ErrorNotifyDTO error;

    /**
     * 错误码
     */
    private String errorCode;

    public static boolean isSuccess(WmsCommonResponse wmsCommonResponse) {
        if (wmsCommonResponse == null) {
            return false;
        }
        return wmsCommonResponse.getIsSuccess();
    }

    public static String getResultMessage(WmsCommonResponse wmsCommonResponse) {
        if (wmsCommonResponse == null) {
            return "null";
        }
        String message = wmsCommonResponse.getMessage();
        String[] messages;
        if (message == null) {
            return "null";
        }
        messages = message.split(REGEX);
        return messages[0];
    }
}
