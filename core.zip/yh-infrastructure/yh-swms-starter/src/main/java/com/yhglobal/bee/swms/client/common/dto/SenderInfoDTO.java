package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author wangsheng
 */
@XmlRootElement(name = "senderInfo")
@Data
@Accessors(chain = true)
public class SenderInfoDTO extends DTO {
    /**
     * 发货方邮编
     **/
    private String senderZipCode;
    /**
     * 发货方省份
     **/
    private String senderProvince;
    /**
     * 发货方城市
     **/
    private String senderCity;
    /**
     * 发货方区县
     **/
    private String senderArea;
    /**
     * 发货方区县    必选
     **/
    private String senderAddress;
    /**
     * 发货方名称    必选
     **/
    private String senderName;
    /**
     * 发货方手机
     **/
    private String senderMobile;
    /**
     * 发货方电话
     **/
    private String senderPhone;
}
