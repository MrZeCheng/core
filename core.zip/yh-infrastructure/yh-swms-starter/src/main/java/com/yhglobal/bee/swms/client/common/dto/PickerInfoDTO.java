package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 提货人信息
 *
 * @author wangsheng
 */
@Data
@Accessors(chain = true)
public class PickerInfoDTO extends DTO {
    /**
     * 提货人
     **/
    private String pickerName;
    /**
     * 提货人电话
     **/
    private String pickerPhone;
    /**
     * 提货人车牌号
     **/
    private String pickerCarNo;
    /**
     * 提货人证件号
     **/
    private String pickerCardID;
    /**
     * 提货车型
     **/
    private String pickerCarType;
    /**
     * 承运公司名称
     **/
    private String parriersName;
    /**
     * 承运公司代码
     **/
    private String parriersCode;
}
