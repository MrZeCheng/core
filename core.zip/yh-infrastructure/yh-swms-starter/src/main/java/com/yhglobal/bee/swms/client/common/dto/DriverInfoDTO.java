package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class DriverInfoDTO extends DTO {

    private String driverName;
    private String driverMobile;
    private String dlateNumber;
}
