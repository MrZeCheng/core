package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * @ Author     ：Wangsheng
 * @ Description：发票明细
 */
@Data
@Accessors(chain = true)
public class InvoiceDetailDTO extends DTO {


    /**
     *
     * */
    private Integer itemType;

    /**
     *商品编码
     * */
    private String itemScode;

    /**
     *商品名称
     * */
    private String itemName;

    /**
     *商品的规格
     * */
    private String itemSpec;

    /**
     *商品的单位 类似 个、斤、箱等
     * */
    private String itemUnit;

    /**
     *商品的数量
     * */
    private Integer itemQuantity;

    /**
     *商品的单价
     * */
    private BigDecimal itemPrice;

    /**
     *商品的总价
     * */
    private BigDecimal totalPrice;

    /**
     *税率
     * */
    private BigDecimal taxRate;

    /**
     *税额
     * */
    private BigDecimal tax;

    /**
     *编码
     * */
    private String taxCode;
}
