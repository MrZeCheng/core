package com.yhglobal.bee.swms.client.createsku;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @author ：Wangsheng 创建仓库商品请求实体
 */
@Data
@Accessors(chain = true)
@NoArgsConstructor
public class CreateSkuReq extends DTO {

    /**
     * 客户主数据
     */
    private String CustomerCode;

    /**
     * SWMS的仓库id
     */
    private String WarehouseId;

    /**
     * 商品列表
     */
    private List<CargoItem> CargoItemList;
}
