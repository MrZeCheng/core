package com.yhglobal.bee.swms.client.common;

/**
 * wms消息类型
 *
 * @author wangsheng
 */
public enum MessageType {

    /**
     * 入库通知单
     */
    INSTOCK_ORDER("入库通知单", 1),
    UPDATE_INSTOCK_ORDER("入库单更新", 12),
    OUTSTOCK_ORDER("出库通知单", 11),
    SALES_OUTSTOCK_ORDER("销售出库单", 3),
    CANCEL_ORDER("取消订单", 4),
    INVENTORY_QUERRY_ORDER("库存查询", 5),
    ADJUST_ORDER("调整通知单", 6),
    CLOSE_ORDER("关闭通知单", 7),
    INSTOCK_ORDER_AUDIT("入库通知单审核", 8),
    CREATE_SWMS_SKU("创建商品", 9),

    INVENTORY_QUERY_ALL("库存全量查询", 15),
    TALLY_ORDER_REVIEW_RESULT("理货报告审核结果", 16);


    private String orderTypeStr;
    private Integer orderType;

    MessageType(String orderTypeStr, int orderType) {
        this.orderTypeStr = orderTypeStr;
        this.orderType = orderType;
    }

    public String getOrderTypeStr() {
        return orderTypeStr;
    }

    public void setOrderTypeStr(String orderTypeStr) {
        this.orderTypeStr = orderTypeStr;
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(int orderType) {
        this.orderType = orderType;
    }
}
