package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author wangsheng
 * @ Description：wms请求统结果信息
 */
@Data
@Accessors(chain = true)
public class WmsInventoryDTO extends DTO {

    /**
     *
     */
    private String id;

    /**
     *
     */
    private String errorCode;

    /**
     *
     */
    private String errorMsg;

    /**
     *
     */
    private String message;

    /**
     *
     */
    private String orderNo;

    /**
     * 业务处理是否成功表示
     */
    private Boolean success;
}
