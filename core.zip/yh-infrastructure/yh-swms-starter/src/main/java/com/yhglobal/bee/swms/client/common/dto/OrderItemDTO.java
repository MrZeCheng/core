package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @ Author     ：Wangsheng
 * @ Description：订单详情
 */
@Data
@Accessors(chain = true)
public class OrderItemDTO extends DTO {

    private String itemCode;
    private String itemName;
    private Integer itemQuantity;
}
