package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @ Author     ：Wangsheng
 * @ Description：缺失参数信息
 */
@Data
@Accessors(chain = true)
public class ValidationErrorDTO extends DTO {
    private List<String> members;
    private String message;
}
