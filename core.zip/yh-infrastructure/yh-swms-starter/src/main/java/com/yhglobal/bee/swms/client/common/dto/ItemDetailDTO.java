package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @ Author     ：Wangsheng
 * @ Description：调整单商品明细
 */
@Data
@Accessors(chain = true)
public class ItemDetailDTO extends DTO {

    /**
     * 行号(必选)
     **/
    private String itemNo;
    /**
     * 商品编码(必选)
     **/
    private String itemCode;
    /**
     * 数量(必选)
     **/
    private Integer itemQuantity;
    /**
     * 调整标记 TO-调整后  FROM-调整前 (必选)
     **/
    private String flag;
    /**
     * (可选)
     **/
    private String plant;
    /**
     * ERP批次号(可选)
     **/
    private String eRPBatchCode;
    /**
     * 参考号(如果Flag是TO，则必选，对应为FROM的ItemNo)
     **/
    private String refNo;
    /**
     * 品质(必选)
     **/
    private Integer inventoryType;
}
