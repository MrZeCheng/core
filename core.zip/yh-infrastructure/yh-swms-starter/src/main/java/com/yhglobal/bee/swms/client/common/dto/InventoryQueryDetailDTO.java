package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @ Author     ：Wangsheng
 * @ Description：查询库存仓库信息列表
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class InventoryQueryDetailDTO extends DTO {

    /**
     * 仓库编码
     **/
    private String ckid;
    /**
     * 货主ID
     **/
    private String ownerCode;
    /**
     * 客户主数据代码
     **/
    private String custMDMCode;
    /**
     * 项目code
     **/
    private String projectCode;
    /**
     * 商品信息列表
     **/
    private List<InventoryQueryDetailItemDTO> items;
}
