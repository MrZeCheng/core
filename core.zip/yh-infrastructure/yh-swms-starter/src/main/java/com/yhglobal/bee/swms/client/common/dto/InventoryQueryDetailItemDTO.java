package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @ Author     ：Wangsheng
 * @ Description：商品信息列表
 */
@AllArgsConstructor
@Data
@Accessors(chain = true)
@NoArgsConstructor
public class InventoryQueryDetailItemDTO extends DTO {

    /**
     * 商品编码
     **/
    private String itemCode;
    /**
     * 品质/库存
     **/
    private String inventoryType;
}