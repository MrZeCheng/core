package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @ Author     ：Wangsheng
 * @ Description：请求参数校验错误信息
 */
@Data
@Accessors(chain = true)
public class ErrorNotifyDTO extends DTO {

    private String code;
    private String details;
    private String message;
    private List<ValidationErrorDTO> validationErrors;
}
