package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.List;


/**
 * @author ：Wangsheng
 * @ Description：发票信息
 */
@Data
@Accessors(chain = true)
public class InvoiceInfoDTO extends DTO {


    /**
     *
     */
    private String billType;

    /**
     *
     */
    private String billTitle;

    /**
     *
     */
    private String taxpayerNumber;

    /**
     *
     */
    private String billNumber;

    /**
     *
     */
    private String billCode;

    /**
     * 总计税额
     */
    private BigDecimal totalTaxPrice;

    /**
     * 总计价格
     */
    private BigDecimal totalPrice;

    /**
     * 发票详情
     */
    private List<InvoiceDetailDTO> invoiceDetails;
}
