package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

/**
 * @ Author     ：Wangsheng
 * @ Description：订单商品信息
 */
@Data
@Accessors(chain = true)
public class ConsignOrderItemDTO extends DTO {

    /**
     * 可选	行号
     **/
    private String itemNo;
    /**
     * 必选	商品编码
     **/
    private String itemCode;
    /**
     * 可选	商品名称
     **/
    private String itemName;
    /**
     * 必选	库存类型
     **/
    private Integer inventoryType;
    /**
     * 必选	商品数量
     **/
    private Integer itemQuantity;
    /**
     * 可选	销售价格
     **/
    private BigDecimal itemPrice;
    /**
     * 必选	是否保价
     **/
    private Boolean isInsured;

    /**
     * 必选	恒温配送 1 是 0 否
     */
    private Integer temperatureDistribution;

    /**
     * 可选	商品实际价格
     **/
    private BigDecimal actualPrice;
    /**
     * 可选	商品生产日期
     **/
    private String produceDate;
    /**
     * 可选	商品过期日期
     **/
    private String expireDate;
    /**
     * 可选	批次号
     **/
    private String batchCode;
    private String recordPartNo;
    /**
     * 可选	ERP批次号
     **/
    private String eRPBatchCode;
    /**
     * 可选	备注
     **/
    private String note;
}
