package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "batchSendCtrlParam")
@Data
@Accessors(chain = true)
public class BatchSendCtrlParamDTO extends DTO {

    /**
     * 总共ITEM数量当distributeType为1时为必选
     **/
    private Integer totalOrderItemCount;
    /**
     * 是否有更多商品0 一次发送 1 多次发送
     **/
    private Integer distributeType;
    /**
     * 收货方邮编
     **/
    private String receiverZipCode;
    /**
     * 收货方省份
     **/
    private String receiverProvince;
    /**
     * 收货方城市
     **/
    private String receiverCity;
    /**
     * 收货方区县
     **/
    private String receiverArea;
    /**
     * 收货方地址
     **/
    private String receiverAddress;
    /**
     * 收货人名称
     **/
    private String receiverName;
    /**
     * 收货人手机
     **/
    private String receiverMobile;
    /**
     * 收货人电话
     **/
    private String receiverPhone;
}
