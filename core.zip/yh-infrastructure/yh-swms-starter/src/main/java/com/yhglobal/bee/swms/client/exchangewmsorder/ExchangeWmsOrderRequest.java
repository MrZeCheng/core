package com.yhglobal.bee.swms.client.exchangewmsorder;

import com.yhglobal.bee.common.dto.DTO;
import com.yhglobal.bee.swms.client.common.dto.ItemDetailDTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @ Author     ：Wangsheng
 * @ Description：库存品质调整请求
 */
@Data
@Accessors(chain = true)
public class ExchangeWmsOrderRequest extends DTO {

    /**
     * 报文ID，唯一
     **/
    private String messageId;
    /**
     * 仓库ID
     **/
    private String ckid;
    /**
     * 订单编码
     **/
    private String orderNo;
    /**
     * 订单来源  [用于区分调用方是哪个系统的 例如云仓是 Opentrade]
     **/
    private String orderSource;

    private Integer adjustType;
    /**
     * 操作类型(10.盘盈 20.盘亏 30属性调整)
     **/
    private Integer orderType;
    /**
     * 业务单据类型
     **/
    private String businessOrderType;
    /**
     * 客户ID
     **/
    private String custID;
    /**
     * 客户编码
     **/
    private String custCode;
    /**
     * 客户主数据代码
     **/
    private String custMDMCode;
    /**
     * 备注
     **/
    private String note;
    /**
     * 订单创建时间(格式为: yyyy-MM-dd HH:mm:ss)
     **/
    private String orderCreateTime;
    /**
     * (可选)
     **/
    private String projectCode;
    /**
     * 调整单商品明细
     **/
    private List<ItemDetailDTO> items;
}
