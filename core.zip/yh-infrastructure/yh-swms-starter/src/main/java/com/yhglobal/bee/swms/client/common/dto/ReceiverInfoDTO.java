package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "receiverInfo")
@Data
@Accessors(chain = true)
public class ReceiverInfoDTO extends DTO {
    /**
     * 收货方邮编
     **/
    private String receiverZipCode;
    /**
     * 收货方省份
     **/
    private String receiverProvince;
    /**
     * 收货方城市
     **/
    private String receiverCity;
    /**
     * 收货方区县
     **/
    private String receiverArea;
    /**
     * 收货方地址     必选
     **/
    private String receiverAddress;
    /**
     * 收货人名称     必选
     **/
    private String receiverName;
    /**
     * 收货人手机
     **/
    private String receiverMobile;
    /**
     * 收货人电话
     **/
    private String receiverPhone;
}
