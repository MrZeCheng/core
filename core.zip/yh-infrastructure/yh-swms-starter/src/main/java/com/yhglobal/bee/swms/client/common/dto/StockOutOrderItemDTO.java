package com.yhglobal.bee.swms.client.common.dto;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @author wangsheng
 */
@Data
@Accessors(chain = true)
public class StockOutOrderItemDTO extends DTO {

    /**
     * 行号    可选
     **/
    private String itemNO;
    /**
     * 商品编码      必选
     **/
    private String itemCode;
    /**
     * 商品名称      可选
     **/
    private String itemName;
    /**
     * 库存类型      必选 参照XPS
     **/
    private Integer inventoryType;
    /**
     * 商品数量      必选
     **/
    private Integer itemQuantity;
    /**
     * 销售价格      可选
     **/
    private Double itemPrice;
    /**
     * 是否保价      必选
     **/
    private Double IsInsured;
    /**
     * 商品实际价格    可选
     **/
    private Double actualPrice;
    /**
     * 商品生产日期    可选
     **/
    private Date produceDate;
    /**
     * 商品过期日期    可选
     **/
    private Date expireDate;
    /**
     * 批次号          可选
     **/
    private String BatchCode;
    /**
     * wms实际以这个字段接收批次
     **/
    private String eRPBatchCode;


    public StockOutOrderItemDTO() {
    }

    public StockOutOrderItemDTO(String itemNO, String itemCode, String itemName, Integer inventoryType, Integer itemQuantity, Double itemPrice, Double isInsured, Double actualPrice, Date produceDate, Date expireDate, String batchCode) {
        this.itemNO = itemNO;
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.inventoryType = inventoryType;
        this.itemQuantity = itemQuantity;
        this.itemPrice = itemPrice;
        IsInsured = isInsured;
        this.actualPrice = actualPrice;
        this.produceDate = produceDate;
        this.expireDate = expireDate;
        BatchCode = batchCode;
    }
}
