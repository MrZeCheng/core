package com.yhglobal.bee.mybatis.common.util;

import com.yhglobal.bee.common.annotation.mybaits.DataBeeInsertAndUpdate;
import com.yhglobal.bee.common.annotation.mybaits.DataBeeTombstone;
import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import com.yhglobal.bee.mybatis.common.entity.DataInsertAndUpdateEntity;
import com.yhglobal.bee.mybatis.common.entity.DataTombstoneEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.ibatis.mapping.MappedStatement;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
@Slf4j
public class InterceptorUtil {

    private static final Map<String, DataInsertAndUpdateEntity> DATA_DATE_UPDATE_MAP = new ConcurrentHashMap<>(16);

    public static DataInsertAndUpdateEntity getDateUpdate(MappedStatement mappedStatement){
        String mappedStatementId = mappedStatement.getId();
        String className = mappedStatementId.substring(0, mappedStatementId.lastIndexOf("."));

        if (DATA_DATE_UPDATE_MAP.containsKey(className)) {
            return DATA_DATE_UPDATE_MAP.get(className);
        }
        DataInsertAndUpdateEntity dataInsertAndUpdate = null;
        try {
            // com.yhglobal.bee.server.foundation.repository.project.FoundationProjectMapper.selectAllProject_COUNT
            // 截取为 com.yhglobal.bee.server.foundation.repository.project.FoundationProjectMapper
            final Class<?> clazz = Class.forName(className);
            if (clazz.isAnnotationPresent(DataInsertAndUpdate.class)) {
                DataInsertAndUpdate dateUpdate = clazz.getAnnotation(DataInsertAndUpdate.class);
                dataInsertAndUpdate = buildDataInsertAndUpdate(dateUpdate);
                DATA_DATE_UPDATE_MAP.put(className,dataInsertAndUpdate);
            }

            if (clazz.isAnnotationPresent(DataBeeInsertAndUpdate.class)) {
                DataBeeInsertAndUpdate dataBeeTombstone = clazz.getAnnotation(DataBeeInsertAndUpdate.class);
                dataInsertAndUpdate = buildDataInsertAndUpdate(dataBeeTombstone);
                DATA_DATE_UPDATE_MAP.put(className,dataInsertAndUpdate);
            }
            if (dataInsertAndUpdate == null){
                DATA_DATE_UPDATE_MAP.put(className,null);
            }
        } catch (Exception ignore) {
        }
        return dataInsertAndUpdate;
    }


    private static DataInsertAndUpdateEntity buildDataInsertAndUpdate(DataBeeInsertAndUpdate dataBeeTombstone){
        DataInsertAndUpdateEntity dataTombstoneEntity = new DataInsertAndUpdateEntity();
        dataTombstoneEntity.setDataVersion(dataBeeTombstone.dataVersion());
        dataTombstoneEntity.setDeleteFlag(dataBeeTombstone.deleteFlag());
        dataTombstoneEntity.setCreatedDate(dataBeeTombstone.createdDate());
        dataTombstoneEntity.setCreatedName(dataBeeTombstone.createdName());
        dataTombstoneEntity.setInsertMethods(dataBeeTombstone.insertMethods());
        dataTombstoneEntity.setExcludeInsertMethods(dataBeeTombstone.excludeInsertMethods());
        dataTombstoneEntity.setUpdateMethods(dataBeeTombstone.updateMethods());
        dataTombstoneEntity.setDepositIdFlag(dataBeeTombstone.depositIdFlag());
        dataTombstoneEntity.setExcludeUpdateMethods(dataBeeTombstone.excludeUpdateMethods());
        dataTombstoneEntity.setModifiedDate(dataBeeTombstone.modifiedDate());
        dataTombstoneEntity.setModifiedName(dataBeeTombstone.modifiedName());
        return dataTombstoneEntity;
    }

    private static DataInsertAndUpdateEntity buildDataInsertAndUpdate(DataInsertAndUpdate dataBeeTombstone){
        DataInsertAndUpdateEntity dataTombstoneEntity = new DataInsertAndUpdateEntity();
        dataTombstoneEntity.setDataVersion(dataBeeTombstone.dataVersion());
        dataTombstoneEntity.setDeleteFlag(dataBeeTombstone.deleteFlag());
        dataTombstoneEntity.setCreatedDate(dataBeeTombstone.createdDate());
        dataTombstoneEntity.setCreatedName(dataBeeTombstone.createdName());
        dataTombstoneEntity.setInsertMethods(dataBeeTombstone.insertMethods());
        dataTombstoneEntity.setExcludeInsertMethods(dataBeeTombstone.excludeInsertMethods());
        dataTombstoneEntity.setUpdateMethods(dataBeeTombstone.updateMethods());
        dataTombstoneEntity.setDepositIdFlag(dataBeeTombstone.depositIdFlag());
        dataTombstoneEntity.setExcludeUpdateMethods(dataBeeTombstone.excludeUpdateMethods());
        dataTombstoneEntity.setModifiedDate(dataBeeTombstone.modifiedDate());
        dataTombstoneEntity.setModifiedName(dataBeeTombstone.modifiedName());
        return dataTombstoneEntity;
    }

    private static final Map<String, DataTombstoneEntity> DATA_TOMBSTONE_MAP = new ConcurrentHashMap<>(16);


    public static DataTombstoneEntity getDataTombstone(MappedStatement mappedStatement) {
        String mappedStatementId = mappedStatement.getId();
        String className = mappedStatementId.substring(0, mappedStatementId.lastIndexOf("."));
        log.debug("className = {}",className);
        if (DATA_TOMBSTONE_MAP.containsKey(className)) {
            log.debug("bool = {}",className);
            return DATA_TOMBSTONE_MAP.get(className);
        }
        DataTombstoneEntity dataTombstoneEntity = null;
        try {
            final Class<?> clazz = Class.forName(className);
            if (clazz.isAnnotationPresent(DataTombstone.class)) {
                DataTombstone dataPermission = clazz.getAnnotation(DataTombstone.class);
                dataTombstoneEntity = buildDataTombstoneEntity(dataPermission);
                DATA_TOMBSTONE_MAP.put(className, dataTombstoneEntity);
            }
            if (clazz.isAnnotationPresent(DataBeeTombstone.class)) {
                DataBeeTombstone dataBeeTombstone = clazz.getAnnotation(DataBeeTombstone.class);
                dataTombstoneEntity = buildDataTombstoneEntity(dataBeeTombstone);
                DATA_TOMBSTONE_MAP.put(className, dataTombstoneEntity);
            }
            if (dataTombstoneEntity == null){
                DATA_TOMBSTONE_MAP.put(className, null);
            }
        } catch (Exception ignore) {
        }
        return dataTombstoneEntity;
    }

    private static DataTombstoneEntity buildDataTombstoneEntity(DataBeeTombstone dataBeeTombstone){
        DataTombstoneEntity dataTombstoneEntity = new DataTombstoneEntity();
        dataTombstoneEntity.setDeleteFlag(dataBeeTombstone.deleteFlag());
        dataTombstoneEntity.setMethods(dataBeeTombstone.methods());
        dataTombstoneEntity.setExcludeMethods(dataBeeTombstone.excludeMethods());
        return dataTombstoneEntity;
    }

    private static DataTombstoneEntity buildDataTombstoneEntity(DataTombstone dataBeeTombstone){
        DataTombstoneEntity dataTombstoneEntity = new DataTombstoneEntity();
        dataTombstoneEntity.setDeleteFlag(dataBeeTombstone.deleteFlag());
        dataTombstoneEntity.setMethods(dataBeeTombstone.methods());
        dataTombstoneEntity.setExcludeMethods(dataBeeTombstone.excludeMethods());
        return dataTombstoneEntity;
    }
}
