package com.yhglobal.bee.mybatis.common.interceptor;

import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.dto.constant.DefaultUserConstant;
import com.yhglobal.bee.common.dto.request.RequestUserThreadLocal;
import com.yhglobal.bee.common.dto.request.RequestYhUser;
import com.yhglobal.bee.common.util.SqlHelpUtil;
import com.yhglobal.bee.common.util.constant.DeleteFlagEnum;
import com.yhglobal.bee.mybatis.common.entity.DataInsertAndUpdateEntity;
import com.yhglobal.bee.mybatis.common.util.InterceptorUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.binding.MapperMethod;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;

import java.lang.reflect.Field;
import java.util.*;


/**
 * 插入数据库 自动填充属性
 *
 * 更新数据库 自动增加更新人和更新时间
 *
 * @author weizecheng
 * @date 2021/8/14 15:57
 */
@Intercepts(
        {
                @Signature(type = Executor.class, method = "update", args = {MappedStatement.class, Object.class}),
        }
)
@Slf4j
public class InsertInterceptor implements Interceptor {

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        DataInsertAndUpdateEntity dateUpdate = InterceptorUtil.getDateUpdate(ms);
        // 查看mapper 是否存在注解
        if (dateUpdate == null) {
            return invocation.proceed();
        }
        //由于逻辑关系，只会进入一次
        SqlCommandType sqlCommandType = ms.getSqlCommandType();
        if (SqlCommandType.UPDATE.equals(sqlCommandType)) {
            return invocation.proceed();
        }else if (SqlCommandType.INSERT.equals(sqlCommandType)) {
            if (SqlHelpUtil.methodsFilter(dateUpdate.getInsertMethods(),dateUpdate.getExcludeInsertMethods(),ms.getId())) {
                return invocation.proceed();
            }
            Object parameter = args[1];
            if (parameter instanceof MapperMethod.ParamMap) {
                MapperMethod.ParamMap paramMap = (MapperMethod.ParamMap)parameter;
                updateFields(paramMap,dateUpdate);
            }else {
                updateObjectFields(parameter,dateUpdate);
            }
            return invocation.proceed();
        }
        return invocation.proceed();
    }

    /**
     * 寻找最上层父类字段
     *
     * @author weizecheng
     * @date 2021/8/15 14:22
     */
    private static Field[] getAllFields(Class<?> clazz) {
        List<Field> list = new ArrayList<>();
        while (clazz != null){
            // 如果父类 等于object
            if (Object.class.getName().equals(clazz.getSuperclass().getName())) {
                break;
            }
            clazz = clazz.getSuperclass();
            list.addAll(Arrays.asList(clazz.getDeclaredFields()));
        }
        return list.toArray(new Field[0]);
    }

    private void updateObjectFields(Object object, DataInsertAndUpdateEntity dateUpdate){
        if (object instanceof List) {
            log.info("object is List");
            return;
        }
        changeFields(dateUpdate,object);
    }

    private void changeFields(DataInsertAndUpdateEntity dateUpdate, Object object){
        try {
            // 找到父类的最上层
            Field[] fields = getAllFields(object.getClass());
            if (fields != null) {
                for (Field field : fields){
                    if (field.getName().equals(dateUpdate.getCreatedDate())){
                        field.setAccessible(true);
                        Object createDate = field.get(object);
                        if(createDate!=null){
                         continue;
                        }
                        field.set(object,new Date());
                        continue;
                    }
                    if (field.getName().equals(dateUpdate.getCreatedName())){
                        field.setAccessible(true);
                        Object createdName = field.get(object);
                        if (createdName != null) {
                            continue;
                        }
                        RequestYhUser requestYhUser = RequestUserThreadLocal.getRequestYhUser();
                        if (requestYhUser != null) {
                            if (dateUpdate.getDepositIdFlag()) {
                                field.set(object,requestYhUser.getUserId());
                            } else {
                                field.set(object,requestYhUser.getUserName());
                            }
                        }else {
                            field.set(object, DefaultUserConstant.DEFAULT_USER);
                        }
                        continue;
                    }
                    if (field.getName().equals(dateUpdate.getDeleteFlag())){
                        field.setAccessible(true);
                        field.set(object, DeleteFlagEnum.EXITS.getStatus());
                        continue;
                    }
                    if (field.getName().equals(dateUpdate.getDataVersion())){
                        field.setAccessible(true);
                        field.set(object,0L);
                    }
                }
            }

        }catch (IllegalAccessException e){
            log.error("updateFields is Error !");
        }
    }

    /**
     * 插入语句
     *
     * 自动注入 创建人 创建时间 逻辑删除标识 版本号
     *
     * @author weizecheng
     * @date 2021/8/15 14:21
     */
    private void updateFields(MapperMethod.ParamMap paramMap, DataInsertAndUpdateEntity dateUpdate) {
        if (!paramMap.isEmpty()) {
            for (Object object : paramMap.values()){
                if (object instanceof String){
                    continue;
                }
                if (object instanceof List) {
                    List list = (List)object;
                    if (!list.isEmpty()) {
                        for (Object o : list) {
                            changeFields(dateUpdate,o);
                        }
                    }
                }else {
                    changeFields(dateUpdate,object);
                }
            }
        }
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
    }
}
