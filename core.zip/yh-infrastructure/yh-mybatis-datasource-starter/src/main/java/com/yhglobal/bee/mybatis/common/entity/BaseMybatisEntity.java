package com.yhglobal.bee.mybatis.common.entity;


import com.yhglobal.bee.common.constant.base.BaseSqlEntity;
import io.mybatis.provider.Entity;

import java.util.Date;


/**
 * 基础信息表
 *
 * @author weizecheng
 * @date 2021/8/14 15:24
 */
public abstract class BaseMybatisEntity extends BaseIdEntity {

    /**
     * 创建时间
     */
    @Entity.Column
    private Date createdDate;
    /**
     * 创建人
     */
    @Entity.Column
    private String createdName;
    /**
     * 最后修改时间
     */
    @Entity.Column
    private Date modifiedDate;
    /**
     * 修改人
     */
    @Entity.Column
    private String modifiedName;
    /**
     * 逻辑删除
     */
    @Entity.Column
    private Integer deleteFlag;
    /**
     * 版本号 暂时无用
     */
    @Entity.Column
    private Long dataVersion;


    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedName() {
        return modifiedName;
    }

    public void setModifiedName(String modifiedName) {
        this.modifiedName = modifiedName;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Long getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(Long dataVersion) {
        this.dataVersion = dataVersion;
    }
}
