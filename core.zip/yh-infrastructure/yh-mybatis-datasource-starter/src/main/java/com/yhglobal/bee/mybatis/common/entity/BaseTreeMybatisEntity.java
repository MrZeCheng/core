package com.yhglobal.bee.mybatis.common.entity;

/**
 * 关系表继承对象
 *
 * @author weizecheng
 * @date 2021/7/30 11:10
 */
public abstract class BaseTreeMybatisEntity extends BaseMybatisEntity{

    /**
     * 父级
     */
    private String parentId;

    /**
     * 当前等级
     */
    private Integer level;

    /**
     * 是否叶子节点
     */
    private Integer leaf;

    /**
     * 最大父级
     */
    private String firstLevelCode;

    public String getFirstLevelCode() {
        return firstLevelCode;
    }

    public BaseTreeMybatisEntity setFirstLevelCode(String firstLevelCode) {
        this.firstLevelCode = firstLevelCode;
        return this;
    }

    public String getParentId() {
        return parentId;
    }

    public BaseTreeMybatisEntity setParentId(String parentId) {
        this.parentId = parentId;
        return this;
    }

    public Integer getLevel() {
        return level;
    }

    public BaseTreeMybatisEntity setLevel(Integer level) {
        this.level = level;
        return this;
    }

    public Integer getLeaf() {
        return leaf;
    }

    public BaseTreeMybatisEntity setLeaf(Integer leaf) {
        this.leaf = leaf;
        return this;
    }

}
