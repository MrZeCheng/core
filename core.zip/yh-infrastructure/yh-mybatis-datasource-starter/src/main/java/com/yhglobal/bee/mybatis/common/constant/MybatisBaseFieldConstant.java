package com.yhglobal.bee.mybatis.common.constant;

/**
 *
 *
 * @author zecheng.wei
 * @Date 2022/10/28 10:13
 */
public interface MybatisBaseFieldConstant {

    String BASE = "id, createdDate, createdName, modifiedDate, modifiedName, deleteFlag, dataVersion, ";

    String BEE_BASE = "id, DeletionTime, DeleterId, IsDeleted, CreatorId, CreationTime, LastModifierId, LastModificationTime,ConcurrencyStamp, ";
}
