package com.yhglobal.bee.mybatis.common.entity;

import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;

public class DataTombstoneEntity {

    private String[] methods;

    private String[] excludeMethods;

    private String deleteFlag;

    public String[] getMethods() {
        return methods;
    }

    public void setMethods(String[] methods) {
        this.methods = methods;
    }

    public String[] getExcludeMethods() {
        return excludeMethods;
    }

    public void setExcludeMethods(String[] excludeMethods) {
        this.excludeMethods = excludeMethods;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }
}
