package com.yhglobal.bee.mybatis.common.entity.impl;

import java.util.Date;

public interface IBaseAuditedEntity {

    public String getLastModifierId();

    public void setLastModifierId(String lastModifierId);

    public Date getLastModificationTime();

    public void setLastModificationTime(Date lastModificationTime);
}
