package com.yhglobal.bee.mybatis.common.interceptor;

import com.github.pagehelper.util.MetaObjectUtil;
import com.yhglobal.bee.common.annotation.mybaits.DataBeeTombstone;
import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import com.yhglobal.bee.common.util.SqlHelpUtil;
import com.yhglobal.bee.common.util.constant.DeleteFlagEnum;
import com.yhglobal.bee.mybatis.common.entity.DataTombstoneEntity;
import com.yhglobal.bee.mybatis.common.util.InterceptorUtil;
import lombok.extern.slf4j.Slf4j;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.io.StringReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 查询自动添加逻辑删除条件
 *
 * @author weizecheng
 * @date 2021/8/14 16:32
 */
@Intercepts(
        {
                @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}),
                @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class}),
        }
)
@Slf4j
public class DateTombstoneInterceptor implements Interceptor {

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        DataTombstoneEntity dataTombstone = InterceptorUtil.getDataTombstone(ms);
        if (dataTombstone == null) {
            return invocation.proceed();
        }

        if (SqlHelpUtil.methodsFilter(dataTombstone.getMethods(),dataTombstone.getExcludeMethods(),ms.getId())) {
            return invocation.proceed();
        }
        Object parameter = args[1];
        BoundSql boundSql;
        //由于逻辑关系，只会进入一次
        if (args.length == 4) {
            //4 个参数时
            boundSql = ms.getBoundSql(parameter);
        } else {
            //6 个参数时
            boundSql = (BoundSql) args[5];
        }
        String sql = boundSql.getSql();
        MetaObject metaObject = MetaObjectUtil.forObject(boundSql);
        String newSql = dataTombstoneSql(sql,dataTombstone);
        metaObject.setValue("sql", newSql);
        return invocation.proceed();
    }

    /**
     * 注入逻辑删除的条件语句
     *
     * @author weizecheng
     * @date 2021/8/15 14:24
     */
    private String dataTombstoneSql(String originSql, DataTombstoneEntity dataTombstone) {
        try {
            CCJSqlParserManager parserManager = new CCJSqlParserManager();
            Select select = (Select) parserManager.parse(new StringReader(originSql));
            PlainSelect plainSelect = (PlainSelect) select.getSelectBody();
            if (plainSelect.getWhere() == null) {
                plainSelect.setWhere(CCJSqlParserUtil.parseCondExpression(dataTombstone.getDeleteFlag() +" = "+ DeleteFlagEnum.EXITS.getStatus()));
            } else {
                plainSelect.setWhere(new AndExpression(plainSelect.getWhere(), CCJSqlParserUtil.parseCondExpression(dataTombstone.getDeleteFlag() +" = "+ DeleteFlagEnum.EXITS.getStatus())));
            }
            return select.toString();
        }catch (Exception e){
            log.warn("get data permission sql fail: {}", e.getMessage());
            return originSql;
        }
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
    }

}
