package com.yhglobal.bee.mybatis.common.entity;

import com.yhglobal.bee.mybatis.common.entity.impl.IBaseAuditedEntity;
import io.mybatis.provider.Entity;

import java.util.Date;

public abstract class BaseAuditedEntity extends BaseCreationAuditedEntity implements IBaseAuditedEntity {

    @Entity.Column(value = "LastModifierId")
    private String lastModifierId;

    @Entity.Column(value = "LastModificationTime")
    private Date lastModificationTime;

    @Override
    public String getLastModifierId() {
        return lastModifierId;
    }

    @Override
    public void setLastModifierId(String lastModifierId) {
        this.lastModifierId = lastModifierId;
    }

    @Override
    public Date getLastModificationTime() {
        return lastModificationTime;
    }

    @Override
    public void setLastModificationTime(Date lastModificationTime) {
        this.lastModificationTime = lastModificationTime;
    }
}
