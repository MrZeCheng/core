package com.yhglobal.bee.mybatis.common.entity;

/**
 * 更新和删除的对象
 *
 * @author zecheng.wei
 * @Date 2022/11/18 11:08
 */
public class DataInsertAndUpdateEntity {

    private String[] updateMethods;

    private String[] excludeUpdateMethods;

    private String[] insertMethods;

    private String[] excludeInsertMethods;

    private String modifiedName;

    private String modifiedDate;

    private String createdName;

    private String createdDate;

    private String deleteFlag;

    private String dataVersion;

    private Boolean depositIdFlag;

    public String[] getUpdateMethods() {
        return updateMethods;
    }

    public void setUpdateMethods(String[] updateMethods) {
        this.updateMethods = updateMethods;
    }

    public String[] getExcludeUpdateMethods() {
        return excludeUpdateMethods;
    }

    public void setExcludeUpdateMethods(String[] excludeUpdateMethods) {
        this.excludeUpdateMethods = excludeUpdateMethods;
    }

    public String[] getInsertMethods() {
        return insertMethods;
    }

    public void setInsertMethods(String[] insertMethods) {
        this.insertMethods = insertMethods;
    }

    public String[] getExcludeInsertMethods() {
        return excludeInsertMethods;
    }

    public void setExcludeInsertMethods(String[] excludeInsertMethods) {
        this.excludeInsertMethods = excludeInsertMethods;
    }

    public String getModifiedName() {
        return modifiedName;
    }

    public void setModifiedName(String modifiedName) {
        this.modifiedName = modifiedName;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getDataVersion() {
        return dataVersion;
    }

    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion;
    }

    public Boolean getDepositIdFlag() {
        return depositIdFlag;
    }

    public void setDepositIdFlag(Boolean depositIdFlag) {
        this.depositIdFlag = depositIdFlag;
    }
}
