package com.yhglobal.bee.mybatis.common.entity.impl;

public interface IBaseIdEntity {

    Long getId();

    void setId(Long id);
}
