package com.yhglobal.bee.mybatis.common.interceptor;

import com.github.pagehelper.util.MetaObjectUtil;
import com.yhglobal.bee.common.annotation.mybaits.MinIdScan;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.util.DateUtil;
import com.yhglobal.bee.mybatis.common.mapper.CommonMapper;
import com.yhglobal.bee.mybatis.common.util.MybatisInterceptorUtil;
import lombok.extern.slf4j.Slf4j;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 查询最小Id的扫描
 */
@Intercepts(
        {
                @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}),
                @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class}),
        }
)
@Slf4j
public class MinIdScanInterceptor implements Interceptor {

    /**
     * key mapper的Id+表名
     *  value  map { key - yyyy-mm-dd ,value - minId} 其中日期指的是哪一天生成的
     */
    private final static Map<String,Map<String,String>> SCAN_ID_MAP ;
    static {
        SCAN_ID_MAP = new HashMap<>();
    }


    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        MinIdScan minIdScan = MybatisInterceptorUtil.getMinIdScan(ms) ;
        if (minIdScan == null) {
            return invocation.proceed();
        }
        Object parameter = args[1];

        BoundSql boundSql;
        //由于逻辑关系，只会进入一次
        if (args.length == 4) {
            //4 个参数时
            boundSql = ms.getBoundSql(parameter);
        } else {
            //6 个参数时
            boundSql = (BoundSql) args[5];
        }
        String sql = boundSql.getSql();
        String scanMinId = getScanMinId(sql,ms,minIdScan);
        MetaObject metaObject = MetaObjectUtil.forObject(boundSql);
        String newSql = minIdScanSql(sql,minIdScan,scanMinId);
        log.debug("拼接最小id后的SQL ： {}",newSql);
        metaObject.setValue("sql", newSql);
        try {
            return invocation.proceed();
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            log.error("实行失败：拼接最小id后的SQL ： {}",newSql);
            throw new RuntimeException(e);
        }
    }
    private String getScanMinId(String sql,MappedStatement ms,MinIdScan minIdScan) {
        String tableName = getTableName(sql,minIdScan) ;
        String methodNameKey = ms.getId()+"."+tableName;
        Map<String, String> minIdMap = null ;
        if (SCAN_ID_MAP.containsKey(methodNameKey)) {
            minIdMap = SCAN_ID_MAP.get(methodNameKey);
        }else{
            minIdMap = new HashMap<>(16);
        }
        String currentDate = DateUtil.date2str(new Date(), DateUtil.DATE_FORMAT);
        if(minIdMap.containsKey(currentDate)){
            log.debug("{}从缓存读取值{}的最小扫描id={}",methodNameKey,currentDate,minIdMap.get(currentDate));
            return minIdMap.get(currentDate);
        }else {
            minIdMap.clear();
            String condition = getScanCondition(minIdScan);
            CommonMapper commonMapper = YhApplicationContext.getBean(CommonMapper.class);
            Object maxId = commonMapper.getMaxIdByDate(tableName, minIdScan.primaryKeyColumn(), condition);
            if(maxId==null){
                maxId = "0";
            }
            minIdMap.put(currentDate,maxId.toString());
            SCAN_ID_MAP.put(methodNameKey,minIdMap);
            return maxId.toString();
        }
    }

    /**
     * "[a-zA-Z0-9_]*"+"表后缀"
     * @param sql
     * @param minIdScan
     * @return
     */
    private String getTableName(String sql, MinIdScan minIdScan) {

        Pattern pattern = Pattern.compile(minIdScan.tableName());
        Matcher matcher = pattern.matcher(sql);
        while (matcher.find()){
            log.debug("正则匹配到表名：{}",matcher.group()==null?"":matcher.group());
            return matcher.group() ;
        }
        log.debug("直接从注解中获取表名：{}",matcher.group()==null?"":matcher.group());
        return minIdScan.tableName();
    }

    private String getScanCondition(MinIdScan minIdScan) {

        String scanDateStr = DateUtil.date2str(DateUtil.addDay(new Date(), (0 - minIdScan.scanDays())), DateUtil.DATE_FORMAT);
        StringBuffer sb = new StringBuffer(" ");
        sb.append("date("). append(minIdScan.createTimeColumn()).append(") ");
        sb.append(" <= '").append( scanDateStr).append("' ");
        return sb.toString();
    }

    /**
     *
     * @param originSql
     * @param minIdScan
     * @param scanMinId
     * @return
     */
    private String minIdScanSql(String originSql, MinIdScan minIdScan,String scanMinId) {
        try {
            CCJSqlParserManager parserManager = new CCJSqlParserManager();
            Select select = (Select) parserManager.parse(new StringReader(originSql));
            PlainSelect plainSelect = (PlainSelect) select.getSelectBody();
            if (plainSelect.getWhere() == null) {
                plainSelect.setWhere(CCJSqlParserUtil.parseCondExpression(minIdScan.primaryKeyColumn() +" >= "+ scanMinId));
            } else {
                plainSelect.setWhere(new AndExpression(plainSelect.getWhere(), CCJSqlParserUtil.parseCondExpression(minIdScan.primaryKeyColumn() +" >= "+ scanMinId)));
            }
            return select.toString();
        }catch (Exception e){
            log.error("originSql={} 拼接最下id失败 {}",originSql, e.getMessage(),e);
            return originSql;
        }
    }
    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
    }
}
