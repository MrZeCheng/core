package com.yhglobal.bee.mybatis.common.mapper;


import com.yhglobal.bee.mybatis.common.provider.YHDeleteProvider;
import io.mybatis.mapper.base.EntityProvider;
import io.mybatis.mapper.list.ListProvider;
import io.mybatis.provider.Caching;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * 越海Mapper
 *
 * @author zecheng.wei
 * @Date 2022/11/17 11:43
 */
public interface YHMapper<T>{

    @Lang(Caching.class)
    @InsertProvider(type = EntityProvider.class, method = "insert")
    int insert(T entity);
    /**
     * 根据主键查询实体
     *
     * @param id 主键
     * @return 实体
     */
    @Lang(Caching.class)
    @SelectProvider(type = EntityProvider.class, method = "selectByPrimaryKey")
    T selectByPrimaryKey(Long id);

    @Lang(Caching.class)
    @InsertProvider(
            type = EntityProvider.class,
            method = "insertSelective"
    )
    int insertSelective(T entity);

    @Lang(Caching.class)
    @UpdateProvider(
            type = EntityProvider.class,
            method = "updateByPrimaryKey"
    )
    int updateByPrimaryKey(T entity);

    @Lang(Caching.class)
    @UpdateProvider(
            type = EntityProvider.class,
            method = "updateByPrimaryKeySelective"
    )
    int updateByPrimaryKeySelective(T entity);

    @Lang(Caching.class)
    @InsertProvider(
            type = ListProvider.class,
            method = "insertList"
    )
    int insertList(@Param("entityList") List<? extends T> entityList);

    @Lang(Caching.class)
    @UpdateProvider(
            type = YHDeleteProvider.class,
            method = "deleteBee"
    )
    int deleteBeeById(Long id);

    @Lang(Caching.class)
    @UpdateProvider(
            type = YHDeleteProvider.class,
            method = "delete"
    )
    int deleteById(Long id);

}
