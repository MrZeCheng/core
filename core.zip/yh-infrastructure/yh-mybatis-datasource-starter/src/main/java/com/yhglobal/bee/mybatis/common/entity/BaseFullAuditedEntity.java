package com.yhglobal.bee.mybatis.common.entity;

import com.yhglobal.bee.mybatis.common.entity.impl.IBaseFullAuditedEntity;
import io.mybatis.provider.Entity;

import java.util.Date;

public abstract class BaseFullAuditedEntity extends BaseAuditedEntity implements IBaseFullAuditedEntity {

    @Entity.Column(value = "DeletionTime")
    private Date deletionTime;

    @Entity.Column(value = "DeleterId")
    private String deleterId;

    @Entity.Column(value = "IsDeleted")
    private Integer isDeleted;

    @Override
    public Date getDeletionTime() {
        return deletionTime;
    }

    @Override
    public void setDeletionTime(Date deletionTime) {
        this.deletionTime = deletionTime;
    }

    @Override
    public String getDeleterId() {
        return deleterId;
    }

    @Override
    public void setDeleterId(String deleterId) {
        this.deleterId = deleterId;
    }

    @Override
    public Integer getIsDeleted() {
        return isDeleted;
    }

    @Override
    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }
}
