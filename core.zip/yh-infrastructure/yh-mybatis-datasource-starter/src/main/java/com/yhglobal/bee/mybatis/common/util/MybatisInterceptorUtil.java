package com.yhglobal.bee.mybatis.common.util;

import com.yhglobal.bee.common.annotation.mybaits.MinIdScan;
import org.apache.ibatis.mapping.MappedStatement;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class MybatisInterceptorUtil {

    private final static Map<String, MinIdScan> MIN_ID_SCAN_MAP ;
    static {
        MIN_ID_SCAN_MAP  = new HashMap<>(16);
    }

    public static MinIdScan getMinIdScan(MappedStatement mappedStatement){
        String mappedStatementId = mappedStatement.getId();
        String idPrefix= mappedStatementId.substring(0,mappedStatementId.lastIndexOf(".") + 1);
        String className = mappedStatementId.substring(0, mappedStatementId.lastIndexOf("."));
        if (MIN_ID_SCAN_MAP.containsKey(mappedStatementId)) {
            return MIN_ID_SCAN_MAP.get(mappedStatementId);
        }
        try {
            final Class<?> clazz = Class.forName(className);
            Method[] methods = clazz.getMethods();
            for (Method method : methods) {
                MinIdScan minIdScan = method.getAnnotation(MinIdScan.class);
                MIN_ID_SCAN_MAP.put(idPrefix+method.getName(),minIdScan);
            }
            return MIN_ID_SCAN_MAP.get(mappedStatementId);
        } catch (Exception ignore) {
        }
        return null;
    }
}
