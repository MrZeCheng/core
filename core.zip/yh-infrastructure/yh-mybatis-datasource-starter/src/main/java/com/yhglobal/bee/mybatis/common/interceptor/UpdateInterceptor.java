package com.yhglobal.bee.mybatis.common.interceptor;

import com.github.pagehelper.util.MetaObjectUtil;
import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.dto.request.RequestUserThreadLocal;
import com.yhglobal.bee.common.dto.request.RequestYhUser;
import com.yhglobal.bee.common.util.DateUtil;
import com.yhglobal.bee.common.util.SqlHelpUtil;
import com.yhglobal.bee.mybatis.common.entity.DataInsertAndUpdateEntity;
import com.yhglobal.bee.mybatis.common.util.InterceptorUtil;
import lombok.extern.slf4j.Slf4j;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.StringValue;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.update.Update;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.DefaultReflectorFactory;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;

import java.io.StringReader;
import java.sql.Connection;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;


/**
 * 插入数据库 自动填充属性
 *
 * 更新数据库 自动增加更新人和更新时间
 *
 * @author weizecheng
 * @date 2021/8/14 15:57
 */
@Intercepts(
        {
                @Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class,Integer.class}),
        }
)
@Slf4j
public class UpdateInterceptor implements Interceptor {

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        if (invocation.getTarget() instanceof StatementHandler) {
            StatementHandler statementHandler = (StatementHandler)invocation.getTarget();
            MetaObject metaObject = MetaObject.forObject(
                    statementHandler,
                    SystemMetaObject.DEFAULT_OBJECT_FACTORY,
                    SystemMetaObject.DEFAULT_OBJECT_WRAPPER_FACTORY,
                    new DefaultReflectorFactory());
            // 获取成员变量mappedStatement
            MappedStatement ms = (MappedStatement) metaObject.getValue("delegate.mappedStatement");
            // 如果sql类型是查询
            DataInsertAndUpdateEntity dateUpdate = InterceptorUtil.getDateUpdate(ms);
            // 查看mapper 是否存在注解
            if (dateUpdate == null) {
                return invocation.proceed();
            }
            SqlCommandType sqlCommandType = ms.getSqlCommandType();
            if (SqlCommandType.UPDATE.equals(sqlCommandType)) {
                if (SqlHelpUtil.methodsFilter(dateUpdate.getUpdateMethods(),dateUpdate.getExcludeUpdateMethods(),ms.getId())) {
                    return invocation.proceed();
                }
                BoundSql boundSql = statementHandler.getBoundSql();
                String sql = dataPermissionSql(boundSql.getSql(),dateUpdate);
                MetaObject metaObject1 = MetaObjectUtil.forObject(boundSql);
                metaObject1.setValue("sql", sql);
            }
            return invocation.proceed();
        }
        return invocation.proceed();
    }

    private String dataPermissionSql(String originSql, DataInsertAndUpdateEntity dateUpdate) {
        try {
            CCJSqlParserManager parserManager = new CCJSqlParserManager();
            Update update = (Update) parserManager.parse(new StringReader(originSql));
            List<Column> columns = update.getColumns();
            String modDate =dateUpdate.getModifiedDate();
            List<Column> columns1 = columns.stream().filter(column -> column.getColumnName().equals(modDate)).collect(Collectors.toList());
            boolean dateBool = false;
            boolean nameBool = false;
            if (columns1.isEmpty()) {
                dateBool = true;
                columns.add(new Column(modDate));
            }
            RequestYhUser requestYhUser = RequestUserThreadLocal.getRequestYhUser();
            if (requestYhUser != null) {
                String modName = dateUpdate.getModifiedName();
                if (StringUtils.isNotBlank(modName)) {
                    List<Column> columnsName = columns.stream().filter(column -> column.getColumnName().equals(modName)).collect(Collectors.toList());
                    if (columnsName.isEmpty()) {
                        columns.add(new Column(modName));
                        nameBool = true;
                    }
                }
            }
            update.setColumns(columns);
            List<Expression> expressions = update.getExpressions();
            // 时间
            if (dateBool) {
                expressions.add(new StringValue(DateUtil.getCurrentDate2()));
            }
            // 更新人
            if (nameBool) {
                if (dateUpdate.getDepositIdFlag()) {
                    expressions.add(new StringValue(requestYhUser.getUserId()));
                } else {
                    expressions.add(new StringValue(requestYhUser.getUserName()));
                }
            }
            update.setExpressions(expressions);
            return update.toString();
        }catch (Exception e){
            log.warn("get data permission sql fail: {}", e.getMessage());
            return originSql;
        }
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
    }
}
