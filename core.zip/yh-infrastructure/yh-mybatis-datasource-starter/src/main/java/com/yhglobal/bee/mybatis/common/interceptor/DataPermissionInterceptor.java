package com.yhglobal.bee.mybatis.common.interceptor;

import com.github.pagehelper.util.MetaObjectUtil;
import com.yhglobal.bee.beans.authority.AuthorityDataBO;
import com.yhglobal.bee.beans.authority.constant.DataPermissionLocal;
import com.yhglobal.bee.common.annotation.mybaits.DataPermission;
import com.yhglobal.bee.common.annotation.mybaits.DataPermissionField;
import lombok.extern.slf4j.Slf4j;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.io.StringReader;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


/**
 * 数据权限拦截器
 *
 * @author weizecheng
 * @date 2021/8/14 15:36
 */
@Intercepts(
        {
                @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}),
                @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class}),
        }
)
@Slf4j
public class DataPermissionInterceptor implements Interceptor {


    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        Object parameter = args[1];
        BoundSql boundSql;
        //由于逻辑关系，只会进入一次
        if(args.length == 4){
            //4 个参数时
            boundSql = ms.getBoundSql(parameter);
        } else {
            //6 个参数时
            boundSql = (BoundSql) args[5];
        }
        // 1. 判断本地变量是否存在 如果不存在 则无需拦截
        AuthorityDataBO dataPermissionModel = DataPermissionLocal.getDataPermission();
        if(dataPermissionModel == null || dataPermissionModel.getColumnValue() == null || dataPermissionModel.getColumnValue().isEmpty()){
            return invocation.proceed();
        }
        // 2. 判断DataPermission 是否存在 && DataPermission的字段是否存在
        String sql = boundSql.getSql();
        DataPermission dataPermission = getDataPermission(ms);
        // 3. 判断DataPermission的字段是否存在
        if(shouldFilter(ms,dataPermission)){
            MetaObject metaObject = MetaObjectUtil.forObject(boundSql);
//        contactConditions(sql);
            String newSql = dataPermissionSql(sql,dataPermission,dataPermissionModel);
            metaObject.setValue("sql", newSql);
            log.info("DataPermission oldSql={},newSql={}",sql,newSql);
        }
        return invocation.proceed();
    }

    /**
     * 组装SQL
     */
    private String dataPermissionSql(String originSql, DataPermission dataPermission,AuthorityDataBO authorityDataBO) {
        try {
            CCJSqlParserManager parserManager = new CCJSqlParserManager();
            Select select = (Select) parserManager.parse(new StringReader(originSql));
            PlainSelect plainSelect = (PlainSelect) select.getSelectBody();
            DataPermissionField[] dataPermissionFields = dataPermission.value();
            Map<String, List<String>> map = authorityDataBO.getColumnValue();
            Set<String> superAll = authorityDataBO.getSuperColumnSet();
            if(superAll == null){
                superAll = new HashSet<>();
            }
            StringBuilder stringBuilders = new StringBuilder();
            for(DataPermissionField dataPermissionField : dataPermissionFields){
                String key = dataPermissionField.field();
                // 超级权限 拥有该字段全部权限
                if(superAll.contains(key)){
                    //
                    continue;
                }
                // 如果权限里有审核点
                if(map.containsKey(key)){
                    List<String> strings = map.get(key);
                    stringBuilders.append(singleField(dataPermissionField.type(),dataPermissionField.fieldAlias(),strings));
                    stringBuilders.append(" AND ");
                }
            }

           if(stringBuilders.length() == 0){
               return select.toString();
           }
           stringBuilders.delete(stringBuilders.length()-5,stringBuilders.length());
            String dataPermissionSql = stringBuilders.toString();
            if (plainSelect.getWhere() == null) {
                plainSelect.setWhere(CCJSqlParserUtil.parseCondExpression(dataPermissionSql));
            } else {
                plainSelect.setWhere(new AndExpression(plainSelect.getWhere(), CCJSqlParserUtil.parseCondExpression(dataPermissionSql)));
            }
            return select.toString();
        }catch (Exception e){
            log.warn("get data permission sql fail: {}", e.getMessage());
            return originSql;
        }
    }


    private static final String SQL_STRING="'";

    private static final String SQL_COMMA=",";

    private StringBuilder singleField(DataPermissionField.Type type,String key,List<String> strings){
        StringBuilder stringBuilder = new StringBuilder(" ").append(key).append(" IN (");
        if(strings.isEmpty()){
            if(type == DataPermissionField.Type.STRING){
                stringBuilder.append("'dataPermission'");
            }
            if(type == DataPermissionField.Type.NUM){
                stringBuilder.append("-1");
            }
            stringBuilder.append(")");
            return stringBuilder;
        }
        for (String string : strings) {
            if(type == DataPermissionField.Type.STRING){
                stringBuilder.append(SQL_STRING);
                stringBuilder.append(string);
                stringBuilder.append(SQL_STRING);
                stringBuilder.append(SQL_COMMA);
            }
            if(type == DataPermissionField.Type.NUM){
                stringBuilder.append(string);
                stringBuilder.append(SQL_COMMA);
            }
        }
        stringBuilder.deleteCharAt(stringBuilder.length()-1);
        stringBuilder.append(") ");
        return stringBuilder;
    }


    private static Map<String,DataPermission> DATA_PERMISSION_MAP = new ConcurrentHashMap<>(16);

    private DataPermission getDataPermission(MappedStatement mappedStatement) {
        String mappedStatementId = mappedStatement.getId();
        String className = mappedStatementId.substring(0, mappedStatementId.lastIndexOf("."));
        if(DATA_PERMISSION_MAP.containsKey(className)){
            return DATA_PERMISSION_MAP.get(className);
        }
        DataPermission dataPermission = null;
        try {
            // com.yhglobal.bee.server.foundation.repository.project.FoundationProjectMapper.selectAllProject_COUNT
            // 截取为 com.yhglobal.bee.server.foundation.repository.project.FoundationProjectMapper
            final Class<?> clazz = Class.forName(className);
            if (clazz.isAnnotationPresent(DataPermission.class)) {
                dataPermission = clazz.getAnnotation(DataPermission.class);
                DATA_PERMISSION_MAP.put(className,dataPermission);
            }else {
                DATA_PERMISSION_MAP.put(className,null);
            }
        } catch (Exception ignore) {
        }
        return dataPermission;
    }

    private Boolean shouldFilter(MappedStatement mappedStatement, DataPermission dataPermission) {
        if (dataPermission != null) {
            // 这里是扩展
            String methodName = StringUtils.substringAfterLast(mappedStatement.getId(), ".");

            // 分页查询会添加参数
            if(methodName.endsWith("_COUNT")){
                methodName = methodName.replace("_COUNT","").trim();
            }
            String[] methods = dataPermission.methods();
            for (String method : methods) {
                if (StringUtils.equals(method, methodName)) {
                    return Boolean.TRUE;
                }
            }
        }
        return Boolean.FALSE;
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
    }
}
