package com.yhglobal.bee.mybatis.common.converter;

import com.github.pagehelper.PageInfo;
import com.yhglobal.bee.common.dto.PageBeeResponse;
import com.yhglobal.bee.common.dto.PageResponse;

/**
 * 转换类
 *
 * @author zecheng.wei
 * @Date 2023/6/6 11:12
 */
public class PageMybatisConverter {

    /**
     * 普通的转换
     *
     * @author zecheng.wei
     * @Date 2023/6/6 11:13
     */
    public static <T> PageResponse<T> of(PageInfo<T> data) {
        return PageResponse.of(data.getList(),data.getTotal(),data.getPageSize(),data.getPageNum());
    }

    /**
     * Bee的转换
     *
     * @author zecheng.wei
     * @Date 2023/6/6 11:13
     */
    public static <T> PageBeeResponse<T> ofBee(PageInfo<T> data) {
        return PageBeeResponse.of(data.getList(),data.getTotal(),data.getPageSize(),data.getPageNum());
    }
}
