package com.yhglobal.bee.mybatis.common.provider;

import com.yhglobal.bee.common.dto.constant.DefaultUserConstant;
import com.yhglobal.bee.common.dto.request.RequestUserThreadLocal;
import com.yhglobal.bee.common.dto.request.RequestYhUser;
import com.yhglobal.bee.common.util.constant.DeleteFlagEnum;
import io.mybatis.provider.EntityColumn;
import io.mybatis.provider.EntityTable;
import io.mybatis.provider.SqlScript;
import org.apache.ibatis.builder.annotation.ProviderContext;

import java.util.stream.Collectors;

public class YHDeleteProvider {

    public YHDeleteProvider() {

    }

    public static String deleteBee(ProviderContext providerContext) {
        return SqlScript.caching(providerContext, new SqlScript() {
            public String getSql(EntityTable entity) {
                RequestYhUser requestYhUser = RequestUserThreadLocal.getRequestYhUser();
                String deleteId = requestYhUser == null ? DefaultUserConstant.DEFAULT_USER : requestYhUser.getUserId();
                return "UPDATE " + entity.tableName() + " SET IsDeleted = "+ DeleteFlagEnum.DELETE.getStatus().toString() +", DeletionTime = NOW(), DeleterId = '" + deleteId +"'" + this.where(() -> {
                    return entity.idColumns().stream().map(EntityColumn::columnEqualsProperty).collect(Collectors.joining(" AND "));
                });
            }
        });
    }

    public static String delete(ProviderContext providerContext) {
        return SqlScript.caching(providerContext, new SqlScript() {
            public String getSql(EntityTable entity) {
                return "UPDATE " + entity.tableName() + " SET deleteFlag = "+ DeleteFlagEnum.DELETE.getStatus().toString() + this.where(() -> {
                    return entity.idColumns().stream().map(EntityColumn::columnEqualsProperty).collect(Collectors.joining(" AND "));
                });
            }
        });
    }

}
