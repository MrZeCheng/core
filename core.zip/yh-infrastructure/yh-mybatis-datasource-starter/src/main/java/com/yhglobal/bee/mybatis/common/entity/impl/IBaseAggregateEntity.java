package com.yhglobal.bee.mybatis.common.entity.impl;

public interface IBaseAggregateEntity {

    public Long getConcurrencyStamp();

    public void setConcurrencyStamp(Long concurrencyStamp);
}
