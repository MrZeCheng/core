package com.yhglobal.bee.mybatis.common.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @Date 2022-07-20 17:04:42
 * @Created by wangsheng
 */
@Mapper
public interface CommonMapper {
    @Select({
            "select  ${primaryKeyColumn} from ${tableName}",
            " where  ${condition}  order by ${primaryKeyColumn}  desc limit 1 "
    })
    Object getMaxIdByDate(@Param("tableName") String tableName ,
                          @Param("primaryKeyColumn") String primaryKeyColumn,
                       @Param("condition") String condition);
}
