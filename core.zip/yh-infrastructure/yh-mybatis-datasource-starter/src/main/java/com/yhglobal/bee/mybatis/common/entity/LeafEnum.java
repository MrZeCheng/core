package com.yhglobal.bee.mybatis.common.entity;

/**
 *  是否叶子节点 0 是 1 否
 *
 * @author weizecheng
 */
public enum LeafEnum {

    /**
     * 0 是叶子节点
     */
    YES(0),
    /**
     * 1 不是叶子节点
     */
    NO(1);

    LeafEnum(Integer status){
        this.status = status;
    }

    private Integer status;

    public Integer getStatus() {
        return status;
    }


}
