package com.yhglobal.bee.mybatis.common.entity;

import com.yhglobal.bee.mybatis.common.entity.impl.IBaseIdEntity;
import io.mybatis.provider.Entity;

/**
 * 
 *
 * @author zecheng.wei
 * @Date 2022/11/16 18:04
 */
public abstract class BaseIdEntity implements IBaseIdEntity {

    @Entity.Column(id = true)
    private Long id;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }
}
