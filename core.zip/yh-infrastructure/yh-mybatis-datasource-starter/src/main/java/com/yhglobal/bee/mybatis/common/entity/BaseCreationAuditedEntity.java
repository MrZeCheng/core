package com.yhglobal.bee.mybatis.common.entity;

import com.yhglobal.bee.mybatis.common.entity.impl.IBaseCreationAuditedEntity;
import io.mybatis.provider.Entity;

import java.util.Date;

public abstract class BaseCreationAuditedEntity extends BaseAggregateEntity implements IBaseCreationAuditedEntity {
    @Entity.Column(value = "CreatorId")
    private String creatorId;
    @Entity.Column(value = "CreationTime")
    private Date creationTime;

    @Override
    public String getCreatorId() {
        return creatorId;
    }

    @Override
    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }

    @Override
    public Date getCreationTime() {
        return creationTime;
    }

    @Override
    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }
}
