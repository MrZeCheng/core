package com.yhglobal.bee.mybatis.common.entity.impl;

import java.util.Date;

public interface IBaseCreationAuditedEntity {

    public String getCreatorId();

    public void setCreatorId(String creatorId);

    public Date getCreationTime();

    public void setCreationTime(Date creationTime);
}
