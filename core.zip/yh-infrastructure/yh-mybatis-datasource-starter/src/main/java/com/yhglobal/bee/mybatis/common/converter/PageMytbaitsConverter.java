package com.yhglobal.bee.mybatis.common.converter;

import com.github.pagehelper.PageInfo;
import com.yhglobal.bee.common.dto.PageBeeResponse;
import com.yhglobal.bee.common.dto.PageResponse;

/**
 * 命名错误使用PageMybatisConverter
 *
 * @author zecheng.wei
 * @Date 2023/6/6 11:12
 */
@Deprecated
public class PageMytbaitsConverter {

    @Deprecated
    public static <T> PageResponse<T> of(PageInfo<T> data) {
        return PageResponse.of(data.getList(),data.getTotal(),data.getPageSize(),data.getPageNum());
    }

    @Deprecated
    public static <T> PageBeeResponse<T> ofBee(PageInfo<T> data) {
        return PageBeeResponse.of(data.getList(),data.getTotal(),data.getPageSize(),data.getPageNum());
    }
}
