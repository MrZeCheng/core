package com.yhglobal.bee.mybatis.common.mapper;

import com.yhglobal.bee.mybatis.common.entity.BaseIdEntity;
import io.mybatis.mapper.base.EntityProvider;
import io.mybatis.provider.Caching;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Options;

/**
 * @author wangsheng
 * @Date 2022-11-18 17:34:50
 */
public interface YHIdMapper<T extends BaseIdEntity> extends YHMapper<T>{

    @Lang(Caching.class)
    @InsertProvider(type = EntityProvider.class, method = "insert")
    @Override
    @Options(useGeneratedKeys = true, keyProperty = "id" )
    int insert(T entity);

    @Lang(Caching.class)
    @InsertProvider(
            type = EntityProvider.class,
            method = "insertSelective"
    )
    @Override
    @Options(useGeneratedKeys = true, keyProperty = "id" )
    int insertSelective(T entity);
}
