package com.yhglobal.bee.mybatis.common.entity;

import com.yhglobal.bee.mybatis.common.entity.impl.IBaseAggregateEntity;
import io.mybatis.provider.Entity;

public abstract class BaseAggregateEntity extends BaseIdEntity implements IBaseAggregateEntity {

    @Entity.Column(value = "ConcurrencyStamp")
    private Long concurrencyStamp;

    @Override
    public Long getConcurrencyStamp() {
        return concurrencyStamp;
    }

    @Override
    public void setConcurrencyStamp(Long concurrencyStamp) {
        this.concurrencyStamp = concurrencyStamp;
    }
}
