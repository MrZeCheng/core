package com.yhglobal.bee.mybatis.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 
 * 
 * @author weizecheng
 * @date 2021/2/4 16:33
 */
@ConfigurationProperties(prefix = "yh.mybatis")
public class YhMybatisProperties {

    private Boolean enable = true;

    public Boolean getEnable() {
        return enable;
    }

    public YhMybatisProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    /**
     * 默认mysql
     */
    private String helperDialect = "mysql";

    /**
     * 是否开启数据权限拦截器
     */
    private boolean dataPermission = false;

    /**
     * 更新插入拦截
     */
    private boolean dataUpdate = false;

    /**
     * 逻辑删除 条件带入
     */
    private boolean dataTombstone = false;

    private boolean syncMinIdScan = false;


    public boolean isDataTombstone() {
        return dataTombstone;
    }

    public YhMybatisProperties setDataTombstone(boolean dataTombstone) {
        this.dataTombstone = dataTombstone;
        return this;
    }

    public boolean isDataUpdate() {
        return dataUpdate;
    }

    public YhMybatisProperties setDataUpdate(boolean dataUpdate) {
        this.dataUpdate = dataUpdate;
        return this;
    }

    public boolean isSyncMinIdScan() {
        return syncMinIdScan;
    }

    public YhMybatisProperties setSyncMinIdScan(boolean syncMinIdScan) {
        this.syncMinIdScan = syncMinIdScan;
        return this;
    }

    public String getHelperDialect() {
        return helperDialect;
    }

    public YhMybatisProperties setHelperDialect(String helperDialect) {
        this.helperDialect = helperDialect;
        return this;
    }

    public boolean isDataPermission() {
        return dataPermission;
    }

    public YhMybatisProperties setDataPermission(boolean dataPermission) {
        this.dataPermission = dataPermission;
        return this;
    }
}
