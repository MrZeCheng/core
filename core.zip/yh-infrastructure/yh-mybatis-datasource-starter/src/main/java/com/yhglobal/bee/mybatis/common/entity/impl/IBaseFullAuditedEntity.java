package com.yhglobal.bee.mybatis.common.entity.impl;

import java.util.Date;

public interface IBaseFullAuditedEntity {

    public Date getDeletionTime();

    public void setDeletionTime(Date deletionTime);

    public String getDeleterId();

    public void setDeleterId(String deleterId);

    public Integer getIsDeleted();

    public void setIsDeleted(Integer isDeleted);
}
