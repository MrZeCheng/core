package com.yhglobal.bee.mybatis.common.configure;

import com.github.pagehelper.PageInterceptor;
import com.yhglobal.bee.mybatis.common.interceptor.*;
import com.yhglobal.bee.mybatis.common.properties.YhMybatisProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.boot.autoconfigure.MybatisAutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Properties;


/**
 *
 *
 * @author weizecheng
 * @date 2021/2/4 16:43
 */
@Configuration
@EnableConfigurationProperties(YhMybatisProperties.class)
@ConditionalOnProperty(prefix = "yh.mybatis", name = "enable",havingValue = "true", matchIfMissing = true)

@AutoConfigureAfter(MybatisAutoConfiguration.class)
@RequiredArgsConstructor
@Slf4j
public class YhMybatisAutoConfigure {

    private final YhMybatisProperties yhMybatisProperties;

    private final List<SqlSessionFactory> sqlSessionFactoryList;


    @PostConstruct
    public void addDataPermissionInterceptor() {
        // 更新自动带时间戳拦截器
        if(yhMybatisProperties.isDataUpdate()){
            InsertInterceptor interceptor = new InsertInterceptor();
            Properties properties = new Properties();
            //先把一般方式配置的属性放进去
            interceptor.setProperties(properties);
            for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
                org.apache.ibatis.session.Configuration configuration = sqlSessionFactory.getConfiguration();
                if (!containsInterceptor(configuration, interceptor)) {
                    configuration.addInterceptor(interceptor);
                }
            }
            UpdateInterceptor interceptor1 = new UpdateInterceptor();
            //先把一般方式配置的属性放进去
            interceptor1.setProperties(properties);
            for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
                org.apache.ibatis.session.Configuration configuration = sqlSessionFactory.getConfiguration();
                if (!containsInterceptor(configuration, interceptor1)) {
                    configuration.addInterceptor(interceptor1);
                }
            }
        }
        // 逻辑删除拦截器
        if(yhMybatisProperties.isDataTombstone()){
            DateTombstoneInterceptor interceptor = new DateTombstoneInterceptor();
            Properties properties = new Properties();
            //先把一般方式配置的属性放进去
            interceptor.setProperties(properties);
            for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
                org.apache.ibatis.session.Configuration configuration = sqlSessionFactory.getConfiguration();
                if (!containsInterceptor(configuration, interceptor)) {
                    configuration.addInterceptor(interceptor);
                }
            }
        }
        // 先加载数据权限的拦截器
        if(yhMybatisProperties.isDataPermission()){
            DataPermissionInterceptor interceptor = new DataPermissionInterceptor();
            Properties properties = new Properties();
            //先把一般方式配置的属性放进去
            interceptor.setProperties(properties);
            for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
                org.apache.ibatis.session.Configuration configuration = sqlSessionFactory.getConfiguration();
                if (!containsInterceptor(configuration, interceptor)) {
                    configuration.addInterceptor(interceptor);
                }
            }
        }


        // 配置最小ID扫描
        if(yhMybatisProperties.isSyncMinIdScan()){
            MinIdScanInterceptor interceptor = new MinIdScanInterceptor();
            Properties properties = new Properties();
            interceptor.setProperties(properties);
            for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
                org.apache.ibatis.session.Configuration configuration = sqlSessionFactory.getConfiguration();
                if (!containsInterceptor(configuration, interceptor)) {
                    configuration.addInterceptor(interceptor);
                }
            }
        }

        // 在加载分页的拦截器
        PageInterceptor pageInterceptor = new PageInterceptor();
        Properties pageInterceptorProperties = new Properties();
        //先把一般方式配置的属性放进去
        pageInterceptorProperties.setProperty("helperDialect",yhMybatisProperties.getHelperDialect());
        pageInterceptorProperties.setProperty("reasonable","true");

        pageInterceptor.setProperties(pageInterceptorProperties);
        for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
            org.apache.ibatis.session.Configuration configuration = sqlSessionFactory.getConfiguration();
            if (!containsInterceptor(configuration, pageInterceptor)) {
                configuration.addInterceptor(pageInterceptor);
            }
        }


    }




    private boolean containsInterceptor(org.apache.ibatis.session.Configuration configuration, Interceptor interceptor) {
        try {
            // getInterceptors since 3.2.2
            return configuration.getInterceptors().contains(interceptor);
        } catch (Exception e) {
            return false;
        }
    }

}
