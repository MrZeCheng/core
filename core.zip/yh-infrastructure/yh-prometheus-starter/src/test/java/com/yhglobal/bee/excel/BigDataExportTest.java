package com.yhglobal.bee.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class BigDataExportTest {

    @Test
    public void bigDataTest(){
        Runtime runtime = Runtime.getRuntime();
        long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
        String address = "D:\\test4.xlsx";
        ExcelWriter excelWriter = EasyExcel.write(address, BigDataDto.class).build();
        WriteSheet writeSheet = EasyExcel.writerSheet("test").build();
        for (int i = 0; i < 1; i++) {
            List<BigDataDto> bigDataDtos =new ArrayList<>(1000000);
            for (int m = 0; m < 1000000; m++) {
                BigDataDto bigDataDto = new BigDataDto();
                bigDataDto.setEasOrderNo("2123");
                bigDataDto.setInOrderNo("564564");
                bigDataDto.setOutOrderNo("asdasdasd");
                bigDataDto.setTransferOrderNo("56+59+8ad");
                bigDataDto.setWmsInOrderNo("sadasase");
                bigDataDto.setWmsOutOrderNo("asdastwt");
                bigDataDtos.add(bigDataDto);
            }
            excelWriter.write(bigDataDtos, writeSheet);
            bigDataDtos.clear();
        }
        excelWriter.finish();
        long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
        System.out.println("Memory used: " + (usedMemoryAfter - usedMemoryBefore) + " bytes");
    }

    @Test
    public void bigDataInputTest(){
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        ExcelWriter excelWriter = EasyExcel.write(os, BigDataDto.class).build();
        WriteSheet writeSheet = EasyExcel.writerSheet("test").build();
        for (int i = 0; i < 100; i++) {
            List<BigDataDto> bigDataDtos =new ArrayList<>(10000);
            for (int m = 0; m < 10000; m++) {
                BigDataDto bigDataDto = new BigDataDto();
                bigDataDto.setEasOrderNo("2123");
                bigDataDto.setInOrderNo("564564");
                bigDataDto.setOutOrderNo("asdasdasd");
                bigDataDto.setTransferOrderNo("56+59+8ad");
                bigDataDto.setWmsInOrderNo("sadasase");
                bigDataDto.setWmsOutOrderNo("asdastwt");
                bigDataDtos.add(bigDataDto);
            }
            excelWriter.write(bigDataDtos, writeSheet);
            bigDataDtos.clear();
        }
        excelWriter.finish();
        InputStream inputStream = new ByteArrayInputStream(os.toByteArray());
        String filePath = "D:\\test789.xlsx";

// 创建输出流和缓冲区
        try(FileOutputStream outputStream = new FileOutputStream(filePath)){
            byte[] buffer = new byte[1024];
            int length;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
        }catch (Exception e){

        }
    }
}
