package com.yhglobal.bee.prometheus.common;

import io.github.mweirauch.micrometer.jvm.extras.ProcessMemoryMetrics;
import io.micrometer.core.instrument.binder.MeterBinder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 增加jvm的配置  https://github.com/mweirauch/micrometer-jvm-extras
 *
 * @author zecheng.wei
 * @Date 2023/6/18 19:11
 */

@Slf4j
@RequiredArgsConstructor
@Configuration
public class YhPrometheusConfig {

    @Bean
    public MeterBinder processMemoryMetrics() {
        return new ProcessMemoryMetrics();
    }

}
