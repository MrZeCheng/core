
CREATE TABLE `#operation_type#` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime DEFAULT NULL comment '创建时间',
  `modifiedDate` datetime DEFAULT NULL comment '创建时间',
  `dataVersion` bigint(20) DEFAULT NULL comment '版本号',
  `createdName` varchar(128) DEFAULT NULL comment '创建人',
  `modifiedName` varchar(128) DEFAULT NULL comment '修改人',
  `deleteFlag` tinyint(1) DEFAULT NULL comment '是否删除',
  `bizNumber` varchar(128) DEFAULT NULL comment '业务单号',
  `spareBizNumber` varchar(128) DEFAULT NULL comment '相关信息1',
  `spareBizNumber2` varchar(128) DEFAULT NULL comment '相关信息2',
  `description` text  comment '日志内容',
  PRIMARY KEY (`id`),
  KEY `index_biz_number` (`bizNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;

