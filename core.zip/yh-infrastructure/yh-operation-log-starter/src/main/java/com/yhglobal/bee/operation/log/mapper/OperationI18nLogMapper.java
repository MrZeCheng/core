package com.yhglobal.bee.operation.log.mapper;

import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.constant.base.MybatisBaseFieldConstant;
import com.yhglobal.bee.operation.log.client.OperationI18nLogVO;
import com.yhglobal.bee.operation.log.constant.LogConstant;
import com.yhglobal.bee.operation.log.entity.OperationI18nLogDO;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author yangkaiyun
 * @date 2021/5/14 17:49
 */
@Mapper
@DataInsertAndUpdate(depositIdFlag = false)
public interface OperationI18nLogMapper {

    String ALL_COLUMNS = MybatisBaseFieldConstant.BASE + "bizNumber,spareBizNumber,spareBizNumber2,logCode,logObjects";

    String TABLE_NAME = LogConstant.LOG_18N_TABLE_PREFIX + "${tableName}";

    @Insert({
            "insert into ",
            TABLE_NAME,
            "(createdDate, ",
            "modifiedDate, dataVersion, ",
            "createdName, modifiedName, ",
            "deleteFlag, bizNumber, ",
            "spareBizNumber,spareBizNumber2, logObjects,logCode)",
            "values (#{log.createdDate,jdbcType=TIMESTAMP}, ",
            "#{log.modifiedDate,jdbcType=TIMESTAMP}, #{log.dataVersion,jdbcType=BIGINT}, ",
            "#{log.createdName,jdbcType=VARCHAR}, #{log.modifiedName,jdbcType=VARCHAR}, ",
            "#{log.deleteFlag,jdbcType=INTEGER}, #{log.bizNumber,jdbcType=VARCHAR}, ",
            "#{log.spareBizNumber,jdbcType=VARCHAR},#{log.spareBizNumber2,jdbcType=VARCHAR},",
            "#{log.logObjects,jdbcType=LONGVARCHAR},#{log.logCode,jdbcType=INTEGER})"
    })
    int insert(@Param("log") OperationI18nLogDO operationLogI18nDO, @Param("tableName") String tableName);


    @Select({
            "select ",
            ALL_COLUMNS,
            "from ",
            TABLE_NAME,
            "where ",
            "bizNumber = #{bizNumber} "
    })
    List<OperationI18nLogVO> queryOperationLog(@Param("bizNumber") String bizNumber, @Param("tableName") String tableName);

}
