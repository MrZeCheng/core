package com.yhglobal.bee.operation.log.utils;

import com.yhglobal.bee.common.constant.operation.log.YhOperationLogI18nBaseI;
import com.yhglobal.bee.common.constant.operation.log.YhOperationLogI18nEnumBaseI;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.util.JacksonUtil;
import com.yhglobal.bee.operation.log.client.OperationI18nLogVO;
import com.yhglobal.bee.operation.log.entity.OperationI18nLogDO;
import com.yhglobal.bee.operation.log.service.OperationI18nLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 国际化日志工具类
 *
 * @author wengjunwei
 * @date 2022/11/7 17:02
 */
@Component
@RequiredArgsConstructor
public class OperationI18nLogUtil {

    private final OperationI18nLogService operationI18nLogService;

    public YhResponse addOperationLog(YhOperationLogI18nEnumBaseI yhOperationLogI18nEnumBaseI, String bizNumber, YhOperationLogI18nBaseI yhOperationLogI18nBaseI, Object... operationLogReq) {
        OperationI18nLogDO operationI18nLogDO = new OperationI18nLogDO();
        operationI18nLogDO.setBizNumber(bizNumber);
        operationI18nLogDO.setSpareBizNumber2("");
        operationI18nLogDO.setLogCode(yhOperationLogI18nEnumBaseI.getCode());
        operationI18nLogDO.setLogObjects(JacksonUtil.bean2Json(Arrays.asList(operationLogReq)));
        operationI18nLogDO.setSpareBizNumber("");
        return operationI18nLogService.insert(operationI18nLogDO, yhOperationLogI18nBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(YhOperationLogI18nEnumBaseI yhOperationLogI18nEnumBaseI, String bizNumber, YhOperationLogI18nBaseI yhOperationLogI18nBaseI) {
        OperationI18nLogDO operationI18nLogReq = new OperationI18nLogDO();
        operationI18nLogReq.setBizNumber(bizNumber);
        operationI18nLogReq.setLogCode(yhOperationLogI18nEnumBaseI.getCode());
        operationI18nLogReq.setSpareBizNumber("");
        operationI18nLogReq.setSpareBizNumber2("");
        operationI18nLogReq.setLogObjects("[]");
        return operationI18nLogService.insert(operationI18nLogReq, yhOperationLogI18nBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(YhOperationLogI18nEnumBaseI yhOperationLogI18nEnumBaseI, String bizNumber, String spareBizNumber,YhOperationLogI18nBaseI yhOperationLogI18nBaseI, Object... operationLogReq) {
        OperationI18nLogDO operationI18nLogReq = new OperationI18nLogDO();
        operationI18nLogReq.setBizNumber(bizNumber);
        operationI18nLogReq.setLogCode(yhOperationLogI18nEnumBaseI.getCode());
        operationI18nLogReq.setLogObjects(JacksonUtil.bean2Json(Arrays.asList(operationLogReq)));
        operationI18nLogReq.setSpareBizNumber(spareBizNumber);
        operationI18nLogReq.setSpareBizNumber2("");
        return operationI18nLogService.insert(operationI18nLogReq, yhOperationLogI18nBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(YhOperationLogI18nEnumBaseI yhOperationLogI18nEnumBaseI, String bizNumber, String spareBizNumber, String spareBizNumber2, YhOperationLogI18nBaseI yhOperationLogI18nBaseI, Object... operationLogReq) {
        OperationI18nLogDO operationI18nLogReq = new OperationI18nLogDO();
        operationI18nLogReq.setBizNumber(bizNumber);
        operationI18nLogReq.setLogCode(yhOperationLogI18nEnumBaseI.getCode());
        operationI18nLogReq.setLogObjects(JacksonUtil.bean2Json(Arrays.asList(operationLogReq)));
        operationI18nLogReq.setSpareBizNumber(spareBizNumber);
        operationI18nLogReq.setSpareBizNumber2(spareBizNumber2);
        return operationI18nLogService.insert(operationI18nLogReq, yhOperationLogI18nBaseI.getOperationLogType());
    }


    public YhResponse addOperationLog(YhOperationLogI18nEnumBaseI yhOperationLogI18nEnumBaseI, String bizNumber, String spareBizNumber, YhOperationLogI18nBaseI yhOperationLogI18nBaseI) {
        OperationI18nLogDO operationI18nLogReq = new OperationI18nLogDO();
        operationI18nLogReq.setBizNumber(bizNumber);
        operationI18nLogReq.setLogCode(yhOperationLogI18nEnumBaseI.getCode());
        operationI18nLogReq.setLogObjects("[]");
        operationI18nLogReq.setSpareBizNumber(spareBizNumber);
        operationI18nLogReq.setSpareBizNumber2("");
        return operationI18nLogService.insert(operationI18nLogReq, yhOperationLogI18nBaseI.getOperationLogType());
    }

    public MultiResponse<OperationI18nLogVO> queryOperationLog(String bizNumber, YhOperationLogI18nBaseI yhOperationLogI18nBaseI) {
        return operationI18nLogService.queryOperationLog(bizNumber, yhOperationLogI18nBaseI.getOperationLogType());
    }
}
