package com.yhglobal.bee.operation.log.service.impl;

import com.yhglobal.bee.common.annotation.BeforeLog;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.operation.log.client.OperationLogQueryNumberCmd;
import com.yhglobal.bee.operation.log.client.OperationLogVO;
import com.yhglobal.bee.operation.log.dao.OperationLogDao;
import com.yhglobal.bee.operation.log.entity.OperationLogDO;
import com.yhglobal.bee.operation.log.service.OperationLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 操作日志impl
 *
 * @author yangkaiyun
 * @date 2021/5/14 16:37
 */
@Service
@RequiredArgsConstructor
@Slf4j
@BeforeLog
public class OperationLogServiceImpl implements OperationLogService {

    private final OperationLogDao operationLogDao;

    @Override
    public YhResponse addOperationLog(OperationLogDO operationLogDO, String logType) {
        operationLogDao.addOperationLog(operationLogDO, logType);
        return YhResponse.buildSuccess();
    }

    @Override
    public MultiResponse<OperationLogVO> queryOperationLog(String bizNumber, String operationLogType) {
        return MultiResponse.of(operationLogDao.queryOperationLog(bizNumber, operationLogType));
    }

    @Override
    public OperationLogVO queryOperationLog(String bizNumber, String createdName, String operationLogType) {
        return operationLogDao.queryOperationLogByCreatedName(bizNumber, createdName, operationLogType);
    }

    @Override
    public MultiResponse<OperationLogVO> queryOperationLogByCondition(String tableName, OperationLogQueryNumberCmd queryNumberCmd) {
        return MultiResponse.of(operationLogDao.queryOperationLogByCondition(tableName, queryNumberCmd));
    }


}
