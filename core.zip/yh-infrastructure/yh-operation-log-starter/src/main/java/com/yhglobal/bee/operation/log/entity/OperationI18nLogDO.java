package com.yhglobal.bee.operation.log.entity;


import com.yhglobal.bee.mybatis.common.entity.BaseMybatisEntity;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 国际化日志
 *
 * @author weizecheng
 * @date 2021/12/20 14:09
 */
@Data
@Accessors(chain = true)
public class OperationI18nLogDO extends BaseMybatisEntity implements Serializable {

    private String bizNumber;

    private String spareBizNumber;

    private String spareBizNumber2;

    private Integer logCode;

    private String logObjects;
}
