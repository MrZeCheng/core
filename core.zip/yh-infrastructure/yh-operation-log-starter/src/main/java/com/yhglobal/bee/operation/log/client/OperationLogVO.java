package com.yhglobal.bee.operation.log.client;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;

import java.util.Date;

@Data
public class OperationLogVO extends DTO {

    private String bizNumber;

    private String spareBizNumber;

    private String spareBizNumber2;

    private String description;

    private Date createdDate;

    private String createdName;


}
