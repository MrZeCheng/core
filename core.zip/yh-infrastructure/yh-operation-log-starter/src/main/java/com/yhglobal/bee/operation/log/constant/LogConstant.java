package com.yhglobal.bee.operation.log.constant;

/**
 * @author wengjunwei
 * @date 2022-11-04 12:02
 */
public interface LogConstant {

    /**
     * 普通日志表前缀
     */
    String LOG_TABLE_PREFIX = "yh_operation_log_";

    /**
     * 国际化日志表前缀
     */
    String LOG_18N_TABLE_PREFIX = "yh_operation_i18n_log_";

}
