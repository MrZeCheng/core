package com.yhglobal.bee.operation.log.service;


import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.operation.log.client.OperationI18nLogVO;
import com.yhglobal.bee.operation.log.entity.OperationI18nLogDO;

/**
 * 操作日志service
 *
 * @author yangkaiyun
 * @date 2021/5/14 16:35
 */
public interface OperationI18nLogService {

    YhResponse insert(OperationI18nLogDO operationI18nLogDO, String logType);

    MultiResponse<OperationI18nLogVO> queryOperationLog(String bizNumber, String operationLogType);

}
