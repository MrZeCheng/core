package com.yhglobal.bee.operation.log.service.impl;

import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.constant.operation.log.YhOperationLogBaseI;
import com.yhglobal.bee.common.constant.operation.log.YhOperationLogI18nBaseI;
import com.yhglobal.bee.common.util.FileUtil;
import com.yhglobal.bee.operation.log.constant.LogConstant;
import com.yhglobal.bee.operation.log.mapper.OperationLogBaseMapper;
import com.yhglobal.bee.operation.log.service.OperationLogBaseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
public class OperationLogBaseServiceImpl implements OperationLogBaseService {

    private final OperationLogBaseMapper operationLogBaseMapper;

    @Override
    public void initOperationLogSql() {
        Set<String> operationLogType = getOperationLogType();
        // 创建普通操作表
        if (operationLogType.size() > 0) {
            operationLogType.forEach(key -> {
                String tableName = LogConstant.LOG_TABLE_PREFIX + key.toLowerCase();
                int count = operationLogBaseMapper.countTableName(tableName);
                if (count == 0) {
                    String sql;
                    try {
                        sql = FileUtil.readFileAsString("operation_log.sql");
                        sql = sql.replaceAll("#operation_type#", tableName);
                        operationLogBaseMapper.createTableSql(sql);
                    } catch (Exception e) {
                        log.error("read sql file error = {}", e.getMessage());
                    }
                }
            });
        }
        // 创建多语言操作表
        Set<String> operationLogI18nType = getOperationLogI18nType();
            if (operationLogI18nType.size() > 0) {
            operationLogI18nType.forEach(key -> {
                String tableName = LogConstant.LOG_18N_TABLE_PREFIX + key.toLowerCase();
                int count = operationLogBaseMapper.countTableName(tableName);
                if (count == 0) {
                    String sql;
                    try {
                        sql = FileUtil.readFileAsString("operation_i18n_log.sql");
                        sql = sql.replaceAll("#operation_type#", tableName);
                        operationLogBaseMapper.createTableSql(sql);
                    } catch (Exception e) {
                        log.error("read sql file error = {}", e.getMessage());
                    }
                }
            });
        }
    }

    private Set<String> getOperationLogType() {
        // 可以做成配置扫描制定路径配置
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<? extends YhOperationLogBaseI>> set = reflections.getSubTypesOf(YhOperationLogBaseI.class);
        Set<String> typeSet = new HashSet<>();
        if (set != null && set.size() > 0) {
            set.forEach(key -> {
                // 只处理枚举类型
                if (key.isEnum()) {
                    YhOperationLogBaseI[] yhOperationLogBase = key.getEnumConstants();
                    for (YhOperationLogBaseI i : yhOperationLogBase) {
                        typeSet.add(i.getOperationLogType());
                    }
                }
            });
        }
        return typeSet;
    }

    private Set<String> getOperationLogI18nType() {
        // 可以做成配置扫描制定路径配置
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<? extends YhOperationLogI18nBaseI>> set = reflections.getSubTypesOf(YhOperationLogI18nBaseI.class);
        Set<String> typeSet = new HashSet<>();
        if (set != null && set.size() > 0) {
            set.forEach(key -> {
                // 只处理枚举类型
                if (key.isEnum()) {
                    YhOperationLogI18nBaseI[] yhOperationLogI18nBase = key.getEnumConstants();
                    for (YhOperationLogI18nBaseI i : yhOperationLogI18nBase) {
                        typeSet.add(i.getOperationLogType());
                    }
                }
            });
        }
        return typeSet;
    }
}
