package com.yhglobal.bee.operation.log.dao;

import com.yhglobal.bee.operation.log.client.OperationLogQueryNumberCmd;
import com.yhglobal.bee.operation.log.client.OperationLogVO;
import com.yhglobal.bee.operation.log.entity.OperationLogDO;
import com.yhglobal.bee.operation.log.mapper.OperationLogMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作日志DAO
 * @author yangkaiyun
 * @date 2021/5/14 17:44
 */
@Repository
@RequiredArgsConstructor
public class OperationLogDao {

    private final OperationLogMapper operationLogMapper;

    public int addOperationLog(OperationLogDO operationLogDO, String tableName){
        return operationLogMapper.addOperationLog(operationLogDO,tableName);
    }

    public List<OperationLogVO> queryOperationLog(String bizNumber, String tableName){
        return operationLogMapper.queryOperationLog(bizNumber,tableName);
    }

    public OperationLogVO queryOperationLogByCreatedName(String bizNumber, String createdName, String tableName){
        return operationLogMapper.queryOperationLogByCreatedName(bizNumber,createdName,tableName);
    }

    public List<OperationLogVO> queryOperationLogByCondition(String tableName, OperationLogQueryNumberCmd queryNumberCmd){
        return operationLogMapper.queryOperationLogByCondition(tableName, queryNumberCmd);
    }

}
