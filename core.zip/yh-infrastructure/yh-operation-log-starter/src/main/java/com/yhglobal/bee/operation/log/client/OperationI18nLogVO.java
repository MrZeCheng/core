package com.yhglobal.bee.operation.log.client;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class OperationI18nLogVO extends DTO {

    private String bizNumber;

    private String spareBizNumber;

    private String spareBizNumber2;

    private String description;

    private Integer logCode;

    private String logObjects;

    private Date createdDate;

    private String createdName;

}
