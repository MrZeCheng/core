package com.yhglobal.bee.operation.log.utils;

import com.yhglobal.bee.common.constant.operation.log.YhOperationLogBaseI;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.operation.log.client.OperationLogQueryNumberCmd;
import com.yhglobal.bee.operation.log.client.OperationLogVO;
import com.yhglobal.bee.operation.log.entity.OperationLogDO;
import com.yhglobal.bee.operation.log.service.OperationLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 普通日志工具类
 *
 * @author wengjunwei
 * @date 2022/11/7 17:01
 */
@Component
@RequiredArgsConstructor
public class OperationLogUtil {

    private final OperationLogService operationLogService;

    public YhResponse addOperationLog(String bizNumber, String description, String spareBizNumber, YhOperationLogBaseI yhOperationLogBaseI) {
        OperationLogDO operationLogDO  = new OperationLogDO();
        operationLogDO.setBizNumber(bizNumber);
        operationLogDO.setDescription(description);
        operationLogDO.setSpareBizNumber(spareBizNumber);
        operationLogDO.setSpareBizNumber2("");
        return operationLogService.addOperationLog(operationLogDO, yhOperationLogBaseI.getOperationLogType());
    }

    /**由就接口的操作日志切换到新的操作日志需要通过转换的过程，需要保留原有的时间 ，不然直接使用上面不带时间的方法
     * @param bizNumber
     * @param description
     * @param spareBizNumber
     * @param yhOperationLogBaseI
     * @param createDate
     * @return
     */
    public YhResponse addOperationLog(String bizNumber, String description, String spareBizNumber, YhOperationLogBaseI yhOperationLogBaseI, Date createDate) {
        OperationLogDO operationLogDO  = new OperationLogDO();
        operationLogDO.setBizNumber(bizNumber);
        operationLogDO.setDescription(description);
        operationLogDO.setSpareBizNumber(spareBizNumber);
        operationLogDO.setSpareBizNumber2("");
        operationLogDO.setCreatedDate(createDate);
        return operationLogService.addOperationLog(operationLogDO, yhOperationLogBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(String bizNumber, String description, String spareBizNumber,String spareBizNumber2, YhOperationLogBaseI yhOperationLogBaseI) {
        OperationLogDO operationLogDO  = new OperationLogDO();
        operationLogDO.setBizNumber(bizNumber);
        operationLogDO.setDescription(description);
        operationLogDO.setSpareBizNumber(spareBizNumber);
        operationLogDO.setSpareBizNumber2(spareBizNumber2);
        return operationLogService.addOperationLog(operationLogDO, yhOperationLogBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(String bizNumber, String description, YhOperationLogBaseI yhOperationLogBaseI) {
        OperationLogDO operationLogDO  = new OperationLogDO();
        operationLogDO.setBizNumber(bizNumber);
        operationLogDO.setDescription(description);
        operationLogDO.setSpareBizNumber("");
        operationLogDO.setSpareBizNumber2("");
        return operationLogService.addOperationLog(operationLogDO, yhOperationLogBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(String bizNumber, String description, YhOperationLogBaseI yhOperationLogBaseI, String createName) {
        OperationLogDO operationLogDO  = new OperationLogDO();
        operationLogDO.setBizNumber(bizNumber);
        operationLogDO.setDescription(description);
        operationLogDO.setSpareBizNumber("");
        operationLogDO.setSpareBizNumber2("");
        operationLogDO.setCreatedName(createName);
        return operationLogService.addOperationLog(operationLogDO, yhOperationLogBaseI.getOperationLogType());
    }

    public YhResponse addOperationLog(String bizNumber, String description, String spareBizNumber, YhOperationLogBaseI yhOperationLogBaseI, String createName) {
        OperationLogDO operationLogDO  = new OperationLogDO();
        operationLogDO.setBizNumber(bizNumber);
        operationLogDO.setDescription(description);
        operationLogDO.setSpareBizNumber(spareBizNumber);
        operationLogDO.setSpareBizNumber2("");
        operationLogDO.setCreatedName(createName);
        return operationLogService.addOperationLog(operationLogDO, yhOperationLogBaseI.getOperationLogType());
    }

    public MultiResponse<OperationLogVO> queryOperationLog(String bizNumber, YhOperationLogBaseI yhOperationLogBaseI) {
        return operationLogService.queryOperationLog(bizNumber, yhOperationLogBaseI.getOperationLogType());
    }

    public OperationLogVO queryOperationLogByCreatedName(String bizNumber, String createdName, YhOperationLogBaseI yhOperationLogBaseI) {
        return operationLogService.queryOperationLog(bizNumber, createdName, yhOperationLogBaseI.getOperationLogType());
    }

    public MultiResponse<OperationLogVO> queryOperationLog(String bizNumber, String spareBizNumber, YhOperationLogBaseI yhOperationLogBaseI) {
        OperationLogQueryNumberCmd queryNumberCmd = new OperationLogQueryNumberCmd();
        queryNumberCmd.setSpareBizNumber(spareBizNumber);
        queryNumberCmd.setBizNumber(bizNumber);
        return operationLogService.queryOperationLogByCondition(yhOperationLogBaseI.getOperationLogType(), queryNumberCmd);
    }

    public MultiResponse<OperationLogVO> queryOperationLog(String bizNumber, String spareBizNumber, String spareBizNumber2, YhOperationLogBaseI yhOperationLogBaseI) {
        OperationLogQueryNumberCmd queryNumberCmd = new OperationLogQueryNumberCmd();
        queryNumberCmd.setSpareBizNumber(spareBizNumber);
        queryNumberCmd.setBizNumber(bizNumber);
        queryNumberCmd.setStandbyBizNumber(spareBizNumber2);
        return operationLogService.queryOperationLogByCondition(yhOperationLogBaseI.getOperationLogType(), queryNumberCmd);
    }
}
