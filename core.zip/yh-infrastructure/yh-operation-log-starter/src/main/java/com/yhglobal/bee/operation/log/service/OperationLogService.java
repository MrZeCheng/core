package com.yhglobal.bee.operation.log.service;


import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.operation.log.client.OperationLogQueryNumberCmd;
import com.yhglobal.bee.operation.log.client.OperationLogVO;
import com.yhglobal.bee.operation.log.entity.OperationLogDO;

/**
 * 操作日志service
 *
 * @author yangkaiyun
 * @date 2021/5/14 16:35
 */
public interface OperationLogService {

    YhResponse addOperationLog(OperationLogDO operationLogDO, String logType);

    MultiResponse<OperationLogVO> queryOperationLog(String bizNumber, String operationLogType);

    OperationLogVO queryOperationLog(String bizNumber, String createdName, String operationLogType);

    MultiResponse<OperationLogVO> queryOperationLogByCondition(String tableName, OperationLogQueryNumberCmd queryNumberCmd);
}
