package com.yhglobal.bee.operation.log.service;

public interface OperationLogBaseService {

    void initOperationLogSql();

}
