package com.yhglobal.bee.operation.log.mapper.provider;

import com.yhglobal.bee.operation.log.client.OperationLogQueryNumberCmd;
import com.yhglobal.bee.operation.log.mapper.OperationLogMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

/**
 * @author yangkaiyun
 * @date 2021/5/27 16:40
 */
public class OperationLogMapperProvider {


    public String queryOperationLogByNumber(@Param("tableName") String tableName, @Param("query") OperationLogQueryNumberCmd queryNumberCmd) {
        return new SQL() {
            {
                SELECT(OperationLogMapper.ALL_COLUMNS);
                FROM(OperationLogMapper.TABLE_NAME);
                if (StringUtils.isNotBlank(queryNumberCmd.getBizNumber())) {
                    WHERE("bizNumber = #{query.bizNumber}");
                }
                if (StringUtils.isNotBlank(queryNumberCmd.getSpareBizNumber())) {
                    WHERE("spareBizNumber = #{query.spareBizNumber}");
                }
                if (StringUtils.isNotBlank(queryNumberCmd.getStandbyBizNumber())) {
                    WHERE("spareBizNumber2 = #{query.standbyBizNumber}");
                }
            }
        }.toString();
    }

}
