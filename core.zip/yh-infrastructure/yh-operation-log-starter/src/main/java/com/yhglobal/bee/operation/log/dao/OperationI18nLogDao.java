package com.yhglobal.bee.operation.log.dao;

import com.yhglobal.bee.operation.log.client.OperationI18nLogVO;
import com.yhglobal.bee.operation.log.entity.OperationI18nLogDO;
import com.yhglobal.bee.operation.log.mapper.OperationI18nLogMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作日志DAO
 *
 * @author yangkaiyun
 * @date 2021/5/14 17:44
 */
@Repository
@RequiredArgsConstructor
public class OperationI18nLogDao {

    private final OperationI18nLogMapper operationI18nLogMapper;

    public int insert(OperationI18nLogDO operationLogDO, String tableName) {
        return operationI18nLogMapper.insert(operationLogDO,tableName);
    }

    public List<OperationI18nLogVO> queryOperationLog(String bizNumber, String tableName) {
        return operationI18nLogMapper.queryOperationLog(bizNumber,tableName);
    }

}
