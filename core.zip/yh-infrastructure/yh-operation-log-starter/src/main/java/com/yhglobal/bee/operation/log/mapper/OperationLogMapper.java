package com.yhglobal.bee.operation.log.mapper;

import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.constant.base.MybatisBaseFieldConstant;
import com.yhglobal.bee.operation.log.client.OperationLogQueryNumberCmd;
import com.yhglobal.bee.operation.log.client.OperationLogVO;
import com.yhglobal.bee.operation.log.constant.LogConstant;
import com.yhglobal.bee.operation.log.entity.OperationLogDO;
import com.yhglobal.bee.operation.log.mapper.provider.OperationLogMapperProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

/**
 * @author yangkaiyun
 * @date 2021/5/14 17:49
 */
@Mapper
@DataInsertAndUpdate(depositIdFlag = false)
public interface OperationLogMapper {

    String ALL_COLUMNS = MybatisBaseFieldConstant.BASE + "bizNumber, spareBizNumber,spareBizNumber2, description";

    String TABLE_NAME = LogConstant.LOG_TABLE_PREFIX + "${tableName}";

    @Insert({
            "insert into",
            TABLE_NAME,
            "(createdDate, ",
            "modifiedDate, dataVersion, ",
            "createdName, modifiedName, ",
            "deleteFlag, bizNumber, ",
            "spareBizNumber,spareBizNumber2, description)",
            "values (#{log.createdDate,jdbcType=TIMESTAMP}, ",
            "#{log.modifiedDate,jdbcType=TIMESTAMP}, #{log.dataVersion,jdbcType=BIGINT}, ",
            "#{log.createdName,jdbcType=VARCHAR}, #{log.modifiedName,jdbcType=VARCHAR}, ",
            "#{log.deleteFlag,jdbcType=INTEGER}, #{log.bizNumber,jdbcType=VARCHAR}, ",
            "#{log.spareBizNumber,jdbcType=VARCHAR},#{log.spareBizNumber2,jdbcType=VARCHAR},",
            "#{log.description,jdbcType=LONGVARCHAR})"
    })
    int addOperationLog(@Param("log") OperationLogDO operationLogDO, @Param("tableName") String tableName);

    @Select({
            "select ",
            ALL_COLUMNS,
            "from ",
            TABLE_NAME,
            "where ",
            "bizNumber = #{bizNumber} "
    })
    List<OperationLogVO> queryOperationLog(@Param("bizNumber") String bizNubmer, @Param("tableName") String tableName);

    @Select({
            "select ",
            ALL_COLUMNS,
            "from ",
            TABLE_NAME,
            "where ",
            "bizNumber = #{bizNumber} ",
            "and createdName =#{createdName} ",
            "order by id desc",
            "limit 1"
    })
    OperationLogVO queryOperationLogByCreatedName(@Param("bizNumber") String bizNubmer, @Param("createdName") String createdName, @Param("tableName") String tableName);

    @SelectProvider(type = OperationLogMapperProvider.class, method = "queryOperationLogByNumber")
    List<OperationLogVO> queryOperationLogByCondition(@Param("tableName") String tableName, @Param("query") OperationLogQueryNumberCmd queryNumberCmd);

}
