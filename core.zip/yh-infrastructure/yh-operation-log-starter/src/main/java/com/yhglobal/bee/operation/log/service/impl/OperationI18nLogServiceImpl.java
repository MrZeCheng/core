package com.yhglobal.bee.operation.log.service.impl;

import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.util.JacksonUtil;
import com.yhglobal.bee.operation.log.client.OperationI18nLogVO;
import com.yhglobal.bee.operation.log.dao.OperationI18nLogDao;
import com.yhglobal.bee.operation.log.entity.OperationI18nLogDO;
import com.yhglobal.bee.operation.log.runner.LogDescriptionConfig;
import com.yhglobal.bee.operation.log.service.OperationI18nLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Slf4j
public class OperationI18nLogServiceImpl implements OperationI18nLogService {

    private final OperationI18nLogDao operationI18nLogDao;

    @Override
    public YhResponse insert(OperationI18nLogDO operationI18nLogDO, String logType) {
        operationI18nLogDao.insert(operationI18nLogDO, logType);
        return YhResponse.buildSuccess();
    }

    @Override
    public MultiResponse<OperationI18nLogVO> queryOperationLog(String bizNumber, String operationLogType) {
        List<OperationI18nLogVO> i18nLogs = operationI18nLogDao.queryOperationLog(bizNumber, operationLogType);
        if (!i18nLogs.isEmpty()) {
            i18nLogs.forEach(item -> item.setDescription(LogDescriptionConfig.getDescriptionMap(item.getLogCode(), Objects.requireNonNull(JacksonUtil.json2List(item.getLogObjects(), Object.class)).toArray())));
        }
        return MultiResponse.of(i18nLogs);
    }

}
