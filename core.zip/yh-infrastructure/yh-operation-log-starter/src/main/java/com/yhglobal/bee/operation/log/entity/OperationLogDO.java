package com.yhglobal.bee.operation.log.entity;


import com.yhglobal.bee.mybatis.common.entity.BaseMybatisEntity;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@Accessors(chain = true)
public class OperationLogDO extends BaseMybatisEntity implements Serializable {

    private String bizNumber;

    private String spareBizNumber;

    private String spareBizNumber2;

    private String description;
}
