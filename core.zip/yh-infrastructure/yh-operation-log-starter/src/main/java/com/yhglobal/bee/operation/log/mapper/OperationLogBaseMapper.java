package com.yhglobal.bee.operation.log.mapper;

import org.apache.ibatis.annotations.*;


@Mapper
public interface OperationLogBaseMapper {

    @Update({
            "${sql}"
    })
    int createTableSql(@Param("sql") String sql);


    @Select({
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE table_name = #{mdmTableName}",
    })
    int countTableName(@Param("mdmTableName")String mdmTableName);

}
