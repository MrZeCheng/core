package com.yhglobal.bee.operation.log.client;

import com.yhglobal.bee.common.dto.Query;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class OperationLogQueryNumberCmd extends Query {

    /**
     * 单号
     */
    private String bizNumber;

    private String spareBizNumber;

    private String standbyBizNumber;

}
