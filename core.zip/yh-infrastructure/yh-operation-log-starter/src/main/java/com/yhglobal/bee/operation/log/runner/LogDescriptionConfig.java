package com.yhglobal.bee.operation.log.runner;

import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.constant.operation.log.YhOperationLogI18nEnumBaseI;
import com.yhglobal.bee.operation.log.service.OperationLogBaseService;
import lombok.RequiredArgsConstructor;
import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 国际化索引
 *
 * @author wengjunwei
 * @date 2022/11/4 15:24
 */
@Component
@RequiredArgsConstructor
@Order
public class LogDescriptionConfig implements CommandLineRunner {

    private final OperationLogBaseService operationLogBaseService;

    private final static Map<Integer, YhOperationLogI18nEnumBaseI> DESCRIPTION_MAP = new ConcurrentHashMap<>(16);

    @Override
    public void run(String... args) {
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<? extends YhOperationLogI18nEnumBaseI>> dataDictionaries = reflections.getSubTypesOf(YhOperationLogI18nEnumBaseI.class);
        for (Class<? extends YhOperationLogI18nEnumBaseI> dictionary : dataDictionaries) {
            if (dictionary.isEnum()) {
                YhOperationLogI18nEnumBaseI[] constants = dictionary.getEnumConstants();
                for (YhOperationLogI18nEnumBaseI constant : constants) {
                    DESCRIPTION_MAP.put(constant.getCode(), constant);
                }
            }
        }
        operationLogBaseService.initOperationLogSql();
    }

    public static String getDescriptionMap(Integer status, Object... objects) {
        return DESCRIPTION_MAP.get(status).getMessage(objects);
    }

}
