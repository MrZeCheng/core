package com.yhglobal.bee.mq.common.configure;

import com.yhglobal.bee.api.util.YhWebApiUtil;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.mq.common.properties.YhMqProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.ReturnedMessage;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.CommandLineRunner;

/**
 * 配置消息确认机制
 *
 * @author weizecheng
 * @date 2021/11/10 14:44
 */
@RequiredArgsConstructor
@Slf4j
public class YhMessageQueueConfig implements RabbitTemplate.ConfirmCallback, RabbitTemplate.ReturnsCallback, CommandLineRunner {

    private final RabbitTemplate rabbitTemplate;

    private final YhMqProperties yhMqProperties;

    private final YhWebApiUtil yhWebApiUtil;

    @Override
    public void run(String... args) {
        rabbitTemplate.setConfirmCallback(this);
        rabbitTemplate.setReturnsCallback(this);
    }

    @Override
    public void confirm(CorrelationData correlationData, boolean b, String s) {
        if (correlationData != null && StringUtils.isNotBlank(correlationData.getId())) {
            if (b) {
                log.info("MessageConfirmSuccess confirm = [{}]", correlationData.getId());
            } else {
                log.error("MessageConfirmFail confirm = [{}]", correlationData.getId());
                ReturnedMessage returnedMessage = correlationData.getReturned();
                if (returnedMessage != null) {
                    Message message = returnedMessage.getMessage();
                    if (message != null) {
                        String messageBody = new String(message.getBody());
                        log.error("MessageConfirmBodyFail body = [{}]", messageBody);
                        if (yhMqProperties.getDeadEnable()) {
                            if (StringUtils.isNotBlank(yhMqProperties.getDeadUrl())) {
                                try {
                                    yhWebApiUtil.sendWebJsonApi(YhResponse.class, messageBody, yhMqProperties.getDeadUrl())
                                            .subscribe(yhResponse -> {
                                                if (!yhResponse.isSuccess()) {
                                                    log.error("init code = {}, fail = {}", yhResponse.getErrCode(), yhResponse.getErrMessage());
                                                }
                                            });
                                } catch (Exception e) {
                                    log.error("http messageFailDeal error fail = {}", e.getMessage());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void returnedMessage(ReturnedMessage returnedMessage) {
        log.error("MessageReturned = [{}]", returnedMessage);
    }
}
