package com.yhglobal.bee.mq.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "yh.mq")
public class YhMqProperties {

    private Boolean enable = true;

    private Boolean confirms = true;

    /**
     * 启动死信路由
     */
    private Boolean deadEnable = false;
    /**
     * 死信路由地址
     */
    private String deadUrl;

    public Boolean getDeadEnable() {
        return deadEnable;
    }

    public YhMqProperties setDeadEnable(Boolean deadEnable) {
        this.deadEnable = deadEnable;
        return this;
    }

    public String getDeadUrl() {
        return deadUrl;
    }

    public YhMqProperties setDeadUrl(String deadUrl) {
        this.deadUrl = deadUrl;
        return this;
    }

    public Boolean getEnable() {
        return enable;
    }

    public YhMqProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    public Boolean getConfirms() {
        return confirms;
    }

    public YhMqProperties setConfirms(Boolean confirms) {
        this.confirms = confirms;
        return this;
    }
}
