package com.yhglobal.bee.mq.common.entity;

import com.yhglobal.bee.common.constant.mq.YhMessageQueueTypeI;
import com.yhglobal.bee.common.dto.DTO;

/**
 * 消费对象信息
 *
 * @author weizecheng
 * @date 2021/11/9 16:47
 */
public class YhMessageRequest<T,E extends YhMessageQueueTypeI> extends DTO implements YhMessageBaseI<T,E> {

    private T data;

    private String messageId;

    private E messageQueueType;
    /**
     * 错误消息
     */
    private String errorMessage;


    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public String getMessageId() {
        return messageId;
    }

    @Override
    public T getData() {
        return data;
    }

    @Override
    public E getMessageQueueType() {
        return messageQueueType;
    }

    public YhMessageRequest<T, E> setData(T data) {
        this.data = data;
        return this;
    }

    public YhMessageRequest<T, E> setMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public YhMessageRequest<T, E> setMessageQueueType(E messageQueueType) {
        this.messageQueueType = messageQueueType;
        return this;
    }

    public YhMessageRequest<T, E> setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
        return this;
    }

    public static <T, E extends YhMessageQueueTypeI> YhMessageRequest<T, E> buildMessage(String messageId, E yhMessageQueueTypeI, T data) {
        return  new YhMessageRequest<T,E>().setData(data).setMessageId(messageId).setMessageQueueType(yhMessageQueueTypeI);
    }
}
