package com.yhglobal.bee.mq.common.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.yhglobal.bee.api.util.YhWebApiUtil;
import com.yhglobal.bee.common.constant.mq.YhMessageQueueTypeI;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.util.JacksonUtil;
import com.yhglobal.bee.mq.common.constant.YhMessageQueueConstant;
import com.yhglobal.bee.mq.common.entity.YhMessageRequest;
import com.yhglobal.bee.mq.common.properties.YhMqProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 投递消息
 *
 * @author weizecheng
 * @date 2021/11/10 16:45
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class YhMessageUtil {

    private final RabbitTemplate rabbitTemplate;

    private final YhMqProperties yhMqProperties;

    private final YhWebApiUtil yhWebApiUtil;
    /**
     * 投递消息
     *
     * @author weizecheng
     * @date 2021/11/10 16:43
     */
    public <T, E extends YhMessageQueueTypeI> void sendMessage(YhMessageRequest<T,E> yhMessageRequest){
        // 1 交换机 2.队列名称 3.投递对象
        Message message = buildMessage(yhMessageRequest);
        rabbitTemplate.convertAndSend(yhMessageRequest.getMessageQueueType().getExchangeName(), yhMessageRequest.getMessageQueueType().getKey(), message);
    }

    /**
     * 投递消息 触发回调机制
     *
     * @author weizecheng
     * @date 2021/11/11 9:51
     */
    public <T, E extends YhMessageQueueTypeI> void sendMessage(YhMessageRequest<T,E> yhMessageRequest, MessagePostProcessor messagePostProcessor){
        Message message = buildMessage(yhMessageRequest);
        // 1 交换机 2.队列名称 3.投递对象 4.回调机制
        rabbitTemplate.convertAndSend(yhMessageRequest.getMessageQueueType().getExchangeName(), yhMessageRequest.getMessageQueueType().getKey(), message, messagePostProcessor);
    }


    /**
     * 消息失败处理
     *
     * 1. 当为0的时候 可以进入死信
     * 2. 支持重试 但不支持间隔
     *
     * @author weizecheng
     * @date 2021/11/15 10:17
     */
    public <T, E extends YhMessageQueueTypeI> void messageFailDeal(Message message, Channel channel, YhMessageRequest<T,E> yhMessageRequest, String errorMessage) throws IOException {
        Map<String, Object> map = message.getMessageProperties().getHeaders();
        if (map == null) {
            // 为空 看是否要进入死信队列
           log.info("messageFailDeal headers is NULL!");
            map = new HashMap<>(2);
        }
        Long retry = (Long)map.getOrDefault(YhMessageQueueConstant.YH_RETRY_HEADER, Long.valueOf("0"));
        if (retry == 0L){
           log.info("messageFailDeal headers retry is ZERO!");
           if (yhMqProperties.getDeadEnable()) {
               if (StringUtils.isNotBlank(yhMqProperties.getDeadUrl())) {
                   if (yhMessageRequest.getMessageQueueType().getPushDead()) {
                       try {
                           yhMessageRequest.setErrorMessage(errorMessage);
                           yhWebApiUtil.sendWebApi(YhResponse.class,yhMessageRequest,yhMqProperties.getDeadUrl())
                                   .subscribe(yhResponse -> {
                                       if (!yhResponse.isSuccess()) {
                                           log.error("init code = {}, fail = {}",yhResponse.getErrCode(), yhResponse.getErrMessage());
                                       }
                                   });
                       }catch (Exception e){
                           log.error("http messageFailDeal error fail = {}",e.getMessage());
                       }
                   }
               }
           }
           return;
        }
        Map<String,Object> objectMap = new HashMap<>(2);
        objectMap.put(YhMessageQueueConstant.YH_RETRY_HEADER, retry -1);
        AMQP.BasicProperties builder = new AMQP.BasicProperties.Builder().headers(objectMap).build();
        // 再次投递 进行重试
        yhMessageRequest.setErrorMessage(null);
        channel.basicPublish(yhMessageRequest.getMessageQueueType().getExchangeName(), yhMessageRequest.getMessageQueueType().getKey(), builder, JacksonUtil.bean2Json(yhMessageRequest).getBytes());
    }



    private <T, E extends YhMessageQueueTypeI> Message buildMessage(YhMessageRequest<T,E> yhMessageRequest){
        yhMessageRequest.setErrorMessage(null);
        String json = JacksonUtil.bean2Json(yhMessageRequest);
        log.info("send Message = {}",json);
        Message message = MessageBuilder.withBody(json.getBytes()).build();
        message.getMessageProperties().setMessageId(yhMessageRequest.getMessageId());
        // 设置过期时间
        if (yhMessageRequest.getMessageQueueType().getExpiration() > 0L) {
            message.getMessageProperties().setExpiration(yhMessageRequest.getMessageQueueType().getExpiration().toString());
        }
        // 设置重试次数
        if (yhMessageRequest.getMessageQueueType().getRetryNumber() > 0L) {
            message.getMessageProperties().setHeader(YhMessageQueueConstant.YH_RETRY_HEADER, yhMessageRequest.getMessageQueueType().getRetryNumber());
        }
        return message;
    }


    /**
     *  数据接收后进行转换
     *
     * @author weizecheng
     * @date 2021/11/10 17:05
     */
    public <T, E extends YhMessageQueueTypeI> YhMessageRequest<T,E> getMessageData(Message message, TypeReference<YhMessageRequest<T,E>> tTypeReference){
        log.info("getMessageData id = {}",message.getMessageProperties().getMessageId());
        byte[] body = message.getBody();
        String msg = new String(body);
        return JacksonUtil.json2Bean(msg,tTypeReference);
    }


}
