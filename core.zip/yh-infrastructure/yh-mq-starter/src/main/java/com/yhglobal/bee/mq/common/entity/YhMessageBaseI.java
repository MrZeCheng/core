package com.yhglobal.bee.mq.common.entity;

import com.yhglobal.bee.common.constant.mq.YhMessageQueueTypeI;

import java.io.Serializable;

public interface YhMessageBaseI<T,E extends YhMessageQueueTypeI> extends Serializable {

    /**
     * 消息唯一Id
     */
    public String getMessageId();

    /**
     * 消费的数据
     */
    public T getData();

    /**
     * 类型
     */
    public E getMessageQueueType();

}
