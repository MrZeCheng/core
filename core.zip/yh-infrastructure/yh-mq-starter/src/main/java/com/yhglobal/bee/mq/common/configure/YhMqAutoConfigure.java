package com.yhglobal.bee.mq.common.configure;

import com.yhglobal.bee.api.util.YhWebApiUtil;
import com.yhglobal.bee.mq.common.properties.YhMqProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * mq 基本配置
 *
 * @author weizecheng
 * @date 2021/11/10 17:08
 */
@Configuration
@EnableConfigurationProperties(YhMqProperties.class)
@ConditionalOnProperty(prefix = "yh.mq", name = "enable",havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
public class YhMqAutoConfigure {

    private final RabbitTemplate rabbitTemplate;

    private final YhMqProperties yhMqProperties;

    private final YhWebApiUtil yhWebApiUtil;

//    private final YhMqProperties yhMqProperties;


    @Bean(name = "yhMessageQueueConfig")
    @ConditionalOnProperty(prefix = "yh.mq", name = "confirms",havingValue = "true", matchIfMissing = true)
    @ConditionalOnMissingBean(name = "yhMessageQueueConfig")
    public YhMessageQueueConfig yhMessageQueueConfig() {
        return  new YhMessageQueueConfig(rabbitTemplate, yhMqProperties, yhWebApiUtil);
    }

//    @Bean
//    public Exchange deadExchange(){
//        return new DirectExchange(YhMessageQueueConstant.YH_DEAD_EXCHANGE);
//    }
//    /**
//     * 死信队列
//     * @return
//     */
//    @Bean
//    public Queue deadQueue(){
//        return new Queue(YhMessageQueueConstant.YH_DEAD_QUEUE);
//    }
//    /**
//     * 将死信交换器 与 死信队列绑定
//     * @return
//     */
//    @Bean
//    public Binding deadBindings(){
//        if (StringUtils.isBlank(yhMqProperties.getDeadKey())) {
//            throw new BusinessException(ErrorCode.DATA_ABNORMAL.getCode(),"yh.mq.dead-key is NULL!");
//        }
//        return new Binding(YhMessageQueueConstant.YH_DEAD_QUEUE, Binding.DestinationType.QUEUE,YhMessageQueueConstant.YH_DEAD_EXCHANGE, yhMqProperties.getDeadKey(),null);
//    }
}
