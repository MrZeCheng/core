package com.yhglobal.bee.mq.common.constant;

/**
 *  队列的基本配置
 *
 * @author weizecheng
 * @date 2021/11/11 11:15
 */
public interface YhMessageQueueConstant {

//    /**
//     * 死信交换机
//     */
//    String YH_DEAD_EXCHANGE = "yh.dead.exchange";
//
//    /**
//     * 死信队列
//     */
//    String YH_DEAD_QUEUE = "yh.dead.queue";

    /**
     * 重试次数头部
     */
    String YH_RETRY_HEADER = "yh-retry-header";
}
