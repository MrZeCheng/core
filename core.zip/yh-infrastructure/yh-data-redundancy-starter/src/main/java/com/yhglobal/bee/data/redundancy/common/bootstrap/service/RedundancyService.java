package com.yhglobal.bee.data.redundancy.common.bootstrap.service;

import com.yhglobal.bee.common.annotation.mybaits.DataRedundancy;
import com.yhglobal.bee.common.constant.redundancy.YhDataRedundancyI;

public interface RedundancyService {

    /**
     * 根据注解 往里面注册redis的值
     *
     * @author weizecheng
     * @date 2021/8/28 13:05
     */
    void redundancyRegistration(DataRedundancy dataRedundancy);

    /**
     * 获取冗余字段
     *
     *
     * @author weizecheng
     */
    String getRedundancyValue(String redundancyCode, YhDataRedundancyI yhDataRedundancyI);


    /**
     *  查找不到 冗余字段 进行初始化
     *
     * @author weizecheng
     * @date 2021/8/28 14:59
     */
    void initRedundancy(String redundancyValue);

    /**
     * 更新冗余字段
     *
     * @author weizecheng
     * @date 2021/8/28 14:57
     */
    void updateRedundancyRegistration(Class<?> c);

    /**
     * 更新单个冗余字段
     *
     * @author weizecheng
     * @date 2021/8/28 14:57
     */
    void updateRedundancyRegistrationByKey(Class<?> c,String code);
}
