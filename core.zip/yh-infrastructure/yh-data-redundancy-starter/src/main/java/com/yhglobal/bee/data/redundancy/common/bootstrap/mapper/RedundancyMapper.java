package com.yhglobal.bee.data.redundancy.common.bootstrap.mapper;

import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;


@Mapper
@DataTombstone
public interface RedundancyMapper {

    @Select({"SELECT  ${redundancyJson}  FROM ${redundancyTableName}"})
    List<Map<String,String>> findAll(@Param("redundancyJson")String redundancyJson,@Param("redundancyTableName")String redundancyTableName);

    @Select({"SELECT  ${redundancyJson}  FROM ${redundancyTableName} WHERE ${redundancyCode} = #{redundancyValue}"})
    Map<String,String> findByCode(@Param("redundancyJson")String redundancyJson,
                                  @Param("redundancyTableName")String redundancyTableName,
                                  @Param("redundancyCode")String redundancyCode,
                                  @Param("redundancyValue")String redundancyValue);

}
