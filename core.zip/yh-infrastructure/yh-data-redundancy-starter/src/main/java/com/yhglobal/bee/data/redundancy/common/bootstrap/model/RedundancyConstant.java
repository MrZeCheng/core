package com.yhglobal.bee.data.redundancy.common.bootstrap.model;

public class RedundancyConstant {

    public static String REDIS_REDUNDANCY_KEY =  "REDUNDANCY:";

}
