//package com.yhglobal.bee.data.redundancy.common.bootstrap.configure;
//
//import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
//import org.springframework.boot.actuate.endpoint.web.annotation.WebEndpoint;
//
//@WebEndpoint(id = "redundancy")
//public class RedundancyEndpoint {
//
//    @ReadOperation
//    public String endpointCustomRead(String content) {
//        return "你请求的内容: " + content;
//    }
//}
