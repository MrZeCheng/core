package com.yhglobal.bee.data.redundancy.common.bootstrap.controller;

import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.data.redundancy.common.bootstrap.model.RedundancyRequest;
import com.yhglobal.bee.data.redundancy.common.bootstrap.service.RedundancyService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("redundancy")
public class RedundancyController {

    private final RedundancyService redundancyService;

    @PostMapping(value = "/init")
    public YhResponse initRedundancyCode(@RequestBody RedundancyRequest redundancyRequest){
        redundancyService.initRedundancy(redundancyRequest.getRedundancyValue());
        return YhResponse.buildSuccess();
    }


}
