package com.yhglobal.bee.data.redundancy.common.bootstrap.configure;


import com.yhglobal.bee.data.redundancy.common.bootstrap.properties.YhRedundancyProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
/**
 * redis 基本配置
 *
 * @author weizecheng
 * @date 2021/2/7 10:33
 */
@Configuration
@EnableConfigurationProperties(YhRedundancyProperties.class)
public class YhRedundancyAutoConfigure {

}
