package com.yhglobal.bee.data.redundancy.common.bootstrap.service.impl;

import com.yhglobal.bee.api.util.YhWebApiUtil;
import com.yhglobal.bee.common.annotation.mybaits.DataRedundancy;
import com.yhglobal.bee.common.constant.redundancy.YhDataRedundancyI;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.dto.request.RequestLanguageThreadLocal;
import com.yhglobal.bee.common.util.I18nUtil;
import com.yhglobal.bee.data.redundancy.common.bootstrap.mapper.RedundancyMapper;
import com.yhglobal.bee.data.redundancy.common.bootstrap.model.RedundancyConstant;
import com.yhglobal.bee.data.redundancy.common.bootstrap.model.RedundancyRequest;
import com.yhglobal.bee.data.redundancy.common.bootstrap.properties.YhRedundancyProperties;
import com.yhglobal.bee.data.redundancy.common.bootstrap.service.RedundancyService;
import com.yhglobal.bee.redis.common.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class RedundancyServiceImpl implements RedundancyService {

    private final RedundancyMapper redundancyMapper;

    private final RedisService redisService;

    private final YhWebApiUtil yhWebApiUtil;

    private final YhRedundancyProperties yhRedundancyProperties;

    @Override
    public void redundancyRegistration(DataRedundancy dataRedundancy) {
        if (dataRedundancy !=null) {
            // 拼接查询对象例如
            List<Map<String,String>> list = redundancyMapper.findAll(getSelectSql(dataRedundancy),dataRedundancy.tableName());
            if (!list.isEmpty()) {
                // 查找出对象 进行循环注入对象
                list.forEach(i->putRedundancyRedis(dataRedundancy,i));
            }
        }
    }

    /**
     * 获取查询的json
     *
     * @author weizecheng
     * @date 2021/8/28 14:25
     */
    private String getSelectSql(DataRedundancy dataRedundancy){
        List<String> field = getEnumCode(dataRedundancy);
        if (field.isEmpty()) {
            return dataRedundancy.redundancyCode();
        }
        String json =  String.join(",",field);
        return json + ","+ dataRedundancy.redundancyCode();
    }

    /**
     * 获取需要注册的列表
     *
     * @author weizecheng
     * @date 2021/9/5 12:46
     */
    private List<String> getEnumCode(DataRedundancy dataRedundancy){
        Class<? extends YhDataRedundancyI> c = dataRedundancy.redundancyName();
        List<String> field = new ArrayList<>();
        if (c.isEnum()) {
            YhDataRedundancyI[] yhDataDictionaryI = c.getEnumConstants();
            for (YhDataRedundancyI y : yhDataDictionaryI) {
                field.add(y.getCode());
            }
        }
        return field;
    }



    @Override
    public String getRedundancyValue(String redundancyCode,YhDataRedundancyI yhDataRedundancyI) {
        if (StringUtils.isBlank(redundancyCode) || StringUtils.isBlank(yhDataRedundancyI.getCode())) {
            return "";
        }
        Object object = redisService.hget(RedundancyConstant.REDIS_REDUNDANCY_KEY+redundancyCode, getI18nCode(yhDataRedundancyI, yhDataRedundancyI.getCode()));
        if (object != null) {
            return object.toString();
        }
        if (yhRedundancyProperties.getEnable()) {
            try {
                yhWebApiUtil.sendWebApi(YhResponse.class,new RedundancyRequest()
                        .setRedundancyValue(yhDataRedundancyI.getCode()),"http://"+yhDataRedundancyI.getUrl()+"/redundancy/init")
                        .subscribe(yhResponse -> {
                            if (!yhResponse.isSuccess()) {
                                log.error("init fail = {}",yhResponse.getErrMessage());
                            }
                        });
            }catch (Exception e){
                log.error("http error fail = {}",e.getMessage());
            }
        }
        Object object1 = redisService.hget(RedundancyConstant.REDIS_REDUNDANCY_KEY+redundancyCode, getI18nCode(yhDataRedundancyI, yhDataRedundancyI.getCode()));
        return object1 == null ? "" : object1.toString();
    }

    private String getI18nCode(YhDataRedundancyI yhDataRedundancyI, String code){
        if(!yhDataRedundancyI.getGlobalization()){
            return code;
        }
        Locale locale = I18nUtil.getYhLocale(RequestLanguageThreadLocal.getRequestLanguage());
        if (Locale.ENGLISH.equals(locale)) {
            return code + yhRedundancyProperties.getEn();
        }
        if (Locale.TRADITIONAL_CHINESE.equals(locale)) {
            return code + yhRedundancyProperties.getChinaTW();
        }
        return code;
    }


    @Override
    public void initRedundancy(String redundancyValue) {
        Map<String, Object> extensionBeans = YhApplicationContext.getApplicationContext().getBeansWithAnnotation(DataRedundancy.class);
        if (!extensionBeans.isEmpty()) {
            extensionBeans.values().forEach(
                    dataRedundancy ->{
                        Class<?>  extensionClz = dataRedundancy.getClass();
                        DataRedundancy declaredAnnotation = extensionClz.getDeclaredAnnotation(DataRedundancy.class);
                        if (declaredAnnotation != null) {
                            boolean bool = false;
                            for (String s :  getEnumCode(declaredAnnotation)) {
                                if (s.equals(redundancyValue)) {
                                    bool = true;
                                    break;
                                }
                            }
                            if (bool) {
                                redundancyRegistration(declaredAnnotation);
                            }
                        }
                    });
        }
    }

    @Override
    public void updateRedundancyRegistration(Class<?> c) {
        DataRedundancy dataRedundancy = c.getDeclaredAnnotation(DataRedundancy.class);
        if (dataRedundancy !=null) {
            redundancyRegistration(dataRedundancy);
        }
    }

    /**
     * 往redis里注入 对象
     *
     * @author weizecheng
     * @date 2021/8/28 14:34
     */
    private void putRedundancyRedis(DataRedundancy dataRedundancy,Map<String,String> stringStringMap){
        String key = stringStringMap.get(dataRedundancy.redundancyCode());
        if (StringUtils.isNotBlank(key)) {
            Map<String,Object> newMap = new HashMap<>(12);
            for (String string :getEnumCode(dataRedundancy)) {
                newMap.put(string,stringStringMap.getOrDefault(string,""));
            }
            redisService.hmset(RedundancyConstant.REDIS_REDUNDANCY_KEY+key,newMap);
        }
    }


    @Override
    public void updateRedundancyRegistrationByKey(Class<?> c, String code) {
        DataRedundancy dataRedundancy = c.getDeclaredAnnotation(DataRedundancy.class);
        if (dataRedundancy != null) {
            Map<String,String> map = redundancyMapper.findByCode(getSelectSql(dataRedundancy),dataRedundancy.tableName(),dataRedundancy.redundancyCode(),code);
            if (map != null) {
                putRedundancyRedis(dataRedundancy,map);
            }
        }
    }
}
