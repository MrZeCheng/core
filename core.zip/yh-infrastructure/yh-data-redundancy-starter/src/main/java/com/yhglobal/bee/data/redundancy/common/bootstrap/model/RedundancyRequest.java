package com.yhglobal.bee.data.redundancy.common.bootstrap.model;

import com.yhglobal.bee.common.dto.DTO;

public class RedundancyRequest extends DTO {

    private String redundancyValue;

    public String getRedundancyValue() {
        return redundancyValue;
    }

    public RedundancyRequest setRedundancyValue(String redundancyValue) {
        this.redundancyValue = redundancyValue;
        return this;
    }
}
