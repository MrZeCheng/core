package com.yhglobal.bee.data.redundancy.common.bootstrap.util;

import com.yhglobal.bee.common.constant.redundancy.YhDataRedundancyI;
import com.yhglobal.bee.common.dto.constant.DefaultUserConstant;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.data.redundancy.common.bootstrap.service.RedundancyService;

/**
 * 数据字典
 *
 * @author weizecheng
 * @date 2021/8/24 17:58
 */
public class RedundancyUtil {

    private static volatile RedundancyService dataDictionaryService = null;

    /**
     * 获取值
     *
     * @author weizecheng
     * @date 2021/8/24 17:57
     */
    public static String getRedundancyField(String redundancyCode, YhDataRedundancyI yhDataRedundancyI){
        if(DefaultUserConstant.DEFAULT_USER.equals(redundancyCode)){
            return DefaultUserConstant.DEFAULT_USER;
        }
        return getRedundancyService().getRedundancyValue(redundancyCode,yhDataRedundancyI);
    }

    private static RedundancyService getRedundancyService(){
        if (dataDictionaryService == null) {
            synchronized (RedundancyUtil.class){
                if (dataDictionaryService == null) {
                    dataDictionaryService = YhApplicationContext.getBean(RedundancyService.class);
                }
            }
        }
        return dataDictionaryService;
    }

}
