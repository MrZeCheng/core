package com.yhglobal.bee.data.redundancy.common.bootstrap.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 
 * 
 * @author weizecheng
 * @date 2021/2/4 16:33
 */
@ConfigurationProperties(prefix = "yh.redundancy")
public class YhRedundancyProperties {

    private Boolean enable = false;

    private String en = "English";

    private String chinaTW = "ZhTW";

    public String getEn() {
        return en;
    }

    public YhRedundancyProperties setEn(String en) {
        this.en = en;
        return this;
    }

    public String getChinaTW() {
        return chinaTW;
    }

    public YhRedundancyProperties setChinaTW(String chinaTW) {
        this.chinaTW = chinaTW;
        return this;
    }


    public Boolean getEnable() {
        return enable;
    }

    public YhRedundancyProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }
}
