package com.yhglobal.bee.data.redundancy.common.bootstrap.configure;

import com.yhglobal.bee.common.annotation.mybaits.DataRedundancy;
import com.yhglobal.bee.common.constant.ProxyConstant;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.data.redundancy.common.bootstrap.service.RedundancyService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@RequiredArgsConstructor
@Order
@Slf4j
public class RedundancyRegistrationRedisConfig implements CommandLineRunner {

    private final RedundancyService redundancyService;

    @Override
    public void run(String... args) {
        Map<String, Object> extensionBeans = YhApplicationContext.getApplicationContext().getBeansWithAnnotation(DataRedundancy.class);
        if (!extensionBeans.isEmpty()) {
            extensionBeans.values().forEach(
                    dataRedundancy ->{
                        Class<?>  extensionClz = dataRedundancy.getClass();
                        String name = extensionClz.getName();
                        // 兼容代理模式
                        if (name.contains(ProxyConstant.PROXY_OBJECT_MARK)) {
                            String className = StringUtils.substringBefore(name, ProxyConstant.PROXY_OBJECT_MARK);
                            try {
                                final Class<?> clazz = Class.forName(className);
                                if (clazz.isAnnotationPresent(DataRedundancy.class)) {
                                    redundancyService.redundancyRegistration(clazz.getDeclaredAnnotation(DataRedundancy.class));
                                }
                            } catch (Exception ignore) {
                            }
                        }else {
                            DataRedundancy declaredAnnotation = extensionClz.getDeclaredAnnotation(DataRedundancy.class);
                            if (declaredAnnotation != null) {
                                redundancyService.redundancyRegistration(declaredAnnotation);
                            }
                        }
                    });
        }
    }

//    public static void main(String[] args) {
//        String methodName = StringUtils.substringBefore("com.yhglobal.scp.server.mdm.foundation.service.impl.CompanyServiceImpl$$EnhancerBySpringCGLIB$$369878d", "$$");
//        System.out.println(methodName);
//    }
}
