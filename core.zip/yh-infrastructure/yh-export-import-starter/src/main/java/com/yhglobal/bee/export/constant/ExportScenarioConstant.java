package com.yhglobal.bee.export.constant;

/**
 * 导出场景
 *
 * @author wengjunwei
 * @date 2022-11-02 15:56
 */
public interface ExportScenarioConstant {

    String EXPORT_ORDER = "export";
}
