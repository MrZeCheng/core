package com.yhglobal.bee.export.client;

import com.yhglobal.bee.common.dto.DTO;
import com.yhglobal.bee.common.util.constant.SyncCommonEnum;
import com.yhglobal.bee.export.configure.ExportTypeConfig;

import java.util.Date;

public class ExportResponsePageVO extends DTO {

    private Long id;
    /**
     * 导出类型
     */
    private String exportType;
    public String getExportTypeStr() {
        return ExportTypeConfig.getExportType(exportType).getExportType();
    }
    /**
     * 导出状态
     */
    private Integer exportStatus;

    public String getExportStatusStr() {
        return SyncCommonEnum.getEnumMessage(exportStatus);
    }
    /**
     * 服务名称
     */
    private String serverName;

    /**
     * 上传OSS的 objectName
     */
    private String objectName;
    /**
     * 导出单号
     */
    private String exportNo;
    /**
     * 请求的JSON对象
     */
    private String serverObject;

    private String serverObjectUrl;

    private Date createdDate;

    public Date getCreatedDate() {
        return createdDate;
    }

    public ExportResponsePageVO setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
        return this;
    }

    public String getServerObjectUrl() {
        return serverObjectUrl;
    }

    public ExportResponsePageVO setServerObjectUrl(String serverObjectUrl) {
        this.serverObjectUrl = serverObjectUrl;
        return this;
    }

    public Long getId() {
        return id;
    }

    public ExportResponsePageVO setId(Long id) {
        this.id = id;
        return this;
    }

    public String getExportType() {
        return exportType;
    }

    public ExportResponsePageVO setExportType(String exportType) {
        this.exportType = exportType;
        return this;
    }

    public Integer getExportStatus() {
        return exportStatus;
    }

    public ExportResponsePageVO setExportStatus(Integer exportStatus) {
        this.exportStatus = exportStatus;
        return this;
    }

    public String getServerName() {
        return serverName;
    }

    public ExportResponsePageVO setServerName(String serverName) {
        this.serverName = serverName;
        return this;
    }

    public String getObjectName() {
        return objectName;
    }

    public ExportResponsePageVO setObjectName(String objectName) {
        this.objectName = objectName;
        return this;
    }

    public String getExportNo() {
        return exportNo;
    }

    public ExportResponsePageVO setExportNo(String exportNo) {
        this.exportNo = exportNo;
        return this;
    }

    public String getServerObject() {
        return serverObject;
    }

    public ExportResponsePageVO setServerObject(String serverObject) {
        this.serverObject = serverObject;
        return this;
    }
}
