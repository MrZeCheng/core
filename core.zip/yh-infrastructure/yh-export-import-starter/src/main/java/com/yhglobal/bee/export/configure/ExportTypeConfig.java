package com.yhglobal.bee.export.configure;

import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.constant.export.YhExportTypeI;
import com.yhglobal.bee.export.domain.ExportDomain;
import com.yhglobal.bee.export.repository.ExportRecordMapper;
import lombok.RequiredArgsConstructor;
import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author zhengkaizhou
 * @date 2022/11/1 10:47
 */
@Component
@RequiredArgsConstructor
@Order
public class ExportTypeConfig implements CommandLineRunner {

    private final ExportDomain exportDomain;
    private final static Map<String, YhExportTypeI> EXPORT_TYPE = new ConcurrentHashMap<>(16);

    @Override
    public void run(String... args){
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<? extends YhExportTypeI>> dataDictionaries = reflections.getSubTypesOf(YhExportTypeI.class);
        for (Class<? extends YhExportTypeI> dictionary : dataDictionaries) {
            if (dictionary.isEnum()){
                YhExportTypeI[] constants = dictionary.getEnumConstants();
                for (YhExportTypeI constant : constants) {
                    EXPORT_TYPE.put(constant.getExportType(), constant);
                }
            }
        }
        exportDomain.init(ExportRecordMapper.TABLE_NAME);
    }

    public static YhExportTypeI getExportType(String exportType){
        return EXPORT_TYPE.get(exportType);
    }
}
