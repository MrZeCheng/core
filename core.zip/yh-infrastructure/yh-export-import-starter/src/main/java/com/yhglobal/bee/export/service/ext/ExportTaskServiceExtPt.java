package com.yhglobal.bee.export.service.ext;

import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.extension.ExtensionPointI;
import com.yhglobal.bee.export.entity.ExportRecordDO;

public interface ExportTaskServiceExtPt extends ExtensionPointI {

    YhResponse submitExportTask(ExportRecordDO exportRecordDO);

}
