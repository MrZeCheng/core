package com.yhglobal.bee.export.client;

import com.yhglobal.bee.common.dto.PageQuery;
import lombok.Data;

@Data
public class ExportQueryPageCmd extends PageQuery {

    /**
     * 导出类型
     */
    private String exportType;

    /**
     * 导出状态
     */
    private Integer exportStatus;

    /**
     * 创建人
     */
    private String createdName;

}
