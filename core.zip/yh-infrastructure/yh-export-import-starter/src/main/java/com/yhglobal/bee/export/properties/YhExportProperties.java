
package com.yhglobal.bee.export.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 导出配置
 *
 * @author wengjunwei
 * @date 2022/11/1 10:30
 */
@Data
@ConfigurationProperties(prefix = "yh.export")
public class YhExportProperties {

    private Boolean enable = true;
    private String retry;
    private String create;
    private String page;
    private String getUrl;
}

