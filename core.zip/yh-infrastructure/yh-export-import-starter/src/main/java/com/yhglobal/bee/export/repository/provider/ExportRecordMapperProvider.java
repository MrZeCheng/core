package com.yhglobal.bee.export.repository.provider;

import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.repository.ExportRecordMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

/**
 * @author yangkaiyun
 * @date 2021/5/27 16:40
 */
public class ExportRecordMapperProvider {

    public String findAllPage(@Param("order") ExportQueryPageCmd exportQueryPageCmd) {
        return new SQL() {
            {
                SELECT("id, exportType, exportStatus, serverName, objectName, exportNo, serverObject, createdDate");
                FROM(ExportRecordMapper.TABLE_NAME);

                if (StringUtils.isNotBlank(exportQueryPageCmd.getExportType())) {
                    WHERE("exportType = #{order.exportType}");
                }

                if (StringUtils.isNotBlank(exportQueryPageCmd.getCreatedName())) {
                    WHERE("createdName = #{order.createdName}");
                }

                if (exportQueryPageCmd.getExportStatus() != null && exportQueryPageCmd.getExportStatus() > 0) {
                    WHERE("exportStatus = #{order.exportStatus}");
                }

                ORDER_BY("id DESC");
            }
        }.toString();
    }
}
