package com.yhglobal.bee.export.client;

import com.yhglobal.bee.common.dto.DTO;

import java.io.Serializable;

/**
 * 下载记录
 *
 * @author weizecheng
 * @date 2021/12/8 14:53
 */
public class CreateExportRecordCmd extends DTO implements Serializable {

    /**
     * 导出类型
     */
    private String exportType;

    /**
     * 服务名称
     */
    private String serverName;

    /**
     * 请求的JSON对象
     */
    private String serverObject;

    /**
     * 语言
     */
    private String languageName;

    /**
     * 数据权限
     */
    private String dataPermission;

    public String getExportType() {
        return exportType;
    }

    public CreateExportRecordCmd setExportType(String exportType) {
        this.exportType = exportType;
        return this;
    }

    public String getServerName() {
        return serverName;
    }

    public CreateExportRecordCmd setServerName(String serverName) {
        this.serverName = serverName;
        return this;
    }

    public String getServerObject() {
        return serverObject;
    }

    public CreateExportRecordCmd setServerObject(String serverObject) {
        this.serverObject = serverObject;
        return this;
    }

    public String getLanguageName() {
        return languageName;
    }

    public CreateExportRecordCmd setLanguageName(String languageName) {
        this.languageName = languageName;
        return this;
    }

    public String getDataPermission() {
        return dataPermission;
    }

    public CreateExportRecordCmd setDataPermission(String dataPermission) {
        this.dataPermission = dataPermission;
        return this;
    }
}
