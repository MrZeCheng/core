package com.yhglobal.bee.export.service;


import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.export.client.CreateExportRecordCmd;
import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.client.ExportResponsePageVO;
import com.yhglobal.bee.export.client.RetryExportTaskCmd;
import com.yhglobal.bee.export.entity.ExportRecordDO;

import java.util.List;

public interface ExportRecordService {

    /**
     * 处理下载任务
     *
     * @author weizecheng
     * @date 2021/12/8 15:32
     */
    void dealExportRecordTask(ExportRecordDO exportRecordDO);

    /**
     * 获取等待执行的任务
     * taskNum 任务数量
     *
     * @author weizecheng
     * @date 2021/12/8 16:15
     */
    List<ExportRecordDO> findAllWaitTask(Integer taskNum);

    /**
     * 创建下载导出任务
     *
     * @author weizecheng
     * @date 2021/12/13 10:22
     */
    ExportRecordDO createExportRecord(CreateExportRecordCmd createExportRecordCmd);

    /**
     * 分页查找下载任务
     *
     * @author weizecheng
     * @date 2021/12/13 14:53
     */
    PageResponse<ExportResponsePageVO> findAllPage(ExportQueryPageCmd exportQueryPageCmd);

    /**
     * 重试任务
     *
     * @author weizecheng
     * @date 2021/12/13 15:31
     */
    SingleResponse<ExportRecordDO> retryExportTask(RetryExportTaskCmd retryExportTaskCmd);

    /**
     * 获取文件地址
     *
     * @author wengjunwei
     * @date 2022/11/1 15:53
     */
    String getFileAddress(String objectName);

    /**
     * 创建初始化表
     *
     * @author wengjunwei
     * @date 2022/11/4 17:32
     */
    YhResponse init(String tableName);
}
