package com.yhglobal.bee.export.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yhglobal.bee.common.annotation.redis.Redis;
import com.yhglobal.bee.common.annotation.redis.RedisGet;
import com.yhglobal.bee.common.constant.export.YhExportTypeI;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.dto.constant.DefaultUserConstant;
import com.yhglobal.bee.common.dto.extension.BizScenario;
import com.yhglobal.bee.common.dto.request.RequestUserUtil;
import com.yhglobal.bee.common.extension.ExtensionExecutor;
import com.yhglobal.bee.common.util.DateUtil;
import com.yhglobal.bee.common.util.FileUtil;
import com.yhglobal.bee.common.util.UUIDUtil;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.bee.common.util.constant.SyncCommonEnum;
import com.yhglobal.bee.export.client.CreateExportRecordCmd;
import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.client.ExportResponsePageVO;
import com.yhglobal.bee.export.client.RetryExportTaskCmd;
import com.yhglobal.bee.export.configure.ExportTypeConfig;
import com.yhglobal.bee.export.constant.ExportScenarioConstant;
import com.yhglobal.bee.export.dao.ExportRecordDao;
import com.yhglobal.bee.export.entity.ExportRecordDO;
import com.yhglobal.bee.export.service.ExportRecordService;
import com.yhglobal.bee.export.service.ext.ExportTaskServiceExtPt;
import com.yhglobal.bee.mybatis.common.converter.PageMytbaitsConverter;
import com.yhglobal.bee.oss.common.configure.OSSUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Redis
public class ExportRecordServiceImpl implements ExportRecordService {

    private final ExportRecordDao exportRecordDao;

    private final ExtensionExecutor extensionExecutor;

    private final OSSUtil ossUtil;

    private final RequestUserUtil requestUserUtil;

    @Override
    @Async("exportExecutor")
    public void dealExportRecordTask(ExportRecordDO exportRecordDO) {
        YhExportTypeI exportType = ExportTypeConfig.getExportType(exportRecordDO.getExportType());
        if (null == exportType) {
            log.info("yhExportTypeEnum is NULL");
            return;
        }
        int update = exportRecordDao.updateExportStatusLock(exportRecordDO.getId(), SyncCommonEnum.HANDLING.getStatus(),
                SyncCommonEnum.UNHANDLED.getStatus());
        if (update == 0) {
            log.info("exportStatusLock fail!");
            return;
        }
        YhResponse yhResponse = extensionExecutor.execute(ExportTaskServiceExtPt.class,
                BizScenario.valueOf(exportType.getExtensionName(), ExportScenarioConstant.EXPORT_ORDER),
                e -> e.submitExportTask(exportRecordDO));
        exportRecordDao.updateExportStatus(exportRecordDO.getId(), yhResponse.isSuccess() ?
                SyncCommonEnum.HANDLED.getStatus() : SyncCommonEnum.UNKNOWN.getStatus());
    }


    @Override
    public List<ExportRecordDO> findAllWaitTask(Integer taskNum) {
        return exportRecordDao.findAllLimit(taskNum, SyncCommonEnum.UNHANDLED.getStatus());
    }


    @Override
    public ExportRecordDO createExportRecord(CreateExportRecordCmd createExportRecordCmd) {
        YhExportTypeI exportType = ExportTypeConfig.getExportType(createExportRecordCmd.getExportType());
        ExportRecordDO exportRecordDO = new ExportRecordDO();
        exportRecordDO.setExportType(exportType.getExportType());
        exportRecordDO.setExportStatus(SyncCommonEnum.UNHANDLED.getStatus());
        exportRecordDO.setServerName(createExportRecordCmd.getServerName());
        exportRecordDO.setServerObject(createExportRecordCmd.getServerObject());
        exportRecordDO.setLanguageName(createExportRecordCmd.getLanguageName());
        exportRecordDO.setDataPermission(createExportRecordCmd.getDataPermission());
        String orderNo = UUIDUtil.generateShortUuid();
        exportRecordDO.setExportNo(orderNo);
        String object = DateUtil.date2str(new Date(), "yyyy/MM/dd");
        String objectName = object + "/" + exportType.getExportType() + "-" + orderNo + ".xlsx";
        log.info("createExportRecord objectName = {}", objectName);
        exportRecordDO.setObjectName(objectName);
        exportRecordDao.insert(exportRecordDO);
        return exportRecordDO;
    }

    @Override
    public PageResponse<ExportResponsePageVO> findAllPage(ExportQueryPageCmd exportQueryPageCmd) {
        if (!DefaultUserConstant.DEFAULT_USER.equals(requestUserUtil.getUserId())) {
            exportQueryPageCmd.setCreatedName(requestUserUtil.getUserId());
        }
        PageHelper.startPage(exportQueryPageCmd.getPageIndex(), exportQueryPageCmd.getPageSize());
        List<ExportResponsePageVO> exportResponsePages = exportRecordDao.findAllByPage(exportQueryPageCmd);
        if (!exportResponsePages.isEmpty()) {
            exportResponsePages.forEach(e -> {
                if (SyncCommonEnum.HANDLED.getStatus().equals(e.getExportStatus())) {
                    e.setServerObjectUrl(getFileAddress(e.getObjectName()));
                }
            });
        }
        return PageMytbaitsConverter.of(new PageInfo<>(exportResponsePages));
    }


    @Override
    public SingleResponse<ExportRecordDO> retryExportTask(RetryExportTaskCmd retryExportTaskCmd) {
        ExportRecordDO exportRecordDO = exportRecordDao.findById(retryExportTaskCmd.getId());
        if (exportRecordDO == null) {
            return SingleResponse.ofFailure(ErrorCode.DATA_ABNORMAL);
        }
        if (!SyncCommonEnum.UNKNOWN.getStatus().equals(exportRecordDO.getExportStatus())) {
            return SingleResponse.ofFailure(ErrorCode.SYS_ERROR);
        }
        int update = exportRecordDao.updateExportStatusLock(exportRecordDO.getId(), SyncCommonEnum.UNHANDLED.getStatus(),
                SyncCommonEnum.UNKNOWN.getStatus());

        if (update == 0) {
            return SingleResponse.ofFailure(ErrorCode.SYS_ERROR);
        }
        return SingleResponse.of(exportRecordDO);
    }

    @Override
    @RedisGet(redisKey = "EXPORT:", parameter = true, expire = 3200L)
    public String getFileAddress(String objectName) {
        return ossUtil.getUrlAddress(objectName).getData();
    }

    @Override
    public YhResponse init(String tableName) {
        int count = exportRecordDao.countTableName(tableName);
        if (count == 0) {
            String sql;
            try {
                sql = FileUtil.readFileAsString("export_record.sql");
                sql = sql.replaceAll("#operation_type#", tableName);
                exportRecordDao.createTableSql(sql);
            } catch (Exception e) {
                log.error("read sql file error = {}", e.getMessage());
            }
        }
        return YhResponse.buildSuccess();
    }
}
