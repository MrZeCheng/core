package com.yhglobal.bee.export.client;

import lombok.Data;

@Data
public class RetryExportTaskCmd {

    private Long id;
}
