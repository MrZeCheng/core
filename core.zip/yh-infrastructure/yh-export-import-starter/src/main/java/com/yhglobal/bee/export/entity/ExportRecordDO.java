package com.yhglobal.bee.export.entity;

import com.yhglobal.bee.mybatis.common.entity.BaseMybatisEntity;

import java.io.Serializable;

/**
 * 下载记录
 *
 * @author weizecheng
 * @date 2021/12/8 14:53
 */
public class ExportRecordDO extends BaseMybatisEntity implements Serializable {

    /**
     * 导出类型
     */
    private String exportType;

    /**
     * 导出状态
     */
    private Integer exportStatus;

    /**
     * 服务名称
     */
    private String serverName;

    /**
     * 上传OSS的 objectName
     */
    private String objectName;

    /**
     * 导出单号
     */
    private String exportNo;

    /**
     * 请求的JSON对象
     */
    private String serverObject;

    /**
     * 语言
     */
    private String languageName;

    /**
     * 数据权限
     */
    private String dataPermission;

    public String getExportType() {
        return exportType;
    }

    public ExportRecordDO setExportType(String exportType) {
        this.exportType = exportType;
        return this;
    }

    public Integer getExportStatus() {
        return exportStatus;
    }

    public ExportRecordDO setExportStatus(Integer exportStatus) {
        this.exportStatus = exportStatus;
        return this;
    }

    public String getServerName() {
        return serverName;
    }

    public ExportRecordDO setServerName(String serverName) {
        this.serverName = serverName;
        return this;
    }

    public String getObjectName() {
        return objectName;
    }

    public ExportRecordDO setObjectName(String objectName) {
        this.objectName = objectName;
        return this;
    }

    public String getExportNo() {
        return exportNo;
    }

    public ExportRecordDO setExportNo(String exportNo) {
        this.exportNo = exportNo;
        return this;
    }

    public String getServerObject() {
        return serverObject;
    }

    public ExportRecordDO setServerObject(String serverObject) {
        this.serverObject = serverObject;
        return this;
    }

    public String getLanguageName() {
        return languageName;
    }

    public ExportRecordDO setLanguageName(String languageName) {
        this.languageName = languageName;
        return this;
    }

    public String getDataPermission() {
        return dataPermission;
    }

    public ExportRecordDO setDataPermission(String dataPermission) {
        this.dataPermission = dataPermission;
        return this;
    }
}
