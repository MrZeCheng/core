package com.yhglobal.bee.export.dao;

import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.client.ExportResponsePageVO;
import com.yhglobal.bee.export.entity.ExportRecordDO;
import com.yhglobal.bee.export.repository.ExportRecordMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class ExportRecordDao {

    private final ExportRecordMapper exportRecordMapper;

    public int insert(ExportRecordDO exportRecordDO) {
        return exportRecordMapper.insert(exportRecordDO);
    }

    public int updateExportStatusLock(Long id, Integer exportStatus, Integer exportStatusLock) {
        return exportRecordMapper.updateExportStatusLock(id, exportStatus, exportStatusLock);
    }

    public int updateExportStatus(Long id, Integer exportStatus) {
        return exportRecordMapper.updateExportStatus(id, exportStatus);
    }

    public ExportRecordDO findById(Long id) {
        return exportRecordMapper.findById(id);
    }

    public List<ExportRecordDO> findAllLimit(Integer limitNum, Integer exportStatus) {
        return exportRecordMapper.findAllLimit(limitNum, exportStatus);
    }

    public List<ExportResponsePageVO> findAllByPage(ExportQueryPageCmd exportQueryPageCmd) {
        return exportRecordMapper.findAllByPage(exportQueryPageCmd);
    }

    public int countTableName(String tableName) {
        return exportRecordMapper.countTableName(tableName);
    }

    public void createTableSql(String sql) {
        exportRecordMapper.createTableSql(sql);
    }
}
