package com.yhglobal.bee.export.repository;

import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import com.yhglobal.bee.common.constant.base.MybatisBaseFieldConstant;
import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.client.ExportResponsePageVO;
import com.yhglobal.bee.export.entity.ExportRecordDO;
import com.yhglobal.bee.export.repository.provider.ExportRecordMapperProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
@DataInsertAndUpdate(excludeUpdateMethods = {"createTableSql"})
@DataTombstone(excludeMethods = {"countTableName"})
public interface ExportRecordMapper {

    String TABLE_NAME = "yh_common_export_record";

    String ALL_COLUMNS = MybatisBaseFieldConstant.BASE +
            "exportType, exportStatus, serverName, objectName, exportNo, serverObject, languageName, dataPermission";

    @Insert({
            "insert into yh_common_export_record (createdDate, ",
            "modifiedDate, dataVersion, ",
            "createdName, modifiedName, ",
            "deleteFlag, exportType, ",
            "exportStatus, serverName, ",
            "objectName, exportNo, ",
            "serverObject, languageName, dataPermission)",
            "values (#{createdDate,jdbcType=TIMESTAMP}, ",
            "#{modifiedDate,jdbcType=TIMESTAMP}, #{dataVersion,jdbcType=BIGINT}, ",
            "#{createdName,jdbcType=VARCHAR}, #{modifiedName,jdbcType=VARCHAR}, ",
            "#{deleteFlag,jdbcType=INTEGER}, #{exportType,jdbcType=VARCHAR}, ",
            "#{exportStatus,jdbcType=INTEGER}, #{serverName,jdbcType=VARCHAR}, ",
            "#{objectName,jdbcType=VARCHAR}, #{exportNo,jdbcType=VARCHAR}, ",
            "#{serverObject,jdbcType=VARCHAR}, #{languageName,jdbcType=VARCHAR}, ",
            "#{dataPermission,jdbcType=VARCHAR})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(ExportRecordDO exportRecordDO);

    @Update({
            "update ", TABLE_NAME,
            "set ",
            "exportStatus = #{exportStatus}",
            "where id = #{id} AND exportStatus = #{exportStatusLock}",
    })
    int updateExportStatusLock(@Param("id") Long id, @Param("exportStatus") Integer exportStatus, @Param("exportStatusLock") Integer exportStatusLock);

    @Update({
            "update ", TABLE_NAME,
            "set ",
            "exportStatus = #{exportStatus}",
            "where id = #{id} ",
    })
    int updateExportStatus(@Param("id") Long id, @Param("exportStatus") Integer exportStatus);

    @Select({
            "select ",
            ALL_COLUMNS,
            "from ",
            TABLE_NAME,
            "where ",
            "id = #{id} "
    })
    ExportRecordDO findById(@Param("id") Long id);

    @Select({
            "select ",
            ALL_COLUMNS,
            "from ",
            TABLE_NAME,
            "where ",
            "exportStatus = #{exportStatus} limit #{limitNum} "
    })
    List<ExportRecordDO> findAllLimit(@Param("limitNum") Integer limitNum, @Param("exportStatus") Integer exportStatus);

    @SelectProvider(type = ExportRecordMapperProvider.class, method = "findAllPage")
    List<ExportResponsePageVO> findAllByPage(@Param("order") ExportQueryPageCmd exportQueryPageCmd);

    @Select({
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE table_name = #{tableName}",
    })
    int countTableName(@Param("tableName") String tableName);

    @Update({
            "${sql}"
    })
    int createTableSql(@Param("sql") String sql);
}
