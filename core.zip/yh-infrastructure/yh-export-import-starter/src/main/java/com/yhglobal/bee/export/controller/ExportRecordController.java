package com.yhglobal.bee.export.controller;

import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.export.client.CreateExportRecordCmd;
import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.client.ExportResponsePageVO;
import com.yhglobal.bee.export.client.GetUrlCmd;
import com.yhglobal.bee.export.client.RetryExportTaskCmd;
import com.yhglobal.bee.export.domain.ExportDomain;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequiredArgsConstructor
@Slf4j
public class ExportRecordController {

    private final ExportDomain exportDomain;

    /**
     * 重试任务
     *
     * @author wengjunwei
     * @date 2022/11/1 15:27
     */
    @PostMapping(value = "${yh.export.retry:/export/retry}")
    public YhResponse retryExportTask(@RequestBody RetryExportTaskCmd retryExportTaskCmd) {
        return exportDomain.retryExportTask(retryExportTaskCmd);
    }


    /**
     * 创建下载任务
     *
     * @author wengjunwei
     * @date 2022/11/1 15:27
     */
    @PostMapping(value = "${yh.export.create:/export/create}")
    public YhResponse createExportRecord(@RequestBody CreateExportRecordCmd createExportRecordCmd) {
        return exportDomain.createExportRecord(createExportRecordCmd);
    }

    /**
     * 分页查找下载任务
     *
     * @author weizecheng
     * @date 2021/12/13 14:53
     */
    @PostMapping(value = "${yh.export.page:/export/page}")
    public PageResponse<ExportResponsePageVO> findAllPage(@RequestBody ExportQueryPageCmd exportQueryPageCmd) {
        return exportDomain.findAllPage(exportQueryPageCmd);
    }

    /**
     * 获取下载路径
     *
     * @author wengjunwei
     * @date 2022/11/1 15:27
     */
    @PostMapping(value = "${yh.export.getUrl:/export/getUrl}")
    public SingleResponse<String> getUrl(@RequestBody GetUrlCmd getUrlCmd) {
        return exportDomain.getUrl(getUrlCmd);
    }

}
