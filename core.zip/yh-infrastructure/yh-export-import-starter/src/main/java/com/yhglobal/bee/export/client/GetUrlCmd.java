package com.yhglobal.bee.export.client;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;

/**
 * @author wengjunwei
 * @date 2022-01-21 16:44
 */
@Data
public class GetUrlCmd extends DTO {

    /**
     * 上传到OSS的objectName
     */
    private String objectName;
}
