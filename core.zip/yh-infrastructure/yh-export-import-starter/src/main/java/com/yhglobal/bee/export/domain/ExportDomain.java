package com.yhglobal.bee.export.domain;

import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.export.client.CreateExportRecordCmd;
import com.yhglobal.bee.export.client.ExportQueryPageCmd;
import com.yhglobal.bee.export.client.ExportResponsePageVO;
import com.yhglobal.bee.export.client.GetUrlCmd;
import com.yhglobal.bee.export.client.RetryExportTaskCmd;
import com.yhglobal.bee.export.entity.ExportRecordDO;
import com.yhglobal.bee.export.service.ExportRecordService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class ExportDomain {

    private final ExportRecordService exportRecordService;

    public YhResponse retryExportTask(RetryExportTaskCmd retryExportTaskCmd) {
        SingleResponse<ExportRecordDO> singleResponse = exportRecordService.retryExportTask(retryExportTaskCmd);
        if (!singleResponse.isSuccess()) {
            return YhResponse.buildFailure(singleResponse.getErrCode(), singleResponse.getErrMessage());
        }
        exportRecordService.dealExportRecordTask(singleResponse.getData());
        return YhResponse.buildSuccess();
    }

    public YhResponse createExportRecord(CreateExportRecordCmd createExportRecordCmd) {
        ExportRecordDO exportRecordDO = exportRecordService.createExportRecord(createExportRecordCmd);
        exportRecordService.dealExportRecordTask(exportRecordDO);
        return YhResponse.buildSuccess();
    }

    public void syncSubmitTask() {
        List<ExportRecordDO> list = exportRecordService.findAllWaitTask(2);
        if (!list.isEmpty()) {
            log.info("sync-export-task size = {}", list.size());
            list.forEach(exportRecordService::dealExportRecordTask);
        }
    }

    /**
     * 分页查找下载任务
     *
     * @author weizecheng
     * @date 2021/12/13 14:53
     */
    public PageResponse<ExportResponsePageVO> findAllPage(ExportQueryPageCmd exportQueryPageCmd) {
        return exportRecordService.findAllPage(exportQueryPageCmd);
    }


    public SingleResponse<String> getUrl(GetUrlCmd getUrlCmd) {
        return SingleResponse.of(exportRecordService.getFileAddress(getUrlCmd.getObjectName()));
    }

    public YhResponse init(String tableName) {
        return  exportRecordService.init(tableName);
    }
}
