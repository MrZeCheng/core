CREATE TABLE `#operation_type#` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  `dataVersion` bigint(20) DEFAULT NULL,
  `createdName` varchar(128) DEFAULT NULL,
  `modifiedName` varchar(128) DEFAULT NULL,
  `deleteFlag` int(1) DEFAULT NULL,
  `exportType` varchar(255) DEFAULT NULL COMMENT '导出类型',
  `exportStatus` int(1) DEFAULT NULL COMMENT '导出状态',
  `serverName` varchar(128) DEFAULT NULL COMMENT '服务名称',
  `objectName` varchar(255) DEFAULT NULL COMMENT '上传OSS的 objectName',
  `exportNo` varchar(128) DEFAULT NULL COMMENT '导出单号',
  `serverObject` varchar(255) DEFAULT NULL COMMENT '请求的JSON对象',
  `languageName` varchar(128) DEFAULT NULL COMMENT '语言',
  `dataPermission` varchar(255) DEFAULT NULL COMMENT '数据权限',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
