package com.yhglobal.bee.excel;

import com.alibaba.excel.annotation.ExcelProperty;

public class BigDataDto {

    @ExcelProperty(value = "XPS调拨订单")
    private String transferOrderNo;

    @ExcelProperty(value = "EAS调拨订单")
    private String easOrderNo;

    @ExcelProperty(value = "出库通知单号")
    private String outOrderNo;

    @ExcelProperty(value = "入库通知单号")
    private String inOrderNo;

    @ExcelProperty(value = "wms出库单号")
    private String wmsOutOrderNo;

    @ExcelProperty(value = "wms入库单号")
    private String wmsInOrderNo;

    public String getTransferOrderNo() {
        return transferOrderNo;
    }

    public void setTransferOrderNo(String transferOrderNo) {
        this.transferOrderNo = transferOrderNo;
    }

    public String getEasOrderNo() {
        return easOrderNo;
    }

    public void setEasOrderNo(String easOrderNo) {
        this.easOrderNo = easOrderNo;
    }

    public String getOutOrderNo() {
        return outOrderNo;
    }

    public void setOutOrderNo(String outOrderNo) {
        this.outOrderNo = outOrderNo;
    }

    public String getInOrderNo() {
        return inOrderNo;
    }

    public void setInOrderNo(String inOrderNo) {
        this.inOrderNo = inOrderNo;
    }

    public String getWmsOutOrderNo() {
        return wmsOutOrderNo;
    }

    public void setWmsOutOrderNo(String wmsOutOrderNo) {
        this.wmsOutOrderNo = wmsOutOrderNo;
    }

    public String getWmsInOrderNo() {
        return wmsInOrderNo;
    }

    public void setWmsInOrderNo(String wmsInOrderNo) {
        this.wmsInOrderNo = wmsInOrderNo;
    }
}
