//package com.yhglobal.bee.excel.common;
//
//import com.alibaba.excel.EasyExcel;
//import com.yhglobal.bee.common.util.JacksonUtil;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
//public class Test {
//
//    public static void main(String[] args) {
//        String fileName = "C:\\Users\\zecheng.wei\\Downloads\\BCDFT210524_16219394-Stock-其它城市仓租.xlsx";
//        // 这里 只要，然后读取第一个sheet 同步读取会自动finish
//        List<Map<String, String>> list = new ArrayList<>();
//        EasyExcel.read(fileName, new NoModelDataListener(list)).sheet().doRead();
//        System.out.println(JacksonUtil.bean2Json(list));
//    }
//}
