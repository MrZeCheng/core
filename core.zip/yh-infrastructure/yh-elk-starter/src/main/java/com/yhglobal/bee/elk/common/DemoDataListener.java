//package com.yhglobal.bee.excel.common;
//
//import com.alibaba.excel.context.AnalysisContext;
//import com.alibaba.excel.event.AnalysisEventListener;
//
//public class DemoDataListener extends AnalysisEventListener<DemoData> {
//
//
//    @Override
//    public void invoke(DemoData data, AnalysisContext context) {
//
//    }
//
//
//    @Override
//    public void doAfterAllAnalysed(AnalysisContext context) {
//
//    }
//}
