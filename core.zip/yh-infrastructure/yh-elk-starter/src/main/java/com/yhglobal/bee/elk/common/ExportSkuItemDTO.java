//package com.yhglobal.bee.excel.common;
//
//public class ExportSkuItemDTO {
//
//    private String skuCode;
//
//    private String byteSkuCode;
//
//    public String getSkuCode() {
//        return skuCode;
//    }
//
//    public ExportSkuItemDTO setSkuCode(String skuCode) {
//        this.skuCode = skuCode;
//        return this;
//    }
//
//    public String getByteSkuCode() {
//        return byteSkuCode;
//    }
//
//    public ExportSkuItemDTO setByteSkuCode(String byteSkuCode) {
//        this.byteSkuCode = byteSkuCode;
//        return this;
//    }
//}
