//package com.yhglobal.bee.excel.common;
//
//import com.alibaba.excel.context.AnalysisContext;
//import com.alibaba.excel.event.AnalysisEventListener;
//import com.yhglobal.bee.common.util.JacksonUtil;
//
//import java.util.List;
//import java.util.Map;
//
//public class NoModelDataListener extends AnalysisEventListener<Map<String, String>> {
//    private static final int BATCH_COUNT = 5;
//
//    private List<Map<String, String>> list;
//
//    public List<Map<String, String>> getList() {
//        return list;
//    }
//
//    @Override
//    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
//        System.out.println("解析到一条头数据:"+ JacksonUtil.bean2Json(headMap));
//        System.out.println(JacksonUtil.bean2Json(headMap.values()));
//    }
//
//    public NoModelDataListener setList(List<Map<String, String>> list) {
//        this.list = list;
//        return this;
//    }
//
//    public NoModelDataListener(List<Map<String, String>> list){
//        this.list = list;
//    }
//
//    @Override
//    public void invoke(Map<String, String> data, AnalysisContext context) {
//        list.add(data);
//        if (list.size() >= BATCH_COUNT) {
//            saveData();
////            list.clear();
//        }
//
//    }
//
//
//    @Override
//    public void doAfterAllAnalysed(AnalysisContext context) {
//        saveData();
//        System.out.println("所有数据解析完成！");
//    }
//
//
//    /**
//
//     * 加上存储数据库
//
//     */
//    private void saveData() {
//        System.out.println("存储数据库成功！");
//    }
//
//
//}
