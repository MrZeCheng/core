//package com.yhglobal.bee.excel.common;
//
//import java.util.List;
//
//public class ExportSkuDTO {
//
//    private List<ExportSkuItemDTO> list;
//
//    public List<ExportSkuItemDTO> getList() {
//        return list;
//    }
//
//    public ExportSkuDTO setList(List<ExportSkuItemDTO> list) {
//        this.list = list;
//        return this;
//    }
//}
