package com.yhglobal.bee.data.dictionary.common.bootstrap.service.impl;

import com.yhglobal.bee.api.util.YhWebApiUtil;
import com.yhglobal.bee.bean.data.dictionary.InitDataDictionaryCmd;
import com.yhglobal.bee.common.constant.RequestHeaderConstant;
import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.request.RequestLanguageThreadLocal;
import com.yhglobal.bee.common.util.I18nUtil;
import com.yhglobal.bee.data.dictionary.common.bootstrap.service.DataDictionaryService;
import com.yhglobal.bee.redis.common.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Locale;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataDictionaryServiceImpl implements DataDictionaryService {

    private final RedisService redisService;

    private final YhWebApiUtil yhWebApiUtil;

    @Value("${yh.data.dictionary.registration.url:fail}")
    private String registrationUrl;

    private static final String DATA_DICTIONARY_KEY = "DATA:DICTIONARY:";


    @Override
    public Mono<String> getDataDictionaryEnumValue(YhDataDictionaryI yhDataDictionaryI, Integer enumValue) {
        if (enumValue == null) {
            return Mono.just("");
        }
        return getDataDictionaryStringEnumValue(yhDataDictionaryI,enumValue.toString());
    }

    @Override
    public boolean validationExits(String dictionary, Integer enumValue) {
        if (enumValue == null) {
            return false;
        }
        if (StringUtils.isBlank(dictionary)) {
            return false;
        }
        Locale locale = I18nUtil.getYhLocale(RequestLanguageThreadLocal.getRequestLanguage());
        Object object = redisService.hget(DATA_DICTIONARY_KEY + dictionary,enumValue.toString()+ I18nUtil.I18N_DELIMITER + locale.toString());
        return object != null;
    }

    @Override
    public Mono<String> getDataDictionaryStringEnumValue(YhDataDictionaryI yhDataDictionaryI, String enumValue) {
        if (StringUtils.isBlank(enumValue) || StringUtils.isBlank(yhDataDictionaryI.getCode())) {
            return Mono.just("");
        }
        Locale locale = I18nUtil.getYhLocale(RequestLanguageThreadLocal.getRequestLanguage());

        Object object = redisService.hget(DATA_DICTIONARY_KEY + yhDataDictionaryI.getCode(), enumValue + I18nUtil.I18N_DELIMITER + locale.toString());
        if (object != null) {
            return Mono.just(object.toString());
        }
        if (RequestHeaderConstant.FAIL_URL.equals(registrationUrl)) {
            throw new RuntimeException("yh.data.dictionary.registration.url is null !");
        }
        try {
            return yhWebApiUtil.sendWebApi(SingleResponse.class, new InitDataDictionaryCmd().setDictionaryCode(yhDataDictionaryI.getCode()).setDictionaryItemId(enumValue).setLanguage(locale.toString()),
                    "http://"+registrationUrl+"/foundation/mdm/dictionary/init")
                    .flatMap(yhResponse -> {
                        if (!yhResponse.isSuccess()) {
                            return Mono.just("");
                        }
                        return  Mono.just(yhResponse.getData().toString());
                });
        }catch (Exception e){
            log.error("getDataDictionaryStringEnumValue error = {}",e.getMessage());
            return Mono.just("");
        }
    }

    @Override
    public void putAllDataDictionaryEnumValue(String dictionary, Map<String, Object> map) {
       redisService.hmset(DATA_DICTIONARY_KEY + dictionary,map);
    }

    @Override
    public void putDataDictionaryEnumValue(String dictionary, String enumValue,String enumObject) {
        redisService.hset(DATA_DICTIONARY_KEY + dictionary,enumValue,enumObject);
    }
}
