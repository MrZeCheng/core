package com.yhglobal.bee.data.dictionary.common.bootstrap.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author zhengkaizhou
 * @date 2022/11/1 16:44
 */
@ConfigurationProperties("yh.data.dictionary.registration")
@Data
public class YhDictionaryProperties {

    private Boolean enable = true;

    private String path;

    private String url = "fail";

    private Boolean dataBaseEnable = true;


}
