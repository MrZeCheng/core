//package com.yhglobal.bee.data.dictionary.common.bootstrap;
//
//import com.yhglobal.bee.api.util.YhWebApiUtil;
//import com.yhglobal.bee.bean.data.dictionary.DataDictionaryCmd;
//import com.yhglobal.bee.common.annotation.mybaits.DataDictionary;
//import com.yhglobal.bee.common.constant.ProxyConstant;
//import com.yhglobal.bee.common.constant.RequestHeaderConstant;
//import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
//import com.yhglobal.bee.common.dto.YhResponse;
//import com.yhglobal.bee.common.dto.context.YhApplicationContext;
//import com.yhglobal.bee.data.dictionary.common.bootstrap.properties.YhDictionaryProperties;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.Map;
//import java.util.Set;
//
///**
// * 自动扫描RequestMappingHandlerMapping 上的AuthorityValidate 进行注册
// *
// * @author weizecheng
// * @date 2021/3/28 17:01
// */
//@Component
//@Slf4j
//@Order(-1)
//@RequiredArgsConstructor
//public class DataDictionaryRegistrationConfig implements CommandLineRunner {
//
//    private final YhWebApiUtil yhWebApiUtil;
//
//    private final YhDictionaryProperties properties;
//
//
//    @Override
//    public void run(String... args) {
//        if (properties.getEnable()) {
//            Map<String, Object> extensionBeans = YhApplicationContext.getApplicationContext().getBeansWithAnnotation(DataDictionary.class);
//            if (!extensionBeans.isEmpty()) {
//                Set<String> set = new HashSet<>();
//                extensionBeans.values().forEach(
//                        dataDictionary ->{
//                            Class<?>  extensionClz = dataDictionary.getClass();
//                            String name = extensionClz.getName();
//                            // 兼容
//                            if (name.contains(ProxyConstant.PROXY_OBJECT_MARK)) {
//                                String className = StringUtils.substringBefore(name, ProxyConstant.PROXY_OBJECT_MARK);
//                                try {
//                                    final Class<?> clazz = Class.forName(className);
//                                    if (clazz.isAnnotationPresent(DataDictionary.class)) {
//                                        addDictionarySet(set,clazz.getDeclaredAnnotation(DataDictionary.class));
//                                    }
//                                } catch (Exception ignore) {
//
//                                }
//                            }else {
//                                addDictionarySet(set,extensionClz.getDeclaredAnnotation(DataDictionary.class));
//                            }
//                        });
//                if (!set.isEmpty()) {
//                    if (RequestHeaderConstant.FAIL_URL.equals(properties.getUrl())) {
//                        throw new RuntimeException("yh.data.dictionary.registration.url is null !");
//                    }
//                    try {
//                        yhWebApiUtil.sendWebApi(YhResponse.class,
//                                new DataDictionaryCmd().setDataDictionaryItemCmds(new ArrayList<>(set)),
//                                "http://"+properties.getUrl()+"/foundation/mdm/dictionary/registration")
//                                .subscribe(yhResponse -> {
//                            if (!yhResponse.isSuccess()) {
//                                log.warn("DataDictionaryRegistrationConfig fail = {}",yhResponse.getErrMessage());
//                            }
//                        });
//                    }catch (Exception e){
//                        log.warn("DataDictionaryRegistrationConfig fail = {}",e.getMessage());
//                    }
//                }
//            }
//        }
//    }
//
//    private void addDictionarySet(Set<String> set,DataDictionary declaredAnnotation){
//        if (declaredAnnotation != null) {
//            Class<? extends YhDataDictionaryI>[] classes = declaredAnnotation.dictionarys();
//            for (Class<? extends YhDataDictionaryI> c : classes){
//                if (c.isEnum()) {
//                    YhDataDictionaryI[] yhDataDictionaryI = c.getEnumConstants();
//                    for (YhDataDictionaryI y : yhDataDictionaryI) {
//                        set.add(y.getCode());
//                    }
//                }
//            }
//        }
//    }
//
//}
