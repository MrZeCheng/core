package com.yhglobal.bee.data.dictionary.common.bootstrap.util;

import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.data.dictionary.common.bootstrap.service.DataDictionaryService;

/**
 * 数据字典
 *
 * @author weizecheng
 * @date 2021/8/24 17:58
 */
public class DictionaryUtil {

    private static volatile DataDictionaryService dataDictionaryService = null;

    /**
     * 获取值
     *
     * @author weizecheng
     * @date 2021/8/24 17:57
     */
    public static String getDictionaryValue(YhDataDictionaryI yhDataDictionaryI, Integer enumValue){
        return getDataDictionaryService().getDataDictionaryEnumValue(yhDataDictionaryI,enumValue).block();
    }


    public static String getDictionaryValue(YhDataDictionaryI yhDataDictionaryI, String enumValue){
        return getDataDictionaryService().getDataDictionaryStringEnumValue(yhDataDictionaryI,enumValue).block();
    }

    public static Boolean validationExits(String dictionary, Integer enumValue){
        return getDataDictionaryService().validationExits(dictionary,enumValue);
    }

    private static DataDictionaryService getDataDictionaryService(){
        if (dataDictionaryService == null) {
            synchronized (DictionaryUtil.class){
                if (dataDictionaryService == null) {
                    dataDictionaryService = YhApplicationContext.getBean(DataDictionaryService.class);
                }
            }
        }
        return dataDictionaryService;
    }

}
