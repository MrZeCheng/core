package com.yhglobal.bee.data.dictionary.common.bootstrap.service;

import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
import reactor.core.publisher.Mono;

import java.util.Map;

public interface DataDictionaryService {


    /**
     * 获取枚举值
     *
     * @author weizecheng
     * @date 2021/8/23 17:48
     */
    Mono<String> getDataDictionaryEnumValue(YhDataDictionaryI yhDataDictionaryI, Integer enumValue);



    boolean validationExits(String dictionary, Integer enumValue);
    /**
     * 
     * 
     * @author weizecheng
     * @date 2021/8/24 17:49
     */
    Mono<String> getDataDictionaryStringEnumValue(YhDataDictionaryI yhDataDictionaryI,String enumValue);
    /**
     * put ALL 对象进去
     *
     * @author weizecheng
     * @date 2021/8/23 17:47
     */
    void putAllDataDictionaryEnumValue(String dictionary, Map<String,Object> map);

    /**
     * 设置单个对象
     *
     * @param dictionary
     * @param enumValue
     * @param enumObject
     */
    void putDataDictionaryEnumValue(String dictionary,String enumValue,String enumObject);
}
