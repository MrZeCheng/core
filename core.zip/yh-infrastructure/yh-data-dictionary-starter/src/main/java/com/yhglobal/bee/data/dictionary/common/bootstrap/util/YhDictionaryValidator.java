package com.yhglobal.bee.data.dictionary.common.bootstrap.util;

import com.yhglobal.bee.data.dictionary.common.bootstrap.annotation.DataDictionaryValidation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * 数据字典的自定义校验
 *
 * @author weizecheng
 * @date 2021/8/30 18:29
 */
public class YhDictionaryValidator implements ConstraintValidator<DataDictionaryValidation,Object> {

    @Override
    public void initialize(DataDictionaryValidation constraintAnnotation) {

    }

    @Override
    public boolean isValid(Object o, ConstraintValidatorContext constraintValidatorContext) {
        // TODO 参数校验
        return false;
    }
}
