package com.yhglobal.bee.data.dictionary.common.bootstrap.configure;

import com.yhglobal.bee.data.dictionary.common.bootstrap.properties.YhDictionaryProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author zhengkaizhou
 * @date 2022/11/1 17:01
 */
@Configuration
@EnableConfigurationProperties(YhDictionaryProperties.class)
@ConditionalOnProperty(prefix = "yh.data.dictionary.registration", name = "enable", havingValue = "true", matchIfMissing = true)
public class YhDictionaryAutoConfigure {

}
