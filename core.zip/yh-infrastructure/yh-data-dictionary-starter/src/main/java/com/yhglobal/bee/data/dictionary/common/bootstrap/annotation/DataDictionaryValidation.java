package com.yhglobal.bee.data.dictionary.common.bootstrap.annotation;

import com.yhglobal.bee.data.dictionary.common.bootstrap.util.YhDictionaryValidator;

import javax.validation.Constraint;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Documented
@Retention(RUNTIME)
@Target(TYPE)///接口、类、枚举、注解、方法
@Constraint(validatedBy = YhDictionaryValidator.class)
public @interface DataDictionaryValidation {

    String dictionary();
}
