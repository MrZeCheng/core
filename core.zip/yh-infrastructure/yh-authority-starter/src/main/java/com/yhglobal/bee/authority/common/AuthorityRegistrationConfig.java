package com.yhglobal.bee.authority.common;

import com.yhglobal.bee.api.util.YhWebApiUtil;
import com.yhglobal.bee.beans.authority.AuthorityMainBO;
import com.yhglobal.bee.beans.authority.RegistrationAuthorityCmd;
import com.yhglobal.bee.common.annotation.AuthorityValidate;
import com.yhglobal.bee.common.constant.RequestHeaderConstant;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.util.Base64Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 自动扫描RequestMappingHandlerMapping 上的AuthorityValidate 进行注册
 *
 * @author weizecheng
 * @date 2021/3/28 17:01
 */
@Component
@Slf4j
public class AuthorityRegistrationConfig implements CommandLineRunner{

    @Value("${yh.authority.registration.url:fail}")
    private String registrationUrl;

    @Resource
    private YhWebApiUtil yhWebApiUtil;

    @Override
    public void run(String... args) {
        RequestMappingHandlerMapping mapping = YhApplicationContext.getBean(RequestMappingHandlerMapping.class);
        Map<RequestMappingInfo, HandlerMethod> handlerMethods = mapping.getHandlerMethods();
        if (!handlerMethods.isEmpty()) {
            List<AuthorityMainBO> authorityMainBOList = new ArrayList<>();
            handlerMethods.forEach((key,value)->{
                Method method = value.getMethod();
                AuthorityValidate permission = method.getAnnotation(AuthorityValidate.class);
                if (permission != null) {
                    if (key.getPatternsCondition() == null) {
                        log.info("PatternsCondition is null");
                        return;
                    }
                    Set<String> patterns =key.getPatternsCondition().getPatterns();
                    if (patterns.isEmpty()) {
                        log.info("PatternsCondition size is zero");
                        return;
                    }
                    // 截取url
                    String url = String.valueOf(patterns.size() == 1 ? patterns.iterator().next() : patterns);
                    Set<RequestMethod> httpMethods = key.getMethodsCondition().getMethods();
                    // 获取请求方法类型
                    String methodType = String.valueOf(httpMethods.size() == 1 ? httpMethods.iterator().next() : HttpMethod.POST.name());
                    String base64 = Base64Util.encode(url + "-" + methodType);
                    AuthorityMainBO authorityMainBO = new AuthorityMainBO().setFunctionPermission("")
                            .setMethod(methodType).setUrl(url).setAutKey(base64);
                    authorityMainBOList.add(authorityMainBO);
                }
            });
            if (!authorityMainBOList.isEmpty()) {
                if (RequestHeaderConstant.FAIL_URL.equals(registrationUrl)) {
                    throw new RuntimeException("yh.authority.registration.url is null !");
                }
                try {
                    RegistrationAuthorityCmd registrationAuthorityCmd = new RegistrationAuthorityCmd()
                            .setProjectName("")
                            .setAuthorityMainBOList(authorityMainBOList);
                    yhWebApiUtil.sendWebApi(YhResponse.class,registrationAuthorityCmd,"http://"+registrationUrl+"/authority/registration").subscribe(yhResponse -> {
                        if (!yhResponse.isSuccess()) {
                            log.warn("AuthorityRegistrationConfig fail = {}",yhResponse.getErrMessage());
                        }
                    });
                }catch (Exception e){
                    log.warn("AuthorityRegistrationConfig fail = {}",e.getMessage());
                }
            }
        }
    }

}
