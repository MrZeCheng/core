CREATE TABLE foundation_mdm_dictionary_i18n_item (
	id BIGINT(20) auto_increment NOT NULL COMMENT '主键id',
	sourceId BIGINT(20) NULL COMMENT '来源的明细id',
	languageName VARCHAR(64) NULL COMMENT '语言名称',
	languageValue VARCHAR(64) NULL COMMENT '语言值',
	createdDate TIMESTAMP NULL COMMENT '创建时间',
	modifiedDate TIMESTAMP NULL COMMENT '修改时间',
	dataVersion BIGINT(10) NULL COMMENT '版本号',
	createdName VARCHAR(16) NULL COMMENT '创建人',
	modifiedName VARCHAR(16) NULL COMMENT '修改人',
	deleteFlag INTEGER(1) NULL COMMENT '逻辑删除 1:删除 2:非删除',
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE foundation_mdm_dictionary_item (
	id BIGINT(20) auto_increment NOT NULL COMMENT '主键id',
	dictionaryItemId VARCHAR(64) NULL COMMENT '字典id',
	dictionaryItemValue VARCHAR(64) NULL COMMENT '字典值',
	dictionaryCode VARCHAR(64) NULL COMMENT '字典编码',
	dictionaryName VARCHAR(64) NULL COMMENT '字典名称',
	spareField1 VARCHAR(64) NULL COMMENT '备用字段',
	spareFieldDescribe1 VARCHAR(64) NULL COMMENT '备用字段',
	spareField2 VARCHAR(64) NULL COMMENT '备用字段',
	spareFieldDescribe2 VARCHAR(64) NULL COMMENT '备用字段',
	spareField3 VARCHAR(64) NULL COMMENT '备用字段',
	spareFieldDescribe3 VARCHAR(64) NULL COMMENT '备用字段',
	spareField4 VARCHAR(64) NULL COMMENT '备用字段',
	spareFieldDescribe4 VARCHAR(64) NULL COMMENT '备用字段',
	spareField5 VARCHAR(64) NULL COMMENT '备用字段',
	spareFieldDescribe5 VARCHAR(64) NULL COMMENT '备用字段',
	enableFlag INTEGER(1) NULL COMMENT '是否禁用',
	createdDate TIMESTAMP NULL COMMENT '创建时间',
	modifiedDate TIMESTAMP NULL COMMENT '修改时间',
	dataVersion BIGINT(10) NULL COMMENT '版本号',
	createdName VARCHAR(16) NULL COMMENT '创建人',
	modifiedName VARCHAR(16) NULL COMMENT '修改人',
	deleteFlag INTEGER(1) NULL COMMENT '逻辑删除 1:删除 2:非删除',
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE foundation_mdm_dictionary (
	id BIGINT(20) auto_increment NOT NULL COMMENT '主键id',
	dictionaryCode VARCHAR(64) NULL COMMENT '字典编码',
	dictionaryName VARCHAR(64) NULL COMMENT '字典名称',
	dictionaryDescription VARCHAR(64) NULL COMMENT '字段描述',
	enableFlag INTEGER(1) NULL COMMENT '是否禁用',
	createdDate TIMESTAMP NULL COMMENT '创建时间',
	modifiedDate TIMESTAMP NULL COMMENT '修改时间',
	dataVersion BIGINT(10) NULL COMMENT '版本号',
	createdName varchar(16) NULL COMMENT '创建人',
	modifiedName varchar(16) NULL COMMENT '修改人',
	deleteFlag INTEGER(1) NULL COMMENT '逻辑删除 1:删除 2:非删除',
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


