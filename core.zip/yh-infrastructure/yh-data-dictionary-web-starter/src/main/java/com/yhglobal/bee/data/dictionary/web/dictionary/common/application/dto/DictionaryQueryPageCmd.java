package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.PageQuery;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel
public class DictionaryQueryPageCmd extends PageQuery {

}
