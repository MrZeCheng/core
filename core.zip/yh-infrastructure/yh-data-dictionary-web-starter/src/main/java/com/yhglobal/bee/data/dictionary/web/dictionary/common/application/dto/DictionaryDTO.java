package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.DTO;

public class DictionaryDTO extends DTO {

    /**
     * 字典Id
     */
    private String dictionaryItemId;

    /**
     * 备用字段
     */
    private String spareField1;

    /**
     * 备用字段
     */
    private String spareField2;

    /**
     * 备用字段
     */
    private String spareField3;

    /**
     * 备用字段
     */
    private String spareField4;

    /**
     * 备用字段
     */
    private String spareField5;


    public String getDictionaryItemId() {
        return dictionaryItemId;
    }

    public DictionaryDTO setDictionaryItemId(String dictionaryItemId) {
        this.dictionaryItemId = dictionaryItemId;
        return this;
    }

    public String getSpareField1() {
        return spareField1;
    }

    public DictionaryDTO setSpareField1(String spareField1) {
        this.spareField1 = spareField1;
        return this;
    }

    public String getSpareField2() {
        return spareField2;
    }

    public DictionaryDTO setSpareField2(String spareField2) {
        this.spareField2 = spareField2;
        return this;
    }

    public String getSpareField3() {
        return spareField3;
    }

    public DictionaryDTO setSpareField3(String spareField3) {
        this.spareField3 = spareField3;
        return this;
    }

    public String getSpareField4() {
        return spareField4;
    }

    public DictionaryDTO setSpareField4(String spareField4) {
        this.spareField4 = spareField4;
        return this;
    }

    public String getSpareField5() {
        return spareField5;
    }

    public DictionaryDTO setSpareField5(String spareField5) {
        this.spareField5 = spareField5;
        return this;
    }
}
