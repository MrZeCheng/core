package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.DTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel
public class DictionaryItemEnableCmd extends DTO {

    /**
     * 字典Id
     */
    private String dictionaryItemId;
    /**
     * 字典编码
     */
    private String dictionaryCode;
}
