package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.service.impl;

import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryAllQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryDTO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemCreateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemEnableCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.service.DictionaryService;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.domain.gateway.DictionaryGateway;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryItemDO;
import com.yhglobal.bee.bean.data.dictionary.DataDictionaryCmd;
import com.yhglobal.bee.bean.data.dictionary.InitDataDictionaryCmd;
import com.yhglobal.bee.common.constant.KeyValueObject;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class DictionaryServiceImpl implements DictionaryService {

    private final DictionaryGateway dictionaryGateway;

    @Override
    public SingleResponse<String> initDictionaryCode(InitDataDictionaryCmd initDataDictionaryCmd){
        return dictionaryGateway.initDictionaryCode(initDataDictionaryCmd);
    }

    @Override
    public SingleResponse<DictionaryDTO> findDictionaryDTO(DictionaryQueryCmd dictionaryQueryCmd){
        return dictionaryGateway.findDictionaryDTO(dictionaryQueryCmd.getDictionaryCode(),dictionaryQueryCmd.getDictionaryItemId());
    }

    @Override
    public MultiResponse<DictionaryDTO> findAllDictionaryDTO(DictionaryAllQueryCmd dictionaryAllQueryCmd){
        return dictionaryGateway.findAllDictionaryDTO(dictionaryAllQueryCmd.getDictionaryCode());
    }


    @Override
    public YhResponse registrationDataDictionary(DataDictionaryCmd dataDictionaryCmd){
        dictionaryGateway.registrationDataDictionary(dataDictionaryCmd.getDataDictionaryItemCmds());
        return YhResponse.buildSuccess();
    }

    @Override
    public PageResponse<DataDictionaryDO> findAllByPage(DictionaryQueryPageCmd dictionaryQueryPageCmd) {
        return dictionaryGateway.findAllByPage(dictionaryQueryPageCmd);
    }

    @Override
    public YhResponse updateDictionary(DictionaryUpdateCmd dictionaryUpdateCmd) {
        return dictionaryGateway.updateDictionary(dictionaryUpdateCmd);
    }

    @Override
    public MultiResponse<DataDictionaryItemDO> findDataDictionaryItem(DictionaryItemQueryCmd dictionaryItemQueryCmd){
        return dictionaryGateway.findDataDictionaryItem(dictionaryItemQueryCmd);
    }

    @Override
    public MultiResponse<KeyValueObject> findAllEnableByDictionaryCode(DictionaryItemQueryCmd dictionaryItemQueryCmd){
        return dictionaryGateway.findAllEnableByDictionaryCode(dictionaryItemQueryCmd.getDictionaryCode());
    }

    @Override
    public YhResponse updateDictionaryItem(DictionaryItemUpdateCmd dictionaryItemUpdateCmd){
        return dictionaryGateway.updateDictionaryItem(dictionaryItemUpdateCmd);
    }

    @Override
    public YhResponse createDictionaryItem(DictionaryItemCreateCmd dictionaryItemCreateCmd){
        return dictionaryGateway.createDictionaryItem(dictionaryItemCreateCmd);
    }

    @Override
    public YhResponse enableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd){
        return dictionaryGateway.enableDictionaryItem(dictionaryItemEnableCmd);
    }

    @Override
    public YhResponse disableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd){
        return dictionaryGateway.disableDictionaryItem(dictionaryItemEnableCmd);
    }

}
