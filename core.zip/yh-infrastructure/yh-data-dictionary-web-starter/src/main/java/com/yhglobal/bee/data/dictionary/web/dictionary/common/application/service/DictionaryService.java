package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.service;

import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryAllQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryDTO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemCreateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemEnableCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryItemDO;
import com.yhglobal.bee.bean.data.dictionary.DataDictionaryCmd;
import com.yhglobal.bee.bean.data.dictionary.InitDataDictionaryCmd;
import com.yhglobal.bee.common.constant.KeyValueObject;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;

public interface DictionaryService {

    SingleResponse<String> initDictionaryCode(InitDataDictionaryCmd initDataDictionaryCmd);

    SingleResponse<DictionaryDTO> findDictionaryDTO(DictionaryQueryCmd dictionaryQueryCmd);

    MultiResponse<DictionaryDTO> findAllDictionaryDTO(DictionaryAllQueryCmd dictionaryAllQueryCmd);

    YhResponse registrationDataDictionary(DataDictionaryCmd dataDictionaryCmd);

    PageResponse<DataDictionaryDO> findAllByPage(DictionaryQueryPageCmd dictionaryQueryPageCmd);

    YhResponse updateDictionary(DictionaryUpdateCmd dictionaryUpdateCmd);

    MultiResponse<DataDictionaryItemDO> findDataDictionaryItem(DictionaryItemQueryCmd dictionaryItemQueryCmd);

    MultiResponse<KeyValueObject> findAllEnableByDictionaryCode(DictionaryItemQueryCmd dictionaryItemQueryCmd);

    YhResponse updateDictionaryItem(DictionaryItemUpdateCmd dictionaryItemUpdateCmd);

    YhResponse createDictionaryItem(DictionaryItemCreateCmd dictionaryItemCreateCmd);

    YhResponse enableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd);

    YhResponse disableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd);

}
