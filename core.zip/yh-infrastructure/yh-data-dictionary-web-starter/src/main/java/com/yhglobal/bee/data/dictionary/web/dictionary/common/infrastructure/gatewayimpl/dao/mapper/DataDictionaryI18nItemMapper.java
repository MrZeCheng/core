package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper;

import com.yhglobal.bee.common.constant.base.MybatisBaseFieldConstant;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.TableManagement;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryI18nItemDO;
import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * @author weizecheng
 * @date 2021/12/21 16:12
 */
@Mapper
@DataInsertAndUpdate
@DataTombstone
@TableManagement(tableName = "foundation_mdm_dictionary_i18n_item", sqlIndex = 0)
public interface DataDictionaryI18nItemMapper {

    String SQL = MybatisBaseFieldConstant.BASE + "sourceId, languageName, languageValue";


    @Insert({
            "insert into foundation_mdm_dictionary_i18n_item ( createdDate, ",
            "modifiedDate, dataVersion, ",
            "createdName, modifiedName, ",
            "deleteFlag, sourceId, ",
            "languageName, languageValue)",
            "values (#{createdDate,jdbcType=TIMESTAMP}, ",
            "#{modifiedDate,jdbcType=TIMESTAMP}, #{dataVersion,jdbcType=BIGINT}, ",
            "#{createdName,jdbcType=VARCHAR}, #{modifiedName,jdbcType=VARCHAR}, ",
            "#{deleteFlag,jdbcType=INTEGER}, #{sourceId,jdbcType=BIGINT}, ",
            "#{languageName,jdbcType=VARCHAR}, #{languageValue,jdbcType=VARCHAR})"
    })
    int insert(DataDictionaryI18nItemDO DataDictionaryI18nItemDO);


    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary_i18n_item",
            "where sourceId = #{sourceId,jdbcType=INTEGER} AND languageName = #{languageName}"
    })
    DataDictionaryI18nItemDO findBySourceIdAndLanguageName(@Param("sourceId") Long sourceId, @Param("languageName") String languageName);


    @Update({
            "update foundation_mdm_dictionary_i18n_item",
            "set ",
            "languageValue = #{languageValue}",
            "where id = #{id}",
    })
    int updateLanguageValueById(@Param("id") Long id, @Param("languageValue") String languageValue);

    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary_i18n_item",
            "where sourceId = #{sourceId,jdbcType=INTEGER}"
    })
    List<DataDictionaryI18nItemDO> findBySourceId(@Param("sourceId") Long sourceId);
}
