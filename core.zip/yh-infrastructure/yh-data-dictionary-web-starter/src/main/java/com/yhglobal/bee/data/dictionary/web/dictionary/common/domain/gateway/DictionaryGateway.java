package com.yhglobal.bee.data.dictionary.web.dictionary.common.domain.gateway;

import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryDTO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemCreateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemEnableCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryItemDO;
import com.yhglobal.bee.bean.data.dictionary.InitDataDictionaryCmd;
import com.yhglobal.bee.common.constant.KeyValueObject;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;

import java.util.List;

public interface DictionaryGateway {

    SingleResponse<String> initDictionaryCode(InitDataDictionaryCmd initDataDictionaryCmd);

    SingleResponse<DictionaryDTO> findDictionaryDTO(String dictionaryCode, String dictionaryItemId);

    MultiResponse<DictionaryDTO> findAllDictionaryDTO(String dictionaryCode);

    void initDictionaryAll();

    void registrationDataDictionary(List<String> stringList);

    PageResponse<DataDictionaryDO> findAllByPage(DictionaryQueryPageCmd dictionaryQueryPageCmd);

    DataDictionaryDO findByDictionaryCode(String dictionaryCode);

    DataDictionaryItemDO findByDictionaryCodeAndDictionaryItemId(String dictionaryCode, String dictionaryItemId);

    YhResponse updateDictionary(DictionaryUpdateCmd dictionaryUpdateCmd);

    MultiResponse<DataDictionaryItemDO> findDataDictionaryItem(DictionaryItemQueryCmd dictionaryItemQueryCmd);

    MultiResponse<KeyValueObject> findAllEnableByDictionaryCode(String dictionaryCode);

    YhResponse updateDictionaryItem(DictionaryItemUpdateCmd dictionaryItemUpdateCmd);

    YhResponse createDictionaryItem(DictionaryItemCreateCmd dictionaryItemCreateCmd);

    YhResponse enableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd);

    YhResponse disableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd);

    YhResponse managementDataBase(String database);
}
