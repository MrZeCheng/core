package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.Command;
import lombok.Data;

@Data
public class DictionaryUpdateCmd extends Command {

    private Long id;

    /**
     * 字段编码
     */
    private String dictionaryCode;
    /**
     * 字段名
     */
    private String dictionaryName;

    /**
     * 字段描述
     */
    private String dictionaryDescription;

    /**
     * 是否禁用
     */
    private Integer enableFlag;

}
