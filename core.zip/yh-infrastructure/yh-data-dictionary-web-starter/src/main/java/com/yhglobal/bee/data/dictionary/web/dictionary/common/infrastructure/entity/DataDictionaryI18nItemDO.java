package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity;

import lombok.Data;
import lombok.experimental.Accessors;
import com.yhglobal.bee.mybatis.common.entity.BaseMybatisEntity;

import java.io.Serializable;

@Data
@Accessors(chain = true)
public class DataDictionaryI18nItemDO extends BaseMybatisEntity implements Serializable {

    /**
     *  来源的明细Id
     */
    private Long sourceId;

    /**
     * 语言名称
     */
    private String languageName;

    /**
     * 语言值
     */
    private String languageValue;

}
