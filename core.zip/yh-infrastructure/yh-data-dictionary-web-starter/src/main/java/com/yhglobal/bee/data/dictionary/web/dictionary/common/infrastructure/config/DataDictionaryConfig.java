package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.config;

import com.yhglobal.bee.data.dictionary.web.dictionary.common.domain.gateway.DictionaryGateway;
import com.yhglobal.bee.common.annotation.mybaits.DataDictionary;
import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Component
@RequiredArgsConstructor
@Order
public class DataDictionaryConfig implements CommandLineRunner{

    private final DictionaryGateway dictionaryGateway;

    @Override
    public void run(String... args) {
        Map<String, Object> extensionBeans = YhApplicationContext.getApplicationContext().getBeansWithAnnotation(DataDictionary.class);
        if(extensionBeans.size() > 0){
            Set<String> set = new HashSet<>();
            extensionBeans.values().forEach(
                    dataDictionary ->{
                        Class<?> extensionClz = dataDictionary.getClass();
                        addDictionarySet(set,extensionClz.getDeclaredAnnotation(DataDictionary.class));
                    });
            if(set.size() > 0){
                dictionaryGateway.registrationDataDictionary(new ArrayList<>(set));
            }
        }
        // 唤醒注册
        dictionaryGateway.initDictionaryAll();
    }

    private void addDictionarySet(Set<String> set, DataDictionary declaredAnnotation){
        if(declaredAnnotation != null){
            Class<? extends YhDataDictionaryI>[] classes = declaredAnnotation.dictionarys();
            for(Class<? extends YhDataDictionaryI> c : classes){
                if(c.isEnum()){
                    YhDataDictionaryI[] yhDataDictionaryI = c.getEnumConstants();
                    for(YhDataDictionaryI y : yhDataDictionaryI){
                        set.add(y.getCode());
                    }
                }
            }
        }
    }
}
