package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yhglobal.bee.bean.data.dictionary.InitDataDictionaryCmd;
import com.yhglobal.bee.common.constant.KeyValueObject;
import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.dto.request.RequestLanguageThreadLocal;
import com.yhglobal.bee.common.util.FileUtil;
import com.yhglobal.bee.common.util.I18nUtil;
import com.yhglobal.bee.common.util.YhObjectUtil;
import com.yhglobal.bee.common.util.constant.EnableEnum;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.bee.data.dictionary.common.bootstrap.service.DataDictionaryService;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryDTO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemCreateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemEnableCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.domain.gateway.DictionaryGateway;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.TableManagement;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.config.DictionaryDescriptionConfig;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryI18nItemDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryItemDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.DataDictionaryI18nItemMapper;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.DataDictionaryItemMapper;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.DataDictionaryMapper;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.DictionaryDataBaseMapper;
import com.yhglobal.bee.mybatis.common.converter.PageMytbaitsConverter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DictionaryGatewayImpl implements DictionaryGateway {

    private final DataDictionaryItemMapper dataDictionaryItemMapper;
    private final DataDictionaryMapper dataDictionaryMapper;
    private final DataDictionaryI18nItemMapper dataDictionaryI18nItemMapper;
    private final DataDictionaryService dataDictionaryService;
    private final DictionaryDataBaseMapper dictionaryDataBaseMapper;

    @Override
    public SingleResponse<String> initDictionaryCode(InitDataDictionaryCmd initDataDictionaryCmd) {
        DataDictionaryItemDO dataDictionaryItemBO = dataDictionaryItemMapper.findByDictionaryCodeAndDictionaryItemId(initDataDictionaryCmd.getDictionaryCode(),initDataDictionaryCmd.getDictionaryItemId());
        String key = initDataDictionaryCmd.getDictionaryItemId() + I18nUtil.I18N_DELIMITER + initDataDictionaryCmd.getLanguage();
        if (dataDictionaryItemBO == null) {
            dataDictionaryService.putDataDictionaryEnumValue(initDataDictionaryCmd.getDictionaryCode(),key,"");
            return SingleResponse.of("");
        }
        DataDictionaryI18nItemDO dataDictionaryI18nItemBO = dataDictionaryI18nItemMapper.findBySourceIdAndLanguageName(dataDictionaryItemBO.getId(), initDataDictionaryCmd.getLanguage());
        if (dataDictionaryI18nItemBO == null) {
            dataDictionaryService.putDataDictionaryEnumValue(initDataDictionaryCmd.getDictionaryCode(),key,"");
            return SingleResponse.of("");
        }
        dataDictionaryService.putDataDictionaryEnumValue(initDataDictionaryCmd.getDictionaryCode(),key,dataDictionaryI18nItemBO.getLanguageValue());
        return SingleResponse.of(dataDictionaryI18nItemBO.getLanguageValue());
    }

    @Override
    public SingleResponse<DictionaryDTO> findDictionaryDTO(String dictionaryCode, String dictionaryItemId) {
        DataDictionaryItemDO dataDictionaryItemBO = dataDictionaryItemMapper.findByDictionaryCodeAndDictionaryItemId(dictionaryCode,dictionaryItemId);
        YhObjectUtil.requireNonNull(dataDictionaryItemBO);
        DictionaryDTO dictionaryDTO = new DictionaryDTO();
        BeanUtils.copyProperties(dataDictionaryItemBO,dictionaryDTO);
        return SingleResponse.of(dictionaryDTO);
    }

    @Override
    public MultiResponse<DictionaryDTO> findAllDictionaryDTO(String dictionaryCode) {
        return MultiResponse.of(dataDictionaryItemMapper.findAllByDictionaryCode(dictionaryCode).stream().map(dataDictionaryItemBO -> {
            DictionaryDTO dictionaryDTO = new DictionaryDTO();
            BeanUtils.copyProperties(dataDictionaryItemBO,dictionaryDTO);
            return dictionaryDTO;}).collect(Collectors.toList()));
    }

    @Override
    public void initDictionaryAll() {
        List<DataDictionaryItemDO> list = dataDictionaryItemMapper.findAll();
        if (!list.isEmpty()){
            list.stream().collect(Collectors.groupingBy(DataDictionaryItemDO::getDictionaryCode)).forEach((key,value)->{
                if (value.isEmpty()){
                    return;
                }
                Map<String, Object> map = new HashMap<>(16);
                value.forEach(item -> {
                    List<DataDictionaryI18nItemDO> i18nItems = dataDictionaryI18nItemMapper.findBySourceId(item.getId());
                    if (!i18nItems.isEmpty()) {
                        i18nItems.forEach(itemBO -> {
                            String redisMapKey = item.getDictionaryItemId() + I18nUtil.I18N_DELIMITER + itemBO.getLanguageName();
                            map.put(redisMapKey,itemBO.getLanguageValue());
                        });
                    }
                });
                if (!map.isEmpty()) {
                    dataDictionaryService.putAllDataDictionaryEnumValue(key, map);
                }
            });
        }
    }

    @Override
    public void registrationDataDictionary(List<String> stringList) {
        if(stringList.size() > 0){
            for(String s : stringList){
                try {
                    int count = dataDictionaryMapper.countByDictionaryCode(s);
                    if(count > 0){
                        continue;
                    }
                    DataDictionaryDO dataDictionaryBO = new DataDictionaryDO();
                    dataDictionaryBO.setDictionaryCode(s);
                    dataDictionaryBO.setDictionaryDescription("");
                    dataDictionaryBO.setDictionaryName("");
                    dataDictionaryBO.setEnableFlag(EnableEnum.ENABLE.getStatus());
                    dataDictionaryMapper.insert(dataDictionaryBO);
                }catch (Exception e){
                    log.error("registrationDataDictionary fail = {},e={}",s, ExceptionUtils.getMessage(e));
                }
            }
        }
    }


    @Override
    public PageResponse<DataDictionaryDO> findAllByPage(DictionaryQueryPageCmd dictionaryQueryPageCmd) {
        PageHelper.startPage(dictionaryQueryPageCmd.getPageIndex(),dictionaryQueryPageCmd.getPageSize());
        List<DataDictionaryDO> dataDictionarys = dataDictionaryMapper.findAllByPage(dictionaryQueryPageCmd);
        if (!dataDictionarys.isEmpty()) {
            Map<String, YhDataDictionaryI> descriptionMap = DictionaryDescriptionConfig.getDescriptionMap();
            dataDictionarys.forEach(dataDictionaryBO -> dataDictionaryBO.setDictionaryName(descriptionMap.get(dataDictionaryBO.getDictionaryCode()).getDescription()));
        }
        return PageMytbaitsConverter.of(new PageInfo<>(dataDictionarys));
    }

    @Override
    public DataDictionaryDO findByDictionaryCode(String dictionaryCode) {
        DataDictionaryDO dataDictionaryBO = dataDictionaryMapper.findByDictionaryCode(dictionaryCode);
        YhObjectUtil.requireNonNull(dataDictionaryBO,dictionaryCode);
        return dataDictionaryBO;
    }

    @Override
    public DataDictionaryItemDO findByDictionaryCodeAndDictionaryItemId(String dictionaryCode, String dictionaryItemId) {
        DataDictionaryItemDO dataDictionaryItemBO = dataDictionaryItemMapper.findByDictionaryCodeAndDictionaryItemId(dictionaryCode,dictionaryItemId);
        YhObjectUtil.requireNonNull(dataDictionaryItemBO,dictionaryCode);
        return dataDictionaryItemBO;
    }

    @Override
    public YhResponse updateDictionary(DictionaryUpdateCmd dictionaryUpdateCmd) {
        DataDictionaryDO dataDictionaryBO = this.findByDictionaryCode(dictionaryUpdateCmd.getDictionaryCode());
        dictionaryUpdateCmd.setId(dataDictionaryBO.getId());
        dataDictionaryMapper.updateDictionary(dictionaryUpdateCmd);
        return YhResponse.buildSuccess();
    }

    @Override
    public MultiResponse<DataDictionaryItemDO> findDataDictionaryItem(DictionaryItemQueryCmd dictionaryItemQueryCmd) {
        List<DataDictionaryItemDO> dataDictionaryItemBOS = dataDictionaryItemMapper.findAllByDictionaryCodeAndEnableFlag(dictionaryItemQueryCmd);
        setLanguage(dataDictionaryItemBOS);
        return MultiResponse.of(dataDictionaryItemBOS);
    }

    private void setLanguage(List<DataDictionaryItemDO> dataDictionaryItemBOS){
        if (!dataDictionaryItemBOS.isEmpty()) {
            Locale locale = I18nUtil.getYhLocale(RequestLanguageThreadLocal.getRequestLanguage());
            dataDictionaryItemBOS.forEach(dataDictionaryItemBO -> {
                DataDictionaryI18nItemDO dataDictionaryI18nItemBO = dataDictionaryI18nItemMapper.findBySourceIdAndLanguageName(dataDictionaryItemBO.getId(), locale.toString());
                dataDictionaryItemBO.setDictionaryItemValue(dataDictionaryI18nItemBO == null ? "" : dataDictionaryI18nItemBO.getLanguageValue());
            });
        }
    }

    @Override
    public MultiResponse<KeyValueObject> findAllEnableByDictionaryCode(String dictionaryCode) {
        List<DataDictionaryItemDO> dataDictionaryItemBOS = dataDictionaryItemMapper.findAllEnableFlag(EnableEnum.ENABLE.getStatus());
        setLanguage(dataDictionaryItemBOS);
        return MultiResponse.of(dataDictionaryItemBOS.stream()
                .map(dataDictionaryItemBO -> new KeyValueObject(dataDictionaryItemBO.getDictionaryItemId(),dataDictionaryItemBO.getDictionaryItemValue()))
                .collect(Collectors.toList()));
    }

    @Override
    public YhResponse updateDictionaryItem(DictionaryItemUpdateCmd dictionaryItemUpdateCmd) {

        DataDictionaryItemDO dataDictionaryItemBO = findByDictionaryCodeAndDictionaryItemId(dictionaryItemUpdateCmd.getDictionaryCode(),dictionaryItemUpdateCmd.getDictionaryItemId());
        dictionaryItemUpdateCmd.setId(dataDictionaryItemBO.getId());
        Locale locale = I18nUtil.getYhLocale(RequestLanguageThreadLocal.getRequestLanguage());
        String key = dataDictionaryItemBO.getDictionaryItemId() + I18nUtil.I18N_DELIMITER + locale.toString();
        DataDictionaryI18nItemDO dataDictionaryI18nItemBO = dataDictionaryI18nItemMapper.findBySourceIdAndLanguageName(dataDictionaryItemBO.getId(),locale.toString());
        if (dataDictionaryI18nItemBO == null) {
            DataDictionaryI18nItemDO dataDictionaryI18nItemBO1 = new DataDictionaryI18nItemDO();
            dataDictionaryI18nItemBO1.setSourceId(dataDictionaryItemBO.getId());
            dataDictionaryI18nItemBO1.setLanguageName(locale.toString());
            dataDictionaryI18nItemBO1.setLanguageValue(dictionaryItemUpdateCmd.getDictionaryItemValue());
            dataDictionaryI18nItemMapper.insert(dataDictionaryI18nItemBO1);
        }else {
            dataDictionaryI18nItemMapper.updateLanguageValueById(dataDictionaryI18nItemBO.getId(),dictionaryItemUpdateCmd.getDictionaryItemValue());
        }
        dataDictionaryItemMapper.updateDictionaryItemValue(dictionaryItemUpdateCmd);
        dataDictionaryService.putDataDictionaryEnumValue(dataDictionaryItemBO.getDictionaryCode(), key, dictionaryItemUpdateCmd.getDictionaryItemValue());
        return YhResponse.buildSuccess();
    }

    @Override
    public YhResponse createDictionaryItem(DictionaryItemCreateCmd dictionaryItemCreateCmd) {
        DataDictionaryDO dataDictionaryBO = findByDictionaryCode(dictionaryItemCreateCmd.getDictionaryCode());
        DataDictionaryItemDO dataDictionaryItemBO = dataDictionaryItemMapper.findByDictionaryCodeAndDictionaryItemId(dictionaryItemCreateCmd.getDictionaryCode(),dictionaryItemCreateCmd.getDictionaryItemId());
        if(dataDictionaryItemBO != null){
            return YhResponse.buildFailure(ErrorCode.DATA_ABNORMAL);
        }
        Locale locale = I18nUtil.getYhLocale(RequestLanguageThreadLocal.getRequestLanguage());
        String key = dictionaryItemCreateCmd.getDictionaryItemId() + I18nUtil.I18N_DELIMITER + locale.toString();
        DataDictionaryItemDO dataDictionaryItemBO1 = new DataDictionaryItemDO();
        dataDictionaryItemBO1.setDictionaryCode(dataDictionaryBO.getDictionaryCode());
        dataDictionaryItemBO1.setDictionaryName(dataDictionaryBO.getDictionaryName());
        dataDictionaryItemBO1.setDictionaryItemId(dictionaryItemCreateCmd.getDictionaryItemId());
        dataDictionaryItemBO1.setDictionaryItemValue(dictionaryItemCreateCmd.getDictionaryItemValue());
        dataDictionaryItemBO1.setEnableFlag(EnableEnum.ENABLE.getStatus());
        dataDictionaryItemMapper.insert(dataDictionaryItemBO1);
        dataDictionaryService.putDataDictionaryEnumValue(dataDictionaryItemBO1.getDictionaryCode(), key, dataDictionaryItemBO1.getDictionaryItemValue());
        return YhResponse.buildSuccess();
    }

    @Override
    public YhResponse enableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd) {
        DataDictionaryItemDO dataDictionaryItemBO = findByDictionaryCodeAndDictionaryItemId(dictionaryItemEnableCmd.getDictionaryCode(),dictionaryItemEnableCmd.getDictionaryItemId());
        if(EnableEnum.ENABLE.getStatus().equals(dataDictionaryItemBO.getEnableFlag())){
            return YhResponse.buildSuccess();
        }
        dataDictionaryItemMapper.updateEnableFlag(dataDictionaryItemBO.getId(),EnableEnum.ENABLE.getStatus());
        return YhResponse.buildSuccess();
    }

    @Override
    public YhResponse disableDictionaryItem(DictionaryItemEnableCmd dictionaryItemEnableCmd) {
        DataDictionaryItemDO dataDictionaryItemBO = findByDictionaryCodeAndDictionaryItemId(dictionaryItemEnableCmd.getDictionaryCode(),dictionaryItemEnableCmd.getDictionaryItemId());
        if(EnableEnum.DISABLE.getStatus().equals(dataDictionaryItemBO.getEnableFlag())){
            return YhResponse.buildSuccess();
        }
        dataDictionaryItemMapper.updateEnableFlag(dataDictionaryItemBO.getId(),EnableEnum.DISABLE.getStatus());
        return YhResponse.buildSuccess();
    }


    @Override
    public YhResponse managementDataBase(String database) {
        // 1 获取mapper接口上的注解信息
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<?>> classes = reflections.getTypesAnnotatedWith(TableManagement.class);
        Map<String, Integer> tableMap = new HashMap<>(16);
        for (Class<?> aClass : classes) {
            TableManagement tableManagement = aClass.getAnnotation(TableManagement.class);
            tableMap.put(tableManagement.tableName(), tableManagement.sqlIndex());
        }
        try {
            // 2 读取配置文件获取sql语句
            String allSql = FileUtil.readFileAsString("dictionary_table.sql");
            String[] sqls = allSql.split(";");
            // 3 遍历创建表
            for (Map.Entry<String, Integer> entry : tableMap.entrySet()){
                Integer count = dictionaryDataBaseMapper.countByDatabase(database, entry.getKey());
                if (count == 0){
                    dictionaryDataBaseMapper.createTable(sqls[entry.getValue()]);
                }
            }
        }catch (IOException e){
            log.error("[out][managementDataBase] error :",e);
            throw new RuntimeException("读取配置文件出错") ;
        }catch (Exception e){
            log.error("[out][managementDataBase] error :",e);
            throw new RuntimeException("表创建错误") ;
        }


        return YhResponse.buildSuccess();
    }


}
