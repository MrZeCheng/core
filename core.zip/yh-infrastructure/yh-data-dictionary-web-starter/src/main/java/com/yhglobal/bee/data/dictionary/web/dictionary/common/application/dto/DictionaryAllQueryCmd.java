package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.Query;

public class DictionaryAllQueryCmd extends Query {
    private String dictionaryCode;
    public String getDictionaryCode() {
        return dictionaryCode;
    }

    public DictionaryAllQueryCmd setDictionaryCode(String dictionaryCode) {
        this.dictionaryCode = dictionaryCode;
        return this;
    }
}
