package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.provider;


import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.DataDictionaryItemMapper;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.DataDictionaryMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

/**
 *
 *
 * @author weizecheng
 * @date 2021/12/21 15:11
 */
public class DictionarySqlProvider {


    public String findAllByPage(@Param("order") DictionaryQueryPageCmd dictionaryQueryPageCmd){
        return new SQL() {{
            SELECT(DataDictionaryMapper.SQL);
            FROM("foundation_mdm_dictionary");
//            if(operatingPageCmd.getEnableFlag() !=null){
//                WHERE("enableFlag = #{order.enableFlag}");
//            }
            ORDER_BY("id DESC");
        }}.toString();
    }

    public String update(@Param("order") DictionaryUpdateCmd dictionaryUpdateCmd) {
        return new SQL() {{
            UPDATE("foundation_mdm_dictionary");

            if (dictionaryUpdateCmd.getDictionaryName() != null) {
                SET("dictionaryName = #{order.dictionaryName,jdbcType=VARCHAR}");
            }

            if (dictionaryUpdateCmd.getDictionaryDescription() != null) {
                SET("dictionaryDescription = #{order.dictionaryDescription,jdbcType=VARCHAR}");
            }

            if (dictionaryUpdateCmd.getEnableFlag() != null) {
                SET("enableFlag = #{order.enableFlag,jdbcType=INTEGER}");
            }

            WHERE("id = #{order.id,jdbcType=BIGINT}");
        }}.toString();
    }

    public String updateItem(@Param("order") DictionaryItemUpdateCmd dictionaryItemUpdateCmd) {
        return new SQL() {{
            UPDATE("foundation_mdm_dictionary_item");

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getDictionaryItemValue())) {
                SET("dictionaryItemValue = #{order.dictionaryItemValue,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareField1())) {
                SET("spareField1 = #{order.spareField1,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareFieldDescribe1())) {
                SET("spareFieldDescribe1 = #{order.spareFieldDescribe1,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareField2())) {
                SET("spareField2 = #{order.spareField2,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareFieldDescribe2())) {
                SET("spareFieldDescribe2 = #{order.spareFieldDescribe2,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareField3())) {
                SET("spareField3 = #{order.spareField3,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareFieldDescribe3())) {
                SET("spareFieldDescribe3 = #{order.spareFieldDescribe3,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareField4())) {
                SET("spareField4 = #{order.spareField4,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareFieldDescribe4())) {
                SET("spareFieldDescribe4 = #{order.spareFieldDescribe4,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareField5())) {
                SET("spareField5 = #{order.spareField5,jdbcType=VARCHAR}");
            }

            if (StringUtils.isNotBlank(dictionaryItemUpdateCmd.getSpareFieldDescribe5())) {
                SET("spareFieldDescribe5 = #{order.spareFieldDescribe5,jdbcType=VARCHAR}");
            }



            WHERE("id = #{order.id,jdbcType=BIGINT}");
        }}.toString();
    }


    public String select(@Param("item") DictionaryItemQueryCmd dictionaryItemQueryCmd) {
        return new SQL() {{
            SELECT(DataDictionaryItemMapper.SQL);
            FROM("foundation_mdm_dictionary_item");
            if (dictionaryItemQueryCmd.getEnableFlag() != null) {
                WHERE("enableFlag = #{item.enableFlag}");
            }
            if (StringUtils.isNotBlank(dictionaryItemQueryCmd.getDictionaryCode())) {
                WHERE("dictionaryCode = #{item.dictionaryCode}");
            }
            ORDER_BY("id DESC");
        }}.toString();
    }

}
