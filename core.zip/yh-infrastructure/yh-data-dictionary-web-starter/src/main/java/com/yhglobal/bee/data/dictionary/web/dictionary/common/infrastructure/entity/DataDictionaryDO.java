package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity;

import lombok.Data;
import lombok.experimental.Accessors;
import com.yhglobal.bee.mybatis.common.entity.BaseMybatisEntity;
import java.io.Serializable;

@Data
@Accessors(chain = true)
public class DataDictionaryDO extends BaseMybatisEntity implements Serializable {

    /**
     * 数据字典编码
     */
    private String dictionaryCode;

    /**
     * 字段名
     */
    private String dictionaryName;

    /**
     * 字段描述
     */
    private String dictionaryDescription;

    /**
     * 是否禁用
     */
    private Integer enableFlag;


}
