package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledConnection;
import com.mysql.cj.jdbc.ConnectionImpl;
import com.yhglobal.bee.data.dictionary.common.bootstrap.properties.YhDictionaryProperties;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.domain.gateway.DictionaryGateway;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author zhengkaizhou
 * @date 2022/11/4 15:25
 */
@Component
@RequiredArgsConstructor
@Order(-2)
public class DictionaryDataBaseConfig implements CommandLineRunner {

    private final DictionaryGateway dictionaryGateway;

    private final YhDictionaryProperties properties;

    private final DruidDataSource druidDataSource;

    @Override
    public void run(String... args) throws Exception {
        if (properties.getEnable() && properties.getDataBaseEnable()){
            // 获取数据库连接名
            DruidPooledConnection connection = druidDataSource.getConnection();
            ConnectionImpl connection2 = (ConnectionImpl) connection.getConnection();
            String database = connection2.getDatabase();
            dictionaryGateway.managementDataBase(database);
        }
    }
}
