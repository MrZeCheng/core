package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author zhengkaizhou
 * @date 2022/11/8 9:10
 */
@Documented
@Retention(RUNTIME)
@Target(TYPE)
public @interface TableManagement {
    /**
     * 表名称
     */
    String tableName();

    /**
     * resources目录sql文件中创建表语句的索引位置
     */
    int sqlIndex();
}
