package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.Query;

public class DictionaryQueryCmd extends Query {

    private String dictionaryCode;
    private String dictionaryItemId;

    public String getDictionaryCode() {
        return dictionaryCode;
    }

    public DictionaryQueryCmd setDictionaryCode(String dictionaryCode) {
        this.dictionaryCode = dictionaryCode;
        return this;
    }

    public String getDictionaryItemId() {
        return dictionaryItemId;
    }

    public DictionaryQueryCmd setDictionaryItemId(String dictionaryItemId) {
        this.dictionaryItemId = dictionaryItemId;
        return this;
    }
}
