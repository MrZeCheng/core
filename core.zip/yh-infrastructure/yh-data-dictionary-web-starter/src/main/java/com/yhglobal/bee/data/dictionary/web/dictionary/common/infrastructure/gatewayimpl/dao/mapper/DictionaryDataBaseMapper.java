package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * @author zhengkaizhou
 * @date 2022/11/4 15:31
 */
@Mapper
public interface DictionaryDataBaseMapper {

    /**
     * 查询库中是否存在表
     * @param database 数据库名称
     * @param tableName 表名称
     * @return 计数
     */
    @Select({
            "SELECT COUNT(1) FROM information_schema.tables",
            "WHERE table_schema = #{database}",
            "AND table_name = #{tableName}"
    })
    Integer countByDatabase(@Param("database")String database, @Param("tableName") String tableName);

    /**
     * 创建表
     * @param sql 创建表的sql语句
     * @return 判断是否成功
     */
    @Update({
            "${sql}"
    })
    Integer createTable(@Param("sql")String sql);
}
