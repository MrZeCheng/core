package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.DTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel
public class DictionaryItemQueryCmd extends DTO {

    /**
     * 字典编码
     */
    private String dictionaryCode;

    /**
     * 是否禁用
     */
    private Integer enableFlag;

}
