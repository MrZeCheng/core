package com.yhglobal.bee.data.dictionary.web.dictionary.common.adapter;

import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryAllQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryDTO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemCreateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemEnableCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.service.DictionaryService;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryItemDO;
import com.yhglobal.bee.bean.data.dictionary.DataDictionaryCmd;
import com.yhglobal.bee.bean.data.dictionary.InitDataDictionaryCmd;
import com.yhglobal.bee.common.annotation.AuthorityValidate;
import com.yhglobal.bee.common.constant.KeyValueObject;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.data.dictionary.common.bootstrap.properties.YhDictionaryProperties;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("${yh.data.dictionary.registration.path:/authority/dictionary}")
@Api(tags = {"Dictionary"})
public class DictionaryController {

    private final DictionaryService dictionaryService;

    private final YhDictionaryProperties yhDictionaryProperties;

    @PostMapping(value = "/init")
    public SingleResponse<String> initDictionaryCode(@RequestBody InitDataDictionaryCmd initDataDictionaryCmd) {
        return dictionaryService.initDictionaryCode(initDataDictionaryCmd);
    }

    @PostMapping(value = "/get")
    public SingleResponse<DictionaryDTO> findDictionaryDTO(@RequestBody DictionaryQueryCmd dictionaryQueryCmd) {
        return dictionaryService.findDictionaryDTO(dictionaryQueryCmd);
    }

    @PostMapping(value = "/findAll")
    public MultiResponse<DictionaryDTO> findAllDictionaryDTO(@RequestBody DictionaryAllQueryCmd dictionaryAllQueryCmd) {
        return dictionaryService.findAllDictionaryDTO(dictionaryAllQueryCmd);
    }

    /**
     * 注册字典
     *
     * @author weizecheng
     * @date 2021/8/24 14:28
     */
    @PostMapping(value = "/registration")
    public YhResponse registrationDataDictionary(@RequestBody DataDictionaryCmd dataDictionaryCmd) {
        return dictionaryService.registrationDataDictionary(dataDictionaryCmd);
    }


    @PostMapping(value = "/list")
    @AuthorityValidate
    @ApiOperation(value = "获取数据字典", notes = "获取数据字典")
    public PageResponse<DataDictionaryDO> findAllByPage(@RequestBody DictionaryQueryPageCmd dictionaryQueryPageCmd) {
        return dictionaryService.findAllByPage(dictionaryQueryPageCmd);
    }

    @PostMapping(value = "/update")
    @AuthorityValidate
    @ApiOperation(value = "更新数据字典", notes = "更新数据字典")
    public YhResponse updateDictionary(@RequestBody DictionaryUpdateCmd dictionaryUpdateCmd) {
        return dictionaryService.updateDictionary(dictionaryUpdateCmd);
    }


    @PostMapping(value = "/item")
    @ApiOperation(value = "获取字典明细", notes = "获取字典明细")
    public MultiResponse<DataDictionaryItemDO> findDataDictionaryItem(@RequestBody DictionaryItemQueryCmd dictionaryItemQueryCmd) {
        return dictionaryService.findDataDictionaryItem(dictionaryItemQueryCmd);
    }

    /**
     * @return
     */
    @PostMapping(value = "/all")
    @ApiOperation(value = "获取可用字典", notes = "获取可用字典")
    public MultiResponse<KeyValueObject> findAllEnableByDictionaryCode(@RequestBody DictionaryItemQueryCmd dictionaryItemQueryCmd) {
        return dictionaryService.findAllEnableByDictionaryCode(dictionaryItemQueryCmd);
    }


    /**
     * 更新数据字典
     *
     * @author weizecheng
     * @date 2021/8/25 14:29
     */
    @PostMapping(value = "/updateItem")
    @AuthorityValidate
    @ApiOperation(value = "更新字典明细", notes = "更新字典明细")
    public YhResponse updateDictionaryItem(@RequestBody DictionaryItemUpdateCmd dictionaryItemUpdateCmd) {
        return dictionaryService.updateDictionaryItem(dictionaryItemUpdateCmd);
    }

    /**
     * 创建数据字典
     *
     * @author weizecheng
     * @date 2021/8/25 14:29
     */
    @PostMapping(value = "/createItem")
    @AuthorityValidate
    @ApiOperation(value = "创建字典明细", notes = "创建字典明细")
    public YhResponse createDictionaryItem(@RequestBody DictionaryItemCreateCmd dictionaryItemCreateCmd) {
        return dictionaryService.createDictionaryItem(dictionaryItemCreateCmd);
    }

    /**
     * 启用字典
     *
     * @author weizecheng
     * @date 2021/8/25 14:29
     */
    @PostMapping(value = "/enableItem")
    @AuthorityValidate
    @ApiOperation(value = "启用字典明细", notes = "启用字典明细")
    public YhResponse enableDictionaryItem(@RequestBody DictionaryItemEnableCmd dictionaryItemEnableCmd) {
        return dictionaryService.enableDictionaryItem(dictionaryItemEnableCmd);
    }

    /**
     * 禁用字典
     *
     * @param dictionaryItemEnableCmd
     * @return
     */
    @PostMapping(value = "/disableItem")
    @AuthorityValidate
    @ApiOperation(value = "禁用字典明细", notes = "禁用字典明细")
    public YhResponse disableDictionaryItem(@RequestBody DictionaryItemEnableCmd dictionaryItemEnableCmd) {
        return dictionaryService.disableDictionaryItem(dictionaryItemEnableCmd);
    }

}
