package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper;

import com.yhglobal.bee.common.constant.base.MybatisBaseFieldConstant;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryQueryPageCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.TableManagement;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.provider.DictionarySqlProvider;
import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.UpdateProvider;

import java.util.List;

@Mapper
@DataInsertAndUpdate
@DataTombstone
@TableManagement(tableName = "foundation_mdm_dictionary", sqlIndex = 2)
public interface DataDictionaryMapper {

    String SQL = MybatisBaseFieldConstant.BASE + "dictionaryCode, dictionaryName, dictionaryDescription, enableFlag";


    @Insert({
            "insert into foundation_mdm_dictionary (createdDate, ",
            "modifiedDate, dataVersion, ",
            "createdName, modifiedName, ",
            "deleteFlag, dictionaryCode, ",
            "dictionaryName, dictionaryDescription, ",
            "enableFlag)",
            "values (#{createdDate,jdbcType=TIMESTAMP}, ",
            "#{modifiedDate,jdbcType=TIMESTAMP}, #{dataVersion,jdbcType=BIGINT}, ",
            "#{createdName,jdbcType=VARCHAR}, #{modifiedName,jdbcType=VARCHAR}, ",
            "#{deleteFlag,jdbcType=INTEGER}, #{dictionaryCode,jdbcType=VARCHAR}, ",
            "#{dictionaryName,jdbcType=VARCHAR}, #{dictionaryDescription,jdbcType=VARCHAR}, ",
            "#{enableFlag,jdbcType=INTEGER})"
    })
    int insert(DataDictionaryDO record);


    @Select({
            "select",
            "COUNT(*)",
            "from foundation_mdm_dictionary",
            "WHERE dictionaryCode = #{dictionaryCode}"
    })
    Integer countByDictionaryCode(@Param("dictionaryCode") String dictionaryCode);

    @SelectProvider(type = DictionarySqlProvider.class, method = "findAllByPage")
    List<DataDictionaryDO> findAllByPage(@Param("order") DictionaryQueryPageCmd dictionaryQueryPageCmd);

    @UpdateProvider(type = DictionarySqlProvider.class, method = "update")
    int updateDictionary(@Param("order") DictionaryUpdateCmd dictionaryUpdateCmd);

    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary",
            "WHERE dictionaryCode = #{dictionaryCode}"
    })
    DataDictionaryDO findByDictionaryCode(@Param("dictionaryCode") String dictionaryCode);


}
