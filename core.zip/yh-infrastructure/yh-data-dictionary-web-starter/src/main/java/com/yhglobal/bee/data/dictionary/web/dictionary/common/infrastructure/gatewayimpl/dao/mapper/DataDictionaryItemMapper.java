package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper;

import com.yhglobal.bee.common.constant.base.MybatisBaseFieldConstant;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemQueryCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto.DictionaryItemUpdateCmd;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.TableManagement;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity.DataDictionaryItemDO;
import com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.gatewayimpl.dao.mapper.provider.DictionarySqlProvider;
import com.yhglobal.bee.common.annotation.mybaits.DataInsertAndUpdate;
import com.yhglobal.bee.common.annotation.mybaits.DataTombstone;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;

import java.util.List;

@Mapper
@DataInsertAndUpdate
@DataTombstone
@TableManagement(tableName = "foundation_mdm_dictionary_item", sqlIndex = 1)
public interface DataDictionaryItemMapper {

    String SQL = MybatisBaseFieldConstant.BASE + "dictionaryItemId, dictionaryItemValue, dictionaryCode, dictionaryName, enableFlag,spareField1,spareFieldDescribe1,spareField2,spareFieldDescribe2,spareField3,spareFieldDescribe3,spareField4,spareFieldDescribe4,spareField5,spareFieldDescribe5";


    @Insert({
            "insert into foundation_mdm_dictionary_item ( createdDate, ",
            "modifiedDate, dataVersion, ",
            "createdName, modifiedName, ",
            "deleteFlag, dictionaryItemId, ",
            "dictionaryItemValue, dictionaryCode, ",
            "dictionaryName, enableFlag,spareField1,spareFieldDescribe1,spareField2,spareFieldDescribe2,spareField3,spareFieldDescribe3,spareField4,spareFieldDescribe4,spareField5,spareFieldDescribe5)",
            "values (#{createdDate,jdbcType=TIMESTAMP}, ",
            "#{modifiedDate,jdbcType=TIMESTAMP}, #{dataVersion,jdbcType=BIGINT}, ",
            "#{createdName,jdbcType=VARCHAR}, #{modifiedName,jdbcType=VARCHAR}, ",
            "#{deleteFlag,jdbcType=INTEGER}, #{dictionaryItemId,jdbcType=VARCHAR}, ",
            "#{dictionaryItemValue,jdbcType=VARCHAR}, #{dictionaryCode,jdbcType=VARCHAR}, ",
            "#{dictionaryName,jdbcType=VARCHAR}, #{enableFlag,jdbcType=INTEGER},#{spareField1,jdbcType=VARCHAR},#{spareFieldDescribe1,jdbcType=VARCHAR},#{spareField2,jdbcType=VARCHAR},#{spareFieldDescribe2,jdbcType=VARCHAR},#{spareField3,jdbcType=VARCHAR},#{spareFieldDescribe3,jdbcType=VARCHAR},#{spareField4,jdbcType=VARCHAR},#{spareFieldDescribe4,jdbcType=VARCHAR},#{spareField5,jdbcType=VARCHAR},#{spareFieldDescribe5,jdbcType=VARCHAR})"
    })
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(DataDictionaryItemDO record);

    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary_item",
            "where enableFlag = #{enableFlag,jdbcType=INTEGER}"
    })
    List<DataDictionaryItemDO> findAllEnableFlag(@Param("enableFlag") Integer enableFlag);


    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary_item"
    })
    List<DataDictionaryItemDO> findAll();

    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary_item",
            "where dictionaryCode = #{dictionaryCode}"
    })
    List<DataDictionaryItemDO> findAllByDictionaryCode(@Param("dictionaryCode") String dictionaryCode);


    @SelectProvider(type = DictionarySqlProvider.class, method = "select")
    List<DataDictionaryItemDO> findAllByDictionaryCodeAndEnableFlag(@Param("item") DictionaryItemQueryCmd dictionaryItemQueryCmd);

    @Select({
            "select",
            SQL,
            "from foundation_mdm_dictionary_item",
            "where dictionaryCode = #{dictionaryCode,jdbcType=VARCHAR} AND dictionaryItemId = #{dictionaryItemId,jdbcType=VARCHAR}"
    })
    DataDictionaryItemDO findByDictionaryCodeAndDictionaryItemId(@Param("dictionaryCode") String dictionaryCode, @Param("dictionaryItemId") String dictionaryItemId);


    @UpdateProvider(type = DictionarySqlProvider.class, method = "updateItem")
    int updateDictionaryItemValue(@Param("order") DictionaryItemUpdateCmd dictionaryItemUpdateCmd);

    @Update({
            "update foundation_mdm_dictionary_item",
            "set ",
            "enableFlag = #{enableFlag}",
            "where id = #{id}",
    })
    int updateEnableFlag(@Param("id") Long id, @Param("enableFlag") Integer enableFlag);

}
