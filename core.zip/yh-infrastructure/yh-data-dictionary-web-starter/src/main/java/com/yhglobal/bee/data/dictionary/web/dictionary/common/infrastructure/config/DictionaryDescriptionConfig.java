package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.config;

import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;
import lombok.RequiredArgsConstructor;
import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author zhengkaizhou
 * @date 2022/11/1 10:47
 */
@Component
@RequiredArgsConstructor
@Order
public class DictionaryDescriptionConfig implements CommandLineRunner {

    private final static Map<String, YhDataDictionaryI> DESCRIPTION_MAP = new ConcurrentHashMap<>(16);

    @Override
    public void run(String... args){
        Reflections reflections = new Reflections(new ConfigurationBuilder().forPackage(ScanConstant.BASE_SCAN_ADDRESS));
        Set<Class<? extends YhDataDictionaryI>> dataDictionaries = reflections.getSubTypesOf(YhDataDictionaryI.class);
        for (Class<? extends YhDataDictionaryI> dictionary : dataDictionaries) {
            if (dictionary.isEnum()){
                YhDataDictionaryI[] constants = dictionary.getEnumConstants();
                for (YhDataDictionaryI constant : constants) {
                    DESCRIPTION_MAP.put(constant.getCode(), constant);
                }
            }
        }
    }

    public static Map<String, YhDataDictionaryI> getDescriptionMap(){
        return DESCRIPTION_MAP;
    }
}
