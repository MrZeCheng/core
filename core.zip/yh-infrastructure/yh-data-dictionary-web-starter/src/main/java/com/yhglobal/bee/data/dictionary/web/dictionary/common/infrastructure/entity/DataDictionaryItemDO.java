package com.yhglobal.bee.data.dictionary.web.dictionary.common.infrastructure.entity;

import com.yhglobal.bee.mybatis.common.entity.BaseMybatisEntity;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
@Data
@Accessors(chain = true)
public class DataDictionaryItemDO extends BaseMybatisEntity implements Serializable {

    /**
     * 字典Id
     */
    private String dictionaryItemId;

    /**
     * 字典值
     */
    private String dictionaryItemValue;

    /**
     * 字典编码
     */
    private String dictionaryCode;

    /**
     * 字典名称
     */
    private String dictionaryName;

    /**
     * 备用字段
     */
    private String spareField1;

    /**
     * 备用字段
     */
    private String spareFieldDescribe1;

    /**
     * 备用字段
     */
    private String spareField2;

    /**
     * 备用字段
     */
    private String spareFieldDescribe2;

    /**
     * 备用字段
     */
    private String spareField3;

    /**
     * 备用字段
     */
    private String spareFieldDescribe3;


    /**
     * 备用字段
     */
    private String spareField4;

    /**
     * 备用字段
     */
    private String spareFieldDescribe4;

    /**
     * 备用字段
     */
    private String spareField5;

    /**
     * 备用字段
     */
    private String spareFieldDescribe5;

    /**
     * 是否禁用
     */
    private Integer enableFlag;

}
