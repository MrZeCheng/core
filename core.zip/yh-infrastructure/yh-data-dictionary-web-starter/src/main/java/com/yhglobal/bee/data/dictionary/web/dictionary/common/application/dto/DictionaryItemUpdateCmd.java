package com.yhglobal.bee.data.dictionary.web.dictionary.common.application.dto;

import com.yhglobal.bee.common.dto.DTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel
public class DictionaryItemUpdateCmd extends DTO {


    /**
     * 字典Id
     */
    private String dictionaryItemId;

    /**
     * 字典值
     */
    private String dictionaryItemValue;

    /**
     * 字典编码
     */
    private String dictionaryCode;

    /**
     * 备用字段
     */
    private String spareField1;

    /**
     * 备用字段
     */
    private String spareFieldDescribe1;


    /**
     * 备用字段
     */
    private String spareField2;

    /**
     * 备用字段
     */
    private String spareFieldDescribe2;

    /**
     * 备用字段
     */
    private String spareField3;

    /**
     * 备用字段
     */
    private String spareFieldDescribe3;


    /**
     * 备用字段
     */
    private String spareField4;

    /**
     * 备用字段
     */
    private String spareFieldDescribe4;

    /**
     * 备用字段
     */
    private String spareField5;

    /**
     * 备用字段
     */
    private String spareFieldDescribe5;

    private Long id;
}
