package com.yhglobal.bee.jpa.common.converter;

import com.yhglobal.bee.common.dto.PageResponse;
import org.springframework.data.domain.Page;

public class PageConverter {

    /**
     * jpa分页于页面分页直接的转换
     *
     * @author weizecheng
     * @date 2021/3/22 13:18
     */
    public static <T> PageResponse<T> of(Page<T> data) {
        PageResponse<T> response = new PageResponse<>();
        response.setSuccess(true);
        response.setData(data.toList());
        response.setTotalCount(data.getTotalElements());
        response.setPageSize(data.getSize());
        response.setPageIndex(data.getNumber());
        return response;
    }

}
