package com.yhglobal.bee.jpa.common.interceptors;

import com.yhglobal.bee.jpa.common.constant.SubTableConstant;
import com.yhglobal.bee.jpa.common.constant.SubTableModel;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
import org.springframework.stereotype.Component;

import java.util.Locale;


@Component
public class YhSubTableStrategy implements PhysicalNamingStrategy {

    @Override
    public Identifier toPhysicalCatalogName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        return apply(name, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalSchemaName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        return apply(name, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        return applySubTable(name, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalSequenceName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        return apply(name, jdbcEnvironment);
    }

    @Override
    public Identifier toPhysicalColumnName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        return applyColumnName(name, jdbcEnvironment);
    }


    /**
     * 如果是 userName 会变为user_Name
     *
     * 因为 isCaseInsensitive 始终返回true
     *
     * 所以最终 user_Name 返回 user_name
     *
     * @param name
     * @param jdbcEnvironment
     * @return
     */
    private Identifier apply(Identifier name, JdbcEnvironment jdbcEnvironment) {
        if (name == null) {
            return null;
        }
        StringBuilder builder = humpToUnderline(name.getText().replace('.', '_'));
        return getIdentifier(builder.toString(), name.isQuoted(), jdbcEnvironment);
    }

    private Identifier applyColumnName(Identifier name, JdbcEnvironment jdbcEnvironment) {
        if (name == null) {
            return null;
        }
        return getIdentifierName(name.getText().replace('.', '_'), name.isQuoted(), jdbcEnvironment);
    }




    private static final String PREFIX = "prefix_";

    /**
     * 修改表名称的策略
     * @param name
     * @param jdbcEnvironment
     * @return
     */
    private Identifier applySubTable(Identifier name, JdbcEnvironment jdbcEnvironment) {
        if (name == null) {
            return null;
        }
        String tableName = name.getText().replace('.', '_');
        // 获取线程中的存储的表前缀
        SubTableModel subTableModel = SubTableConstant.getSubTabl();
        if(subTableModel != null){
            if(tableName.contains(PREFIX)){
                tableName = tableName.replace(PREFIX,subTableModel.getPrefix()+"_");
            }
        }
        StringBuilder builder = humpToUnderline(tableName);
        return getIdentifier(builder.toString(), name.isQuoted(), jdbcEnvironment);
    }




    /**
     * 驼峰转下划线
     *
     * @author weizecheng
     * @date 2021/3/19 9:49
     */
    private StringBuilder humpToUnderline(String str){
        StringBuilder builder = new StringBuilder(str);
        for (int i = 1; i < builder.length() - 1; i++) {
            if (isUnderscoreRequired(builder.charAt(i - 1), builder.charAt(i), builder.charAt(i + 1))) {
                builder.insert(i++, '_');
            }
        }
        return builder;
    }


    /**
     * Get an identifier for the specified details. By default this method will return an
     * identifier with the name adapted based on the result of
     * {@link #isCaseInsensitive(JdbcEnvironment)}
     * @param name the name of the identifier
     * @param quoted if the identifier is quoted
     * @param jdbcEnvironment the JDBC environment
     * @return an identifier instance
     */
    protected Identifier getIdentifier(String name, boolean quoted, JdbcEnvironment jdbcEnvironment) {
        if (isCaseInsensitive(jdbcEnvironment)) {
            name = name.toLowerCase(Locale.ROOT);
        }
        return new Identifier(name, quoted);
    }

    private Identifier getIdentifierName(String name, boolean quoted, JdbcEnvironment jdbcEnvironment) {

        return new Identifier(name, quoted);
    }

    /**
     * Specify whether the database is case sensitive.
     * @param jdbcEnvironment the JDBC environment which can be used to determine case
     * @return true if the database is case insensitive sensitivity
     */
    protected boolean isCaseInsensitive(JdbcEnvironment jdbcEnvironment) {
        return true;
    }

    private boolean isUnderscoreRequired(char before, char current, char after) {
        return Character.isLowerCase(before) && Character.isUpperCase(current) && Character.isLowerCase(after);
    }

}
