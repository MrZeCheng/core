package com.yhglobal.bee.jpa.common.interceptors;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

import java.io.Serializable;

/**
 *
 * spring.jpa.properties.hibernate.ejb.interceptor=com.smile.config.hibernate.HibernateInterceptor
 *
 * @author weizecheng
 * @date 2021/3/25 12:02
 */
public class DataPermissionJpaInterceptor extends EmptyInterceptor {

    @Override
    public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
        return super.onLoad(entity, id, state, propertyNames, types);
    }

    @Override
    public String onPrepareStatement(String sql) {
        return super.onPrepareStatement(sql);
    }
}
