package com.yhglobal.bee.jpa.common.entity;

import com.yhglobal.bee.jpa.common.constant.SubTableConstant;
import com.yhglobal.bee.jpa.common.constant.SubTableModel;

import java.io.Closeable;

/**
 *  释放分表资源的对象
 *
 * @author weizecheng
 * @date 2021/3/23 9:28
 */
public class SubTableResources implements Closeable {

    public SubTableResources(SubTableModel subTableModel){
        SubTableConstant.remove();
        SubTableConstant.setSubTable(subTableModel);
    }

    @Override
    public void close() {
        SubTableConstant.remove();
    }
}
