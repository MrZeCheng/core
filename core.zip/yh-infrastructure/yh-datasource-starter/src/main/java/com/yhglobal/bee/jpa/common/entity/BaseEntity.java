package com.yhglobal.bee.jpa.common.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 公用模型
 *
 * @author weizecheng
 * @date 2021/1/27 14:25
 */
@Data
@Accessors(chain = true)
@MappedSuperclass
public abstract class BaseEntity {
    /**
     * 主键Id
     */
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    Long id;
    /**
     * 创建时间
     */
    @CreatedDate
    @Column(name = "createdDate",columnDefinition = "datetime  COMMENT '创建时间'")
    LocalDateTime createdDate;

    /**
     * 最后修改时间
     */
    @LastModifiedDate
    @Column(name = "modifiedDate",columnDefinition = "datetime COMMENT '更新时间'")
    @JsonIgnore
    LocalDateTime modifiedDate;

    @Version
    @JsonIgnore
    @Column(name = "dataVersion",columnDefinition = "bigint(20) default 0 COMMENT '权限类型'")
    Long dataVersion;

//    @CreatedBy
//    @LastModifiedBy
}
