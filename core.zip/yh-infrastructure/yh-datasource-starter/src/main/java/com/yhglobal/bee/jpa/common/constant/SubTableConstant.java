package com.yhglobal.bee.jpa.common.constant;

public class SubTableConstant {

    /**
     * 用来
     *
     * @author weizecheng
     * @date 2021/3/19 10:13
     */
    private static final ThreadLocal<SubTableModel> SUB_TABLE_MODEL_THREAD_LOCAL = new ThreadLocal<>();

    public static SubTableModel getSubTabl() {
        return SUB_TABLE_MODEL_THREAD_LOCAL.get();
    }

    public static void setSubTable(SubTableModel subTableModel){
        SUB_TABLE_MODEL_THREAD_LOCAL.set(subTableModel);
    }

    public static void remove(){
        SUB_TABLE_MODEL_THREAD_LOCAL.remove();
    }

}
