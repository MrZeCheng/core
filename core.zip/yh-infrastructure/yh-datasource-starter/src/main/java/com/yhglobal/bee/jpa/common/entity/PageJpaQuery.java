package com.yhglobal.bee.jpa.common.entity;

import com.yhglobal.bee.common.dto.PageQuery;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

/**
 * jpa使用的分页参数
 *
 * @author weizecheng
 * @date 2021/3/22 12:48
 */
public abstract class PageJpaQuery  extends PageQuery {


    public Pageable toPageable(){
        return PageRequest.of(this.getPageIndex(),this.getPageSize(),
                Sort.by(this.getOrderDirection(),
                        StringUtils.isBlank(this.getOrderBy()) ? "id" : this.getOrderBy() ));
    }

}
