package com.yhglobal.bee.jpa.common.constant;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class SubTableModel {

    /**
     * 替换的表前缀
     */
    private String prefix;


}
