package com.yhglobal.bee.mdm.data.common.service;

import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.mdm.data.common.constant.MdmMessageType;
import com.yhglobal.bee.mdm.data.common.model.MdmDataRequest;

public interface MdmDataService {

    YhResponse initMdmData(MdmDataRequest mdmDataRequest);

    void initMdmDataSql(MdmMessageType mdmMessageType);

    void initMdmApi();


}
