package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmWarehouse extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : WAREHOUSE
     * Data : {"Address":"TEST01","Area":"南山区","City":"深圳市","Code":"W220002","ContactName":"TEST2","ContactPhone":"TEST2","Dimensions":"1","Empty":true,"Enable":true,"FullAddress":"广东省深圳市南山区TEST01","LastModificationTime":"2022-08-31T10:36:58.951036","Name":"测试仓011","Province":"广东省","RealWarehouseId":null,"Type":"普通","Volume":"2"}
     */
    @JsonProperty("Address")
    private String address;
    @JsonProperty("Area")
    private String area;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("ContactName")
    private String contactName;
    @JsonProperty("ContactPhone")
    private String contactPhone;
    @JsonProperty("Dimensions")
    private String dimensions;
    @JsonProperty("Empty")
    private Boolean empty;
    @JsonProperty("Enable")
    private Boolean enable;
    @JsonProperty("FullAddress")
    private String fullAddress;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Province")
    private String province;
    @JsonProperty("RealWarehouseId")
    private String realWarehouseId;
    @JsonProperty("Type")
    private String type;
    @JsonProperty("Volume")
    private String volume;

    @Override
    public String toString() {
        return "MdmWarehouse{" +
                "address='" + address + '\'' +
                ", area='" + area + '\'' +
                ", city='" + city + '\'' +
                ", code='" + code + '\'' +
                ", contactName='" + contactName + '\'' +
                ", contactPhone='" + contactPhone + '\'' +
                ", dimensions='" + dimensions + '\'' +
                ", empty=" + empty +
                ", enable=" + enable +
                ", fullAddress='" + fullAddress + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", name='" + name + '\'' +
                ", province='" + province + '\'' +
                ", realWarehouseId='" + realWarehouseId + '\'' +
                ", type='" + type + '\'' +
                ", volume='" + volume + '\'' +
                '}';
    }
}
