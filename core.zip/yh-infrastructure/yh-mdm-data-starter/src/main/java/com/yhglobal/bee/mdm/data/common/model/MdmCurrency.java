package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;


@Data
public class MdmCurrency extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : CURRENCY
     * Data : {"BaseUnit":"澳大利亚币","Code":"E795B6D10AC02A66E050A8C07464CF35","EasId":"wEQAAApJeRzetY/c","EasNumber":"BB18","Enabled":"true","LastModificationTime":"2022-09-01T11:21:26+08:00","Name":"澳大利亚币","Number":"AUD","Precision":2,"Sign":null,"SimpleName":null,"SourceCreationTime":"2022-09-01T11:21:26+08:00","SourceCreator":"黄俊滨","SourceLastUpdater":"黄俊滨"}
     */
    @JsonProperty("BaseUnit")
    private String baseUnit;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("EasId")
    private String easId;
    @JsonProperty("EasNumber")
    private String easNumber;
    @JsonProperty("Enabled")
    private String enabled;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("Precision")
    private Integer precisionNumber;
    @JsonProperty("Sign")
    private String sign;
    @JsonProperty("SimpleName")
    private String simpleName;
    @JsonProperty("SourceCreationTime")
    private String sourceCreationTime;
    @JsonProperty("SourceCreator")
    private String sourceCreator;
    @JsonProperty("SourceLastUpdater")
    private String sourceLastUpdater;

    @Override
    public String toString() {
        return "MdmCurrency{" +
                "baseUnit='" + baseUnit + '\'' +
                ", code='" + code + '\'' +
                ", easId='" + easId + '\'' +
                ", easNumber='" + easNumber + '\'' +
                ", enabled='" + enabled + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", precisionNumber=" + precisionNumber +
                ", sign='" + sign + '\'' +
                ", simpleName='" + simpleName + '\'' +
                ", sourceCreationTime='" + sourceCreationTime + '\'' +
                ", sourceCreator='" + sourceCreator + '\'' +
                ", sourceLastUpdater='" + sourceLastUpdater + '\'' +
                '}';
    }
}
