package com.yhglobal.bee.mdm.data.common.mapper;

import com.yhglobal.bee.mdm.data.common.mapper.provider.MdmDataProvider;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;


@Mapper
public interface MdmDataMapper {
    @Select({
            "select COUNT(*)",
            "from mdm_${mdmTableName} ",
            "where code = #{code}",
    })
    Integer countMdmData(@Param("mdmTableName")String mdmTableName, @Param("code")String code);


    @Select({
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE table_name = #{mdmTableName}",
    })
    int countTableName(@Param("mdmTableName")String mdmTableName);

    @Select({
            "select *",
            "from mdm_${mdmTableName} ",
            "where code = #{code}",
    })
    Map<String,Object> findByCode(@Param("mdmTableName")String mdmTableName, @Param("code")String code);


    @SelectProvider(type = MdmDataProvider.class, method="findAll")
    List<Map<String,Object>> findAll(@Param("mdmTableName")String mdmTableName,
                                     @Param("code")String code,
                                     @Param("name")String name);
    @Select({
            "${customSql}"
    })
    List<Map<String,Object>> customSql(@Param("customSql")String customSql);

    @Update({
            "${sql}"
    })
    int createCreateSql(@Param("sql") String sql);

    @InsertProvider(type = MdmDataProvider.class,method="insertMdmData")
    int insert(@Param("mdmTableName")String mdmTableName,
               @Param("columnName")String columnName,
               @Param("columnValueName")String columnValueName,
               @Param("order")Object order);

    @UpdateProvider(type = MdmDataProvider.class, method="updateMdmData")
    int update(@Param("mdmTableName")String mdmTableName,
               @Param("updateSql")String updateSql,
               @Param("order")Object order);
}
