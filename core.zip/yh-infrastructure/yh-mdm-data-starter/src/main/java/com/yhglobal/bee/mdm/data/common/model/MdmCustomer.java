package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmCustomer extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : CUSTOMER
     * Data : {"AccountType":"外部客户","BalanceToName":null,"BalanceToNumber":null,"BusienessType":null,"BusienessTypeCode":null,"Code":"LCS2022091308366","CooperationTime":null,"CreateTime":"2022-09-13T02:21:06Z","CustomerLevel":"普通客户","EasCode":null,"EnglishName":null,"IsValid":true,"LastModificationTime":"2022-09-13T02:26:06Z","LostTime":null,"Name":"CHI NHÁNH CÔNG TY TNHH M&R FORWARDING TẠI HÀ NỘI M&R FORWARDING CO., LTD. HANOI BRANCH","OldName":null,"OperationsAddress":"24-26 Trieu Viet Vuong Str., Nguyen Du Ward, Hai Ba Trung District, Ha Noi, Vietnam","OwnerName":"潘琴","OwnerNumber":"005859","ParentName":null,"ParentNumber":null,"Phone":"84 024 6287 6388","RecordTypeApi":"Account","RecordTypeName":"客户","RegisteredAddress":"24-26 Trieu Viet Vuong Str., Nguyen Du Ward, Hai Ba Trung District, Ha Noi, Vietnam","ServiceType":null,"ServiceTypeCode":null,"SimpleName":"M&R越南","TaxID":"0312984687-001","WorkType":"物流"}
     */

    @JsonProperty("AccountType")
    private String accountType;
    @JsonProperty("BalanceToName")
    private String balanceToName;
    @JsonProperty("BalanceToNumber")
    private String balanceToNumber;
    @JsonProperty("BusienessType")
    private String busienessType;
    @JsonProperty("BusienessTypeCode")
    private String busienessTypeCode;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CooperationTime")
    private String cooperationTime;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("CustomerLevel")
    private String customerLevel;
    @JsonProperty("EasCode")
    private String easCode;
    @JsonProperty("EnglishName")
    private String englishName;
    @JsonProperty("IsValid")
    private Boolean isValid;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("LostTime")
    private String lostTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OldName")
    private String oldName;
    @JsonProperty("OperationsAddress")
    private String operationsAddress;
    @JsonProperty("OwnerName")
    private String ownerName;
    @JsonProperty("OwnerNumber")
    private String ownerNumber;
    @JsonProperty("ParentName")
    private String parentName;
    @JsonProperty("ParentNumber")
    private String parentNumber;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("RecordTypeApi")
    private String recordTypeApi;
    @JsonProperty("RecordTypeName")
    private String recordTypeName;
    @JsonProperty("RegisteredAddress")
    private String registeredAddress;
    @JsonProperty("ServiceType")
    private String serviceType;
    @JsonProperty("ServiceTypeCode")
    private String serviceTypeCode;
    @JsonProperty("SimpleName")
    private String simpleName;
    @JsonProperty("TaxID")
    private String taxId;
    @JsonProperty("WorkType")
    private String workType;

    @Override
    public String toString() {
        return "MdmCustomer{" +
                "accountType='" + accountType + '\'' +
                ", balanceToName='" + balanceToName + '\'' +
                ", balanceToNumber='" + balanceToNumber + '\'' +
                ", busienessType='" + busienessType + '\'' +
                ", busienessTypeCode='" + busienessTypeCode + '\'' +
                ", code='" + code + '\'' +
                ", cooperationTime='" + cooperationTime + '\'' +
                ", createTime='" + createTime + '\'' +
                ", customerLevel='" + customerLevel + '\'' +
                ", easCode='" + easCode + '\'' +
                ", englishName='" + englishName + '\'' +
                ", isValid=" + isValid +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", lostTime='" + lostTime + '\'' +
                ", name='" + name + '\'' +
                ", oldName='" + oldName + '\'' +
                ", operationsAddress='" + operationsAddress + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", ownerNumber='" + ownerNumber + '\'' +
                ", parentName='" + parentName + '\'' +
                ", parentNumber='" + parentNumber + '\'' +
                ", phone='" + phone + '\'' +
                ", recordTypeApi='" + recordTypeApi + '\'' +
                ", recordTypeName='" + recordTypeName + '\'' +
                ", registeredAddress='" + registeredAddress + '\'' +
                ", serviceType='" + serviceType + '\'' +
                ", serviceTypeCode='" + serviceTypeCode + '\'' +
                ", simpleName='" + simpleName + '\'' +
                ", taxId='" + taxId + '\'' +
                ", workType='" + workType + '\'' +
                '}';
    }
}
