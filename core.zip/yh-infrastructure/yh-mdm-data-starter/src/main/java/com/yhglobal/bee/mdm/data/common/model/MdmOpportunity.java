package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmOpportunity extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : OPPORTUNITY
     * Data : {"ActionArea":"华南","AdjustCycle":null,"AdvanceAmount":null,"AssureType":null,"BillingCurrency":"RMB","BusienessType":"境内零担运输;境内整车运输;快递;境内普通仓储;境内特殊监管仓储;境内代理报关;境外代理报关;代理报检;转DO;代办及单证服务","BusienessTypeCode":"HT01;HT02;EX01;WM03;WM04;CU01;CU02;CU03;AG01;AG03","Code":"PR2021091603856","CreateInvoiceDate":null,"CreateInvoiceEndDate":1,"CreateTime":"2021-09-16T09:20:10Z","CreditCurrency":null,"CustomerCode":"LCS2021091506672","CustomerName":"Hourglass Cosmetics Hong Kong Limited","CustomerRate":null,"EffectiveDate":null,"ExpireDate":null,"FixationRate":null,"InvoiceType":null,"IsAdvance":"否","IsValid":false,"LastModificationTime":"2022-09-12T16:00:09Z","MainOpportunityName":"字节跳动跨境电商项目","MainOpportunityNumber":"PR2021022303079","Name":"Hourglass字节跳动跨境电商项目","OwnerName":"胡瑶","OwnerNumber":"004684","PayDay":null,"PaymentBeginDate":1,"PaymentCycle":30,"PaymentType":"月结","PayType":null,"PeriodValidity":null,"ReconciliationEndDate":20,"RecordTypeApi":"NormalOpportunity","RecordTypeName":"附属业务机会","RoyaltyRatio":1,"ServiceType":"公路运输;快递;仓储;报关;代理服务","ServiceTypeCode":"HT;EX;WM;CU;AG","SignCompanyCode":"0206","SignText":"深圳市越海全球电商供应链有限公司","Tax":null,"TrustDay":null}
     */
    @JsonProperty("ActionArea")
    private String actionArea;
    @JsonProperty("AdjustCycle")
    private String adjustCycle;
    @JsonProperty("AdvanceAmount")
    private String advanceAmount;
    @JsonProperty("AssureType")
    private String assureType;
    @JsonProperty("BillingCurrency")
    private String billingCurrency;
    @JsonProperty("BusienessType")
    private String busienessType;
    @JsonProperty("BusienessTypeCode")
    private String busienessTypeCode;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateInvoiceDate")
    private String createInvoiceDate;
    @JsonProperty("CreateInvoiceEndDate")
    private Integer createInvoiceEndDate;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("CreditCurrency")
    private String creditCurrency;
    @JsonProperty("CustomerCode")
    private String customerCode;
    @JsonProperty("CustomerName")
    private String customerName;
    @JsonProperty("CustomerRate")
    private String customerRate;
    @JsonProperty("EffectiveDate")
    private String effectiveDate;
    @JsonProperty("ExpireDate")
    private String expireDate;
    @JsonProperty("FixationRate")
    private String fixationRate;
    @JsonProperty("InvoiceType")
    private String invoiceType;
    @JsonProperty("IsAdvance")
    private String isAdvance;
    @JsonProperty("IsValid")
    private Boolean isValid;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("MainOpportunityName")
    private String mainOpportunityName;
    @JsonProperty("MainOpportunityNumber")
    private String mainOpportunityNumber;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OwnerName")
    private String ownerName;
    @JsonProperty("OwnerNumber")
    private String ownerNumber;
    @JsonProperty("PayDay")
    private String payDay;
    @JsonProperty("PaymentBeginDate")
    private Integer paymentBeginDate;
    @JsonProperty("PaymentCycle")
    private Integer paymentCycle;
    @JsonProperty("PaymentType")
    private String paymentType;
    @JsonProperty("PayType")
    private String payType;
    @JsonProperty("PeriodValidity")
    private String periodValidity;
    @JsonProperty("ReconciliationEndDate")
    private Integer reconciliationEndDate;
    @JsonProperty("RecordTypeApi")
    private String recordTypeApi;
    @JsonProperty("RecordTypeName")
    private String recordTypeName;
    @JsonProperty("RoyaltyRatio")
    private Integer royaltyRatio;
    @JsonProperty("ServiceType")
    private String serviceType;
    @JsonProperty("ServiceTypeCode")
    private String serviceTypeCode;
    @JsonProperty("SignCompanyCode")
    private String signCompanyCode;
    @JsonProperty("SignText")
    private String signText;
    @JsonProperty("Tax")
    private String tax;
    @JsonProperty("TrustDay")
    private String trustDay;

    @Override
    public String toString() {
        return "MdmOpportunity{" +
                "actionArea='" + actionArea + '\'' +
                ", adjustCycle='" + adjustCycle + '\'' +
                ", advanceAmount='" + advanceAmount + '\'' +
                ", assureType='" + assureType + '\'' +
                ", billingCurrency='" + billingCurrency + '\'' +
                ", busienessType='" + busienessType + '\'' +
                ", busienessTypeCode='" + busienessTypeCode + '\'' +
                ", code='" + code + '\'' +
                ", createInvoiceDate='" + createInvoiceDate + '\'' +
                ", createInvoiceEndDate=" + createInvoiceEndDate +
                ", createTime='" + createTime + '\'' +
                ", creditCurrency='" + creditCurrency + '\'' +
                ", customerCode='" + customerCode + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerRate='" + customerRate + '\'' +
                ", effectiveDate='" + effectiveDate + '\'' +
                ", expireDate='" + expireDate + '\'' +
                ", fixationRate='" + fixationRate + '\'' +
                ", invoiceType='" + invoiceType + '\'' +
                ", isAdvance='" + isAdvance + '\'' +
                ", isValid=" + isValid +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", mainOpportunityName='" + mainOpportunityName + '\'' +
                ", mainOpportunityNumber='" + mainOpportunityNumber + '\'' +
                ", name='" + name + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", ownerNumber='" + ownerNumber + '\'' +
                ", payDay='" + payDay + '\'' +
                ", paymentBeginDate=" + paymentBeginDate +
                ", paymentCycle=" + paymentCycle +
                ", paymentType='" + paymentType + '\'' +
                ", payType='" + payType + '\'' +
                ", periodValidity='" + periodValidity + '\'' +
                ", reconciliationEndDate=" + reconciliationEndDate +
                ", recordTypeApi='" + recordTypeApi + '\'' +
                ", recordTypeName='" + recordTypeName + '\'' +
                ", royaltyRatio=" + royaltyRatio +
                ", serviceType='" + serviceType + '\'' +
                ", serviceTypeCode='" + serviceTypeCode + '\'' +
                ", signCompanyCode='" + signCompanyCode + '\'' +
                ", signText='" + signText + '\'' +
                ", tax='" + tax + '\'' +
                ", trustDay='" + trustDay + '\'' +
                '}';
    }
}
