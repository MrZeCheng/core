package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;


@Data
public class MdmContact extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MdsHeader : {"ClientIpAddress":"35.73.89.117","ComputerName":null,"TraceIdentifier":"0HMJUIFGTNQEV:00000001","SourceMessageId":"3a0646a9-97cf-6b29-99fb-5bd8b180d5f1","SupplierMessageId":"3a0646a9-97fe-a1be-3e54-10f693f1202e","SupplierId":"SalesForce","SupplierDataTypeId":"Contact","EntityId":"C2022091306630","EntityVersion":"2022-09-12T17:35:26","StandardMessageId":"3a0646a9-9850-83e4-836e-d004eff1867c","StandardObjectId":"contact","PartnerMessageId":"00000000-0000-0000-0000-000000000000","PartnerId":null,"SubscribePropertiesString":null}
     * MasterDataTypeCode : CONTACT
     * Data : {"Address":"张宇/18475441119/广东省深圳市南山区兴华工业大厦八栋AB座3楼3A2","Code":"C2022091306630","CreateTime":"2022-09-13T01:35:26Z","CustomerCode":"LCS2022091308364","CustomerName":"深圳市碧函时装有限公司","Department":null,"Email":null,"Fax":null,"LastModificationTime":"2022-09-13T01:35:26Z","MobilePhone":"18475441119","MobilePhone2":null,"Name":"张碧函","OwnerName":"朴莹","OwnerNumber":"006711","Phone":null,"Title":null}
     */
    @JsonProperty("Address")
    private String address;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("CustomerCode")
    private String customerCode;
    @JsonProperty("CustomerName")
    private String customerName;
    @JsonProperty("Department")
    private String department;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Fax")
    private String fax;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("MobilePhone")
    private String mobilePhone;
    @JsonProperty("MobilePhone2")
    private String mobilePhone2;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("OwnerName")
    private String ownerName;
    @JsonProperty("OwnerNumber")
    private String ownerNumber;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("Title")
    private String title;

    @Override
    public String toString() {
        return "MdmContact{" +
                "address='" + address + '\'' +
                ", code='" + code + '\'' +
                ", createTime='" + createTime + '\'' +
                ", customerCode='" + customerCode + '\'' +
                ", customerName='" + customerName + '\'' +
                ", department='" + department + '\'' +
                ", email='" + email + '\'' +
                ", fax='" + fax + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                ", mobilePhone2='" + mobilePhone2 + '\'' +
                ", name='" + name + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", ownerNumber='" + ownerNumber + '\'' +
                ", phone='" + phone + '\'' +
                ", title='" + title + '\'' +
                '}';
    }
}
