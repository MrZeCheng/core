package com.yhglobal.bee.mdm.data.common.controller;

import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.mdm.data.common.model.MdmDataRequest;
import com.yhglobal.bee.mdm.data.common.service.MdmDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
@RequestMapping
public class MdmdataController {

    private final MdmDataService mdmDataService;

    @PostMapping(value = "${yh.mdm.data.path:/mdm/data/init}")
    public YhResponse initRedundancyCode(@RequestBody MdmDataRequest mdmDataRequest){
        return mdmDataService.initMdmData(mdmDataRequest);
    }

}
