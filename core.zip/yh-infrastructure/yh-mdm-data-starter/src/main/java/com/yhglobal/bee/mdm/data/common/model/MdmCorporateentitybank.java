package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmCorporateentitybank extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MdsHeader : {"ClientIpAddress":"116.6.18.97","ComputerName":null,"TraceIdentifier":"0HMJUIG39MAG5:00000002","SourceMessageId":"3a062b92-092a-dd9e-6779-2444f0ee475f","SupplierMessageId":"3a062b92-0bdb-4acc-99b3-417ddc02e62e","SupplierId":"Eas","SupplierDataTypeId":"CorporateEntityBank","EntityId":"E80EA6BE329C0E62E050A8C0746459F4","EntityVersion":"2022-09-07T03:25:07","StandardMessageId":"3a06282c-3d23-c7f7-74ad-dae6db66e2e2","StandardObjectId":"corporateentitybank","PartnerMessageId":"00000000-0000-0000-0000-000000000000","PartnerId":null,"SubscribePropertiesString":null}
     * MasterDataTypeCode : CORPORATEENTITYBANK
     * Data : {"BankAccountNo":"anna.qiu@yhglobal.com","BankInstitution":"支付宝","BasicBank":"false","Code":"E80EA6BE329C0E62E050A8C0746459F4","CorporateEntityName":"东莞市新领电商科技有限公司","CorporateEntityNumber":"0208","CurrencyIso":null,"CurrencyName":null,"EasId":"wEQAAApRGFT7Mm5e","Enabled":"true","LastModificationTime":"2022-09-07T11:25:07+08:00","Name":"跨境电商分销项目（东莞新领）anna.qiu@yhglobal.com","Number":"1012.06.0208.01","OpeningDate":"2022-09-01T00:00:00+08:00","SimpleName":"跨境电商分销项目（东莞新领）anna.qiu@yhglobal.com","SourceCreationTime":"2022-09-07T11:25:07+08:00","SourceCreator":"姚燕虹","SourceLastUpdater":"姚燕虹"}
     */

    @JsonProperty("BankAccountNo")
    private String bankAccountNo;
    @JsonProperty("BankInstitution")
    private String bankInstitution;
    @JsonProperty("BasicBank")
    private String basicBank;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CorporateEntityName")
    private String corporateEntityName;
    @JsonProperty("CorporateEntityNumber")
    private String corporateEntityNumber;
    @JsonProperty("CurrencyIso")
    private String currencyIso;
    @JsonProperty("CurrencyName")
    private String currencyName;
    @JsonProperty("EasId")
    private String easId;
    @JsonProperty("Enabled")
    private String enabled;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("OpeningDate")
    private String openingDate;
    @JsonProperty("SimpleName")
    private String simpleName;
    @JsonProperty("SourceCreationTime")
    private String sourceCreationTime;
    @JsonProperty("SourceCreator")
    private String sourceCreator;
    @JsonProperty("SourceLastUpdater")
    private String sourceLastUpdater;

    @Override
    public String toString() {
        return "MdmCorporateentitybank{" +
                "bankAccountNo='" + bankAccountNo + '\'' +
                ", bankInstitution='" + bankInstitution + '\'' +
                ", basicBank='" + basicBank + '\'' +
                ", code='" + code + '\'' +
                ", corporateEntityName='" + corporateEntityName + '\'' +
                ", corporateEntityNumber='" + corporateEntityNumber + '\'' +
                ", currencyIso='" + currencyIso + '\'' +
                ", currencyName='" + currencyName + '\'' +
                ", easId='" + easId + '\'' +
                ", enabled='" + enabled + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", openingDate='" + openingDate + '\'' +
                ", simpleName='" + simpleName + '\'' +
                ", sourceCreationTime='" + sourceCreationTime + '\'' +
                ", sourceCreator='" + sourceCreator + '\'' +
                ", sourceLastUpdater='" + sourceLastUpdater + '\'' +
                '}';
    }
}
