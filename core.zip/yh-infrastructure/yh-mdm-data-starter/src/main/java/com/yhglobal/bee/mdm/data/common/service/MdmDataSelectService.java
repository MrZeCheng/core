package com.yhglobal.bee.mdm.data.common.service;

import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.mdm.data.common.model.dto.MdmDataAllDto;
import com.yhglobal.bee.mdm.data.common.model.dto.MdmDataPageDto;

import java.util.List;
import java.util.Map;

public interface MdmDataSelectService {

    MultiResponse findAllMdm(MdmDataAllDto mdmDataAllDto);

    PageResponse findPageMdm(MdmDataPageDto mdmDataPageDto);

    List<Map<String, Object>> customSql(String customSql);

}
