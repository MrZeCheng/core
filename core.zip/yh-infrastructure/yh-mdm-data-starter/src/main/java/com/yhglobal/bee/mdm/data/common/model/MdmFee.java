package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmFee extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : FEE
     * Data : {"BusinessTypeCode":"Storage","BusinessTypeName":"仓储","Code":"LF202209080021","DateTimeVersion":"2022-09-08T10:37:22.3461688+08:00","Description":"AGV租赁费","IsDeleted":false,"IsEnable":true,"Name":"AGV租赁费","NameEnglish":null,"Scode":null,"SourceId":517}
     */

    @JsonProperty("BusinessTypeCode")
    private String businessTypeCode;
    @JsonProperty("BusinessTypeName")
    private String businessTypeName;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("DateTimeVersion")
    private String dateTimeVersion;
    @JsonProperty("Description")
    private String description;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("IsEnable")
    private Boolean isEnable;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("NameEnglish")
    private String nameEnglish;
    @JsonProperty("Scode")
    private String scode;
    @JsonProperty("SourceId")
    private Integer sourceId;

    @Override
    public String toString() {
        return "MdmFee{" +
                "businessTypeCode='" + businessTypeCode + '\'' +
                ", businessTypeName='" + businessTypeName + '\'' +
                ", code='" + code + '\'' +
                ", dateTimeVersion='" + dateTimeVersion + '\'' +
                ", description='" + description + '\'' +
                ", isDeleted=" + isDeleted +
                ", isEnable=" + isEnable +
                ", name='" + name + '\'' +
                ", nameEnglish='" + nameEnglish + '\'' +
                ", scode='" + scode + '\'' +
                ", sourceId=" + sourceId +
                '}';
    }
}
