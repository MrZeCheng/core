package com.yhglobal.bee.mdm.data.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
import java.util.StringJoiner;

/**
 * 
 * 
 * @author weizecheng
 * @date 2021/2/4 16:33
 */
@ConfigurationProperties(prefix = "yh.mdm.data")
public class YhMdmDataProperties {

    private Boolean enable = true;

    private String path;

    private List<String> config;

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public List<String> getConfig() {
        return config;
    }

    public void setConfig(List<String> config) {
        this.config = config;
    }

    @Override
    public String toString() {
        return "YhMdmDataProperties{" +
                "enable=" + enable +
                ", path='" + path + '\'' +
                ", config=" + config +
                '}';
    }
}
