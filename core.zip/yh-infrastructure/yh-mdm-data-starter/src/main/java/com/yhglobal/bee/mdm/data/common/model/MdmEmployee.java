package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmEmployee extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : EMPLOYEE
     * Data : {"AdNumber":null,"Code":"006753","CreateTime":"2022-09-13T10:33:33+08:00","DeptNumber":"825701","Email":null,"EmpStatus":"在职","EnterDate":"2022-09-13T00:00:00+08:00","FID":"E8864738E46CFDB4E050A8C07464327E","LastModificationTime":"2022-09-13T10:33:35.211+08:00","LeaveDate":null,"Name":"刘钊","Number":"006753","PositionNumber":"001425","Telephone":"13142073648"}
     */

    @JsonProperty("AdNumber")
    private String adNumber;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("DeptNumber")
    private String deptNumber;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("EmpStatus")
    private String empStatus;
    @JsonProperty("EnterDate")
    private String enterDate;
    @JsonProperty("FID")
    private String fid;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("LeaveDate")
    private String leaveDate;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("PositionNumber")
    private String positionNumber;
    @JsonProperty("Telephone")
    private String telephone;

    @JsonProperty("EmployeeTypeCode")
    private String employeeTypeCode;

    @JsonProperty("EmployeeTypeName")
    private String employeeTypeName;

    @Override
    public String toString() {
        return "MdmEmployee{" +
                "adNumber='" + adNumber + '\'' +
                ", code='" + code + '\'' +
                ", createTime='" + createTime + '\'' +
                ", deptNumber='" + deptNumber + '\'' +
                ", email='" + email + '\'' +
                ", empStatus='" + empStatus + '\'' +
                ", enterDate='" + enterDate + '\'' +
                ", fid='" + fid + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", leaveDate='" + leaveDate + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", positionNumber='" + positionNumber + '\'' +
                ", telephone='" + telephone + '\'' +
                ", employeeTypeCode='" + employeeTypeCode + '\'' +
                ", employeeTypeName='" + employeeTypeName + '\'' +
                '}';
    }
}
