package com.yhglobal.bee.mdm.data.common.runner;

import com.yhglobal.bee.mdm.data.common.constant.MdmMessageType;
import com.yhglobal.bee.mdm.data.common.properties.YhMdmDataProperties;
import com.yhglobal.bee.mdm.data.common.service.MdmDataService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * 初始化Mdm相关数据库
 *
 * @author zecheng.wei
 * @Date 2022/10/18 10:49
 */
@Component
@RequiredArgsConstructor
public class MdmDataSqlInitCommandRunner implements CommandLineRunner {

    private final YhMdmDataProperties yhMdmDataProperties;

    private final MdmDataService mdmDataService;

    @Override
    public void run(String... args) {
        if (yhMdmDataProperties.getConfig() != null && yhMdmDataProperties.getConfig().size() > 0) {
            yhMdmDataProperties.getConfig().forEach( key ->{
                if (StringUtils.isNotBlank(key)) {
                    MdmMessageType mdmMessageType = MdmMessageType.getMessageType(key.trim().toUpperCase());
                    if (mdmMessageType != null) {
                        MdmMessageType.putMdmMessageType(mdmMessageType.getMsgType(), mdmMessageType);
                        mdmDataService.initMdmDataSql(mdmMessageType);
                    }
                }
            });
        }
        mdmDataService.initMdmApi();
    }

}
