package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmDataRequest implements Serializable {
    @JsonProperty("MdsHeader")
    private MdsHeaderBean mdsHeader;
    @JsonProperty("MasterDataTypeCode")
    private String masterDataTypeCode;
    @JsonProperty("Data")
    private Object data;

}
