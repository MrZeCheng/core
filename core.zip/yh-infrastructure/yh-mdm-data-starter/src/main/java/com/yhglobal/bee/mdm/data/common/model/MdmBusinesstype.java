package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmBusinesstype extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MdsHeader : {"ClientIpAddress":"101.53.164.8","ComputerName":null,"TraceIdentifier":"0HM7R0N8R8CU0:00000001","SourceMessageId":"39fc0a22-77d6-dfd7-bcc9-f48f9298d28f","SupplierMessageId":"39fc0a22-77f3-bfde-af8b-7ee16cea64f6","SupplierId":"SalesForce","SupplierDataTypeId":"BusinessType","EntityId":"WM06","EntityVersion":"2021-04-21T21:02:45","StandardMessageId":"39fc0976-6a9c-1689-4e49-d3c7085a13ac","StandardObjectId":"businesstype","PartnerMessageId":"00000000-0000-0000-0000-000000000000","PartnerId":null,"SubscribePropertiesString":null}
     * MasterDataTypeCode : BUSINESSTYPE
     * Data : {"Code":"WM06","CreateTime":"2021-04-22T01:54:56Z","IsEnable":true,"LastModificationTime":"2021-04-22T05:02:45Z","Name":"境内冷藏冷冻仓","ParentBusinessTypeName":"仓储","ParentBusinessTypeNo":"WM","RecordTypeName":"业务类型","Remark":"境内生鲜/医药类冷冻冷藏用业务分类"}
     */


    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("IsEnable")
    private Boolean isEnable;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("ParentBusinessTypeName")
    private String parentBusinessTypeName;
    @JsonProperty("ParentBusinessTypeNo")
    private String parentBusinessTypeNo;
    @JsonProperty("RecordTypeName")
    private String recordTypeName;
    @JsonProperty("Remark")
    private String remark;

    @Override
    public String toString() {
        return "MdmBusinesstype{" +
                "code='" + code + '\'' +
                ", createTime='" + createTime + '\'' +
                ", isEnable=" + isEnable +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", name='" + name + '\'' +
                ", parentBusinessTypeName='" + parentBusinessTypeName + '\'' +
                ", parentBusinessTypeNo='" + parentBusinessTypeNo + '\'' +
                ", recordTypeName='" + recordTypeName + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}
