package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmCorporateentity extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : CORPORATEENTITY
     * Data : {"Address":null,"Bank":null,"BankAccountNo":null,"BaseIso":"SGD","Code":"9477B5440F1DC2A9E050A8C02E6499A9","EasId":"wl++X+PFTPOf7wyonQsJVMznrtQ=","Enabled":"true","LastModificationTime":"2022-09-08T18:05:08.6+08:00","Name":"EASTLYNC CONSULTING & SERVICES PTE. LTD","Number":"0803","ShortNumber":"0803","SimpleName":null,"SourceCreationTime":"2012-11-10T11:49:33+08:00","SourceCreator":"预设用户","SourceLastUpdater":"刘如","TaxNo":null,"Telephone":null}
     */

    @JsonProperty("Address")
    private String address;
    @JsonProperty("Bank")
    private String bank;
    @JsonProperty("BankAccountNo")
    private String bankAccountNo;
    @JsonProperty("BaseIso")
    private String baseIso;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("EasId")
    private String easId;
    @JsonProperty("Enabled")
    private String enabled;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("ShortNumber")
    private String shortNumber;
    @JsonProperty("SimpleName")
    private String simpleName;
    @JsonProperty("SourceCreationTime")
    private String sourceCreationTime;
    @JsonProperty("SourceCreator")
    private String sourceCreator;
    @JsonProperty("SourceLastUpdater")
    private String sourceLastUpdater;
    @JsonProperty("TaxNo")
    private String taxNo;
    @JsonProperty("Telephone")
    private String telephone;

    @Override
    public String toString() {
        return "MdmCorporateentity{" +
                "address='" + address + '\'' +
                ", bank='" + bank + '\'' +
                ", bankAccountNo='" + bankAccountNo + '\'' +
                ", baseIso='" + baseIso + '\'' +
                ", code='" + code + '\'' +
                ", easId='" + easId + '\'' +
                ", enabled='" + enabled + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", shortNumber='" + shortNumber + '\'' +
                ", simpleName='" + simpleName + '\'' +
                ", sourceCreationTime='" + sourceCreationTime + '\'' +
                ", sourceCreator='" + sourceCreator + '\'' +
                ", sourceLastUpdater='" + sourceLastUpdater + '\'' +
                ", taxNo='" + taxNo + '\'' +
                ", telephone='" + telephone + '\'' +
                '}';
    }
}
