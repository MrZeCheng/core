package com.yhglobal.bee.mdm.data.common.service.impl;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.util.FileUtil;
import com.yhglobal.bee.common.util.JacksonUtil;
import com.yhglobal.bee.mdm.data.common.constant.MdmEventTypeEnum;
import com.yhglobal.bee.mdm.data.common.constant.MdmMessageType;
import com.yhglobal.bee.mdm.data.common.model.MdmDataRequest;
import com.yhglobal.bee.mdm.data.common.service.MdmApiService;
import com.yhglobal.bee.mdm.data.common.mapper.MdmDataMapper;
import com.yhglobal.bee.mdm.data.common.service.MdmDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class MdmDataServiceImpl implements MdmDataService {

    private final MdmDataMapper mdmDataMapper;

    private static Map<String, MdmApiService> MDM_API_MAP = new HashMap<>(16);

    private final static Map<String,String> MAP = new HashMap<>(){{
        put("id","id");
        put("createdMdmDate","createdMdmDate");
        put("modifiedMdmDate","modifiedMdmDate");
    }};

    @Override
    public YhResponse initMdmData(MdmDataRequest mdmDataRequest) {
        // 存在才开始操作
        String messageCode = mdmDataRequest.getMasterDataTypeCode().trim().toUpperCase();
        if (MdmMessageType.isMdmMessageType(messageCode)) {
            MdmMessageType mdmMessageType = MdmMessageType.getMessageType(messageCode);
            String tableName = mdmMessageType.getMsgType().toLowerCase();
            Map map = JacksonUtil.readValue(mdmDataRequest.getData());
            if (map != null) {
                Object code = map.get("Code");
                if (code != null) {
                    Integer count = mdmDataMapper.countMdmData(tableName, code.toString());
                    Object nowObject = JacksonUtil.json2Bean(JacksonUtil.bean2Json(mdmDataRequest.getData()), mdmMessageType.getClazz());
                    if (count != null && count > 0) {
                        Map<String,Object> oldMap = mdmDataMapper.findByCode(tableName, code.toString());
                        Map<String,Object> newMap = new HashMap<>(oldMap.size());
                        if (oldMap.size() > 0) {
                            Map<String,String> jsonPropertyMap = new HashMap<>(16);
                            for (Field field : mdmMessageType.getClazz().getDeclaredFields()){
                                JsonProperty jsonProperty = field.getAnnotation(JsonProperty.class);
                                if (jsonProperty != null) {
                                    jsonPropertyMap.put(field.getName(), jsonProperty.value());
                                }
                            }
                            oldMap.forEach((key,value)->{
                                if (MAP.containsKey(key)) {
                                    return;
                                }
                                newMap.put(jsonPropertyMap.getOrDefault(key, ""), value);
                            } );
                        }
                        Object oldObject = JacksonUtil.json2Bean(JacksonUtil.bean2Json(newMap), mdmMessageType.getClazz());
                        // 直接toString
                        // 代表两者相等 无需操作
                        StringBuilder updateSql = new StringBuilder();
                        if (!oldObject.toString().equals(nowObject.toString())) {
                            // 执行更新逻辑
                            for(Field field : mdmMessageType.getClazz().getDeclaredFields()){
                                // 跳过code
                                if ("code".equals(field.getName())) {
                                    continue;
                                }
                                updateSql.append(field.getName());
                                updateSql.append(" = ");
                                updateSql.append("#{order.");
                                updateSql.append(field.getName());
                                updateSql.append("},");
                            }
                            updateSql.deleteCharAt(updateSql.length() - 1);
                            mdmDataMapper.update(tableName, updateSql.toString(), nowObject);
                            eventUpdate(mdmMessageType, MdmEventTypeEnum.UPDATE, nowObject, oldObject);
                        }
                    }else {
                        // 执行插入逻辑
                        StringBuilder column = new StringBuilder();
                        StringBuilder valueName = new StringBuilder();
                        for(Field field : mdmMessageType.getClazz().getDeclaredFields()){
                            column.append(field.getName());
                            column.append(",");
                            valueName.append("#{order.");
                            valueName.append(field.getName());
                            valueName.append("},");
                        }
                        column.deleteCharAt(column.length() - 1);
                        valueName.deleteCharAt(valueName.length() - 1);
                        try {
                            mdmDataMapper.insert(tableName, column.toString(), valueName.toString(), nowObject);
                            event(mdmMessageType, MdmEventTypeEnum.INSERT, nowObject);
                        }catch (Exception e){
                            log.error(" insert sql error = {}",e.getMessage());
                        }
                    }

                }
            }
        }
        return YhResponse.buildSuccess();
    }

    private void event(MdmMessageType mdmMessageType, MdmEventTypeEnum mdmEventTypeEnum, Object object){
        if (MDM_API_MAP != null && MDM_API_MAP.size() > 0) {
            MDM_API_MAP.forEach( (key,value) ->{
                if (value.getMdmEventTypeEnum().equals(mdmEventTypeEnum) && value.getMdmMessageType().equals(mdmMessageType)) {
                    value.executionEvent(object);
                }
            });
        }
    }

    private void eventUpdate(MdmMessageType mdmMessageType, MdmEventTypeEnum mdmEventTypeEnum, Object object, Object oldObject){
        if (MDM_API_MAP != null && MDM_API_MAP.size() > 0) {
            MDM_API_MAP.forEach( (key,value) ->{
                if (value.getMdmEventTypeEnum().equals(mdmEventTypeEnum) && value.getMdmMessageType().equals(mdmMessageType)) {
                    value.executionUpdateEvent(oldObject, object);
                }
            });
        }
    }

    @Override
    public void initMdmApi() {
        MDM_API_MAP = YhApplicationContext.getListBean(MdmApiService.class);
    }

    @Override
    public void initMdmDataSql(MdmMessageType mdmMessageType) {
        int count = mdmDataMapper.countTableName("mdm_" + mdmMessageType.getMsgType().toLowerCase());
        if (count == 0) {
            log.info(" execute sql type = {} ", mdmMessageType.getMsgType());
            String sql ;
            try {
                sql = FileUtil.readFileAsString(mdmMessageType.getSqlFileName());
                mdmDataMapper.createCreateSql(sql);
            } catch (Exception e) {
                log.error("read sql file error = {}",e.getMessage());
            }
        }
    }
}
