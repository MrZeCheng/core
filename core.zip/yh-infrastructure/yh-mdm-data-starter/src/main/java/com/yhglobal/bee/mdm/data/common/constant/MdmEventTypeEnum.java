package com.yhglobal.bee.mdm.data.common.constant;

/**
 * 主数据的事件类型
 *
 * @author zecheng.wei
 * @Date 2022/10/19 10:18
 */
public enum MdmEventTypeEnum {

    /**
     * 更新
     */
    UPDATE,

    /**
     * 插入
     */
    INSERT;

}
