package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdsHeaderBean implements Serializable {
    @JsonProperty("ClientIpAddress")
    private String clientIpAddress;
    @JsonProperty("ComputerName")
    private String computerName;
    @JsonProperty("TraceIdentifier")
    private String traceIdentifier;
    @JsonProperty("SourceMessageId")
    private String sourceMessageId;
    @JsonProperty("SupplierMessageId")
    private String supplierMessageId;
    @JsonProperty("SupplierId")
    private String supplierId;
    @JsonProperty("SupplierDataTypeId")
    private String supplierDataTypeId;
    @JsonProperty("EntityId")
    private String entityId;
    @JsonProperty("EntityVersion")
    private String entityVersion;
    @JsonProperty("StandardMessageId")
    private String standardMessageId;
    @JsonProperty("StandardObjectId")
    private String standardObjectId;
    @JsonProperty("PartnerMessageId")
    private String partnerMessageId;
    @JsonProperty("PartnerId")
    private String partnerId;
    @JsonProperty("SubscribePropertiesString")
    private String subscribePropertiesString;
}
