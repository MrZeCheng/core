package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;


@Data
public class MdmOpportunitysplit extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : OPPORTUNITYSPLIT
     * Data : {"Code":"SP2022091308226","CreateTime":"2022-09-13T02:40:35Z","IsDeleted":false,"LastModificationTime":"2022-09-13T02:40:35Z","OpportunityCode":"PR2022091305215","OpportunityName":"越南M&R斯凯奇越南运输项目","SplitName":"潘琴","SplitNumber":"005859","SplitPercentage":100}
     */
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("IsDeleted")
    private Boolean isDeleted;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("OpportunityCode")
    private String opportunityCode;
    @JsonProperty("OpportunityName")
    private String opportunityName;
    @JsonProperty("SplitName")
    private String splitName;
    @JsonProperty("SplitNumber")
    private String splitNumber;
    @JsonProperty("SplitPercentage")
    private Integer splitPercentage;

    @Override
    public String toString() {
        return "MdmOpportunitysplit{" +
                "code='" + code + '\'' +
                ", createTime='" + createTime + '\'' +
                ", isDeleted=" + isDeleted +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", opportunityCode='" + opportunityCode + '\'' +
                ", opportunityName='" + opportunityName + '\'' +
                ", splitName='" + splitName + '\'' +
                ", splitNumber='" + splitNumber + '\'' +
                ", splitPercentage=" + splitPercentage +
                '}';
    }
}
