package com.yhglobal.bee.mdm.data.common.configure;

import com.yhglobal.bee.mdm.data.common.properties.YhMdmDataProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 *
 *
 * @author weizecheng
 * @date 2021/2/4 16:43
 */
@Configuration
@EnableConfigurationProperties(YhMdmDataProperties.class)
@ConditionalOnProperty(prefix = "yh.mdm.data",name = "enable", havingValue = "true", matchIfMissing = true)
@Slf4j
public class YhMdmDataAutoConfigure {

}
