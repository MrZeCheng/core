package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class MdmExchangerate extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : EXCHANGERATE
     * Data : {"AvailTime":"2011-12-01T00:00:00+08:00","Code":"9477FBCD9E78E129E050A8C02E64AD66","InvalidTime":"2016-12-30T00:00:00+08:00","Rate":1.25,"SourceCurrency":"人民币","SourceISO":"RMB","TargetCurrency":"港币","TargetISO":"HKD"}
     */


    @JsonProperty("AvailTime")
    private String availTime;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("InvalidTime")
    private String invalidTime;
    @JsonProperty("Rate")
    private BigDecimal rate;
    @JsonProperty("SourceCurrency")
    private String sourceCurrency;
    @JsonProperty("SourceISO")
    private String sourceIso;
    @JsonProperty("TargetCurrency")
    private String targetCurrency;
    @JsonProperty("TargetISO")
    private String targetIso;

    @Override
    public String toString() {
        return "MdmExchangerate{" +
                "availTime='" + availTime + '\'' +
                ", code='" + code + '\'' +
                ", invalidTime='" + invalidTime + '\'' +
                ", rate=" + rate +
                ", sourceCurrency='" + sourceCurrency + '\'' +
                ", sourceIso='" + sourceIso + '\'' +
                ", targetCurrency='" + targetCurrency + '\'' +
                ", targetIso='" + targetIso + '\'' +
                '}';
    }
}
