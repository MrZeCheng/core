package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@NoArgsConstructor
@Data
public class MdmDepartment extends BaseMdmMybatisEntity implements Serializable {


    /**
     * Code : F64A1F327FEE8331E050A8C081641AA7
     * CreationTime : 2023-03-03T15:05:39+08:00
     * DisplayName : 全球供应链_大区运营及事业部模块_华东大区_华东运营_唯亭基地_苏州李宁仓
     * EasDepartmentNumber : 830101
     * EasId : wEQAAAt1ev7M567U
     * EasLevel : 6
     * IsDeleted : false
     * IsLeaf : true
     * IsSealUp : false
     * IsStartSHR : true
     * LastModificationTime : 2023-03-03T15:05:40+08:00
     * LayerType : 五级分类
     * LongNumber : 0000000000!0100000000!0103000000!04020801!0402071802!830101
     * Name : 苏州李宁仓
     * ParentCode : F64A1F3281728331E050A8C081641AA9
     * ParentEasId : T9O5WdizShGk2D0MrvWtysznrtQ=
     * ParentEasNumber : 0402071802
     * ParentName : 唯亭基地
     */
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreationTime")
    private String creationTime;
    @JsonProperty("DisplayName")
    private String displayName;
    @JsonProperty("EasDepartmentNumber")
    private String easDepartmentNumber;
    @JsonProperty("EasId")
    private String easId;
    @JsonProperty("EasLevel")
    private Integer easLevel;
    @JsonProperty("IsDeleted")
    private String isDeleted;
    @JsonProperty("IsLeaf")
    private String isLeaf;
    @JsonProperty("IsSealUp")
    private String isSealUp;
    @JsonProperty("IsStartSHR")
    private String isStartSHR;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("LayerType")
    private String layerType;
    @JsonProperty("LongNumber")
    private String longNumber;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("ParentCode")
    private String parentCode;
    @JsonProperty("ParentEasId")
    private String parentEasId;
    @JsonProperty("ParentEasNumber")
    private String parentEasNumber;
    @JsonProperty("ParentName")
    private String parentName;

    @Override
    public String toString() {
        return "MdmDepartment{" +
                "code='" + code + '\'' +
                ", creationTime='" + creationTime + '\'' +
                ", displayName='" + displayName + '\'' +
                ", easDepartmentNumber='" + easDepartmentNumber + '\'' +
                ", easId='" + easId + '\'' +
                ", easLevel=" + easLevel +
                ", isDeleted='" + isDeleted + '\'' +
                ", isLeaf='" + isLeaf + '\'' +
                ", isSealUp='" + isSealUp + '\'' +
                ", isStartSHR='" + isStartSHR + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", layerType='" + layerType + '\'' +
                ", longNumber='" + longNumber + '\'' +
                ", name='" + name + '\'' +
                ", parentCode='" + parentCode + '\'' +
                ", parentEasId='" + parentEasId + '\'' +
                ", parentEasNumber='" + parentEasNumber + '\'' +
                ", parentName='" + parentName + '\'' +
                '}';
    }

    /*
     [
        {
                "NAME": "上海李宁仓",
                "LONGNUMBER": "0000000000!0100000000!0103000000!04020801!0402071802!830001",
                "ISLEAF": 1,
                "PARENTNAME": "唯亭基地",
                "EASID": "wEQAAAt1eu/M567U",
                "CREATETIME": "2023-03-03T15:05:04.000+0800",
                "LAYERTYPE": "五级分类",
                "DISPLAYNAME": "全球供应链_大区运营及事业部模块_华东大区_华东运营_唯亭基地_上海李宁仓",
                "EASNUMBER": "830001",
                "LASTUPDATETIME": "2023-03-03T15:05:04.000+0800",
                "ISSEALUP": 0,
                "PARENTEASNUMBER": "0402071802",
                "EASLEVEL": 6,
                "PARENTEASID": "T9O5WdizShGk2D0MrvWtysznrtQ=",
                "PARENTCODE": "F64A1F3281728331E050A8C081641AA7",
                "ISSTARTSHR": 1,
                "CODE": "F64A1F3281A28331E050A8C081641AA7"
        },
        {
                "NAME": "苏州李宁仓",
                "LONGNUMBER": "0000000000!0100000000!0103000000!04020801!0402071802!830101",
                "ISLEAF": 1,
                "PARENTNAME": "唯亭基地",
                "EASID": "wEQAAAt1ev7M567U",
                "CREATETIME": "2023-03-03T15:05:39.000+0800",
                "LAYERTYPE": "五级分类",
                "DISPLAYNAME": "全球供应链_大区运营及事业部模块_华东大区_华东运营_唯亭基地_苏州李宁仓",
                "EASNUMBER": "830101",
                "LASTUPDATETIME": "2023-03-03T15:05:40.000+0800",
                "ISSEALUP": 0,
                "PARENTEASNUMBER": "0402071802",
                "EASLEVEL": 6,
                "PARENTEASID": "T9O5WdizShGk2D0MrvWtysznrtQ=",
                "PARENTCODE": "F64A1F3281728331E050A8C081641AA7",
                "ISSTARTSHR": 1,
                "CODE": "F64A1F327FEE8331E050A8C081641AA7"
        }
]
     */
}
