package com.yhglobal.bee.mdm.data.common.mapper.provider;

import com.yhglobal.bee.common.util.SqlHelpUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

public class MdmDataProvider {

    public String insertMdmData(@Param("mdmTableName")String mdmTableName,
                                @Param("columnName")String columnName,
                                @Param("columnValueName")String columnValueName,
                                @Param("order")Object order) {
        return  "INSERT INTO mdm_"+ mdmTableName +" (createdMdmDate,modifiedMdmDate,"+  columnName + " )"+
                " VALUES ( NOW() ,NOW(), " +columnValueName  +")";
    }


    public String findAll(@Param("mdmTableName")String mdmTableName,
                                @Param("code")String code,
                                @Param("name")String name) {
        return new SQL() {{
            SELECT(
                    "*");
            FROM("mdm_" + mdmTableName);
            if (StringUtils.isNotBlank(code)) {
                WHERE("code = #{code}");
            }

            if (StringUtils.isNotBlank(name)) {
                WHERE("name LIKE '%' #{name} '%'");
            }

        }}.toString();
    }

    public String updateMdmData(@Param("mdmTableName")String mdmTableName,
                                @Param("updateSql")String updateSql,
                                @Param("order")Object order) {
        return  "update mdm_"+mdmTableName+" set " +updateSql + " , modifiedMdmDate = NOW()  where code = #{order.code}";
    }

}
