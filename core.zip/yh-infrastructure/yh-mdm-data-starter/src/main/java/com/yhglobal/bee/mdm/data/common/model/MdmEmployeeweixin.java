package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;


import java.io.Serializable;

@Data
public class MdmEmployeeweixin extends BaseMdmMybatisEntity implements Serializable {


    /**
     * MasterDataTypeCode : EMPLOYEEWEIXIN
     * Data : {"Code":"17903","Email":"shaoli.zhu@yhglobal.com","ImgUrl":"https://wework.qpic.cn/wwpic/434461_367pfqKwTzWShYE_1660360666/0","LastModificationTime":"2022-09-12T22:51:51","Mobile":"13926562402","Name":"祝少莉","NameEn":"002985","OpenId":"oRyvrwxU95X7QX9_TXo5sa9M4HcQ"}
     */
    @JsonProperty("Code")
    private String code;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("ImgUrl")
    private String imgUrl;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Mobile")
    private String mobile;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("NameEn")
    private String nameEn;
    @JsonProperty("OpenId")
    private String openId;

    @Override
    public String toString() {
        return "MdmEmployeeweixin{" +
                "code='" + code + '\'' +
                ", email='" + email + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", mobile='" + mobile + '\'' +
                ", name='" + name + '\'' +
                ", nameEn='" + nameEn + '\'' +
                ", openId='" + openId + '\'' +
                '}';
    }
}
