package com.yhglobal.bee.mdm.data.common.model.base;


import java.util.Date;


/**
 * 基础信息表
 *
 * @author weizecheng
 * @date 2021/8/14 15:24
 */
public abstract class BaseMdmMybatisEntity {

    private Long id;
    /**
     * 创建时间
     */
    private Date createdMdmDate;
    /**
     * 最后修改时间
     */
    private Date modifiedMdmDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedMdmDate() {
        return createdMdmDate;
    }

    public void setCreatedMdmDate(Date createdMdmDate) {
        this.createdMdmDate = createdMdmDate;
    }

    public Date getModifiedMdmDate() {
        return modifiedMdmDate;
    }

    public void setModifiedMdmDate(Date modifiedMdmDate) {
        this.modifiedMdmDate = modifiedMdmDate;
    }
}
