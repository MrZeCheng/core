package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmOrganization extends BaseMdmMybatisEntity implements Serializable {


    /**
     * MasterDataTypeCode : ORGANIZATION
     * Data : {"AdminNumber":null,"AdminParentNumber":null,"Code":"E80C98D4FB56FAE1E050A8C074649A43","CompanyNumber":null,"CostCenterNumber":"0000000000!1002!0202!020298!02029834","DisplayName":"全球供应链_华南区_深圳越海全球供应链股份有限公司_周转材料中心_周转材料进销存（福州福清1仓813101）","EnglishName":null,"IsAdminOrgUnit":"false","IsAdminSealup":"false","IsCompanyBizUnit":"false","IsCompanyOrgUnit":"false","IsCompanySealup":"false","IsCostCenterBizUnit":"true","IsCostCenterSealup":"false","IsCostOrgUnit":"true","Isleaf":"true","IsLogisticsCostCenter":"false","IsProfitCenterBizUnit":"false","IsProfitCenterSealup":"false","IsProfitCenterUnit":"false","IsPurchaseBizUnit":"true","IsPurchaseOrgUnit":"true","IsPurchaseSealup":"false","IsSaleBizUnit":"true","IsSaleOrgUnit":"true","IsSaleSealup":"false","IsSealup":"false","IsStorageBizUnit":"true","IsStorageOrgUnit":"true","IsStorageSealup":"false","IsYHBusinessEntity":"false","LastModificationTime":"2022-09-07T09:45:09+08:00","LayerType":null,"Level":5,"LongNumber":"0000000000!1002!0202!020298!02029834","Name":"周转材料进销存（福州福清1仓813101）","Number":"02029834","ProfitCenterNumber":null,"PurchaseNumber":"0000000000!0202!020298!02029834","SaleNumber":"0000000000!0202!020298!02029834","SourceCreateTime":"2022-09-07T09:43:55+08:00","StorageNumber":"0000000000!0202!020298!02029834"}
     */


    @JsonProperty("AdminNumber")
    private String adminNumber;
    @JsonProperty("AdminParentNumber")
    private String adminParentNumber;
    @JsonProperty("Code")
    private String code;
    @JsonProperty("CompanyNumber")
    private String companyNumber;
    @JsonProperty("CostCenterNumber")
    private String costCenterNumber;
    @JsonProperty("DisplayName")
    private String displayName;
    @JsonProperty("EnglishName")
    private String englishName;
    @JsonProperty("IsAdminOrgUnit")
    private String isAdminOrgUnit;
    @JsonProperty("IsAdminSealup")
    private String isAdminSealup;
    @JsonProperty("IsCompanyBizUnit")
    private String isCompanyBizUnit;
    @JsonProperty("IsCompanyOrgUnit")
    private String isCompanyOrgUnit;
    @JsonProperty("IsCompanySealup")
    private String isCompanySealup;
    @JsonProperty("IsCostCenterBizUnit")
    private String isCostCenterBizUnit;
    @JsonProperty("IsCostCenterSealup")
    private String isCostCenterSealup;
    @JsonProperty("IsCostOrgUnit")
    private String isCostOrgUnit;
    @JsonProperty("Isleaf")
    private String isleaf;
    @JsonProperty("IsLogisticsCostCenter")
    private String isLogisticsCostCenter;
    @JsonProperty("IsProfitCenterBizUnit")
    private String isProfitCenterBizUnit;
    @JsonProperty("IsProfitCenterSealup")
    private String isProfitCenterSealup;
    @JsonProperty("IsProfitCenterUnit")
    private String isProfitCenterUnit;
    @JsonProperty("IsPurchaseBizUnit")
    private String isPurchaseBizUnit;
    @JsonProperty("IsPurchaseOrgUnit")
    private String isPurchaseOrgUnit;
    @JsonProperty("IsPurchaseSealup")
    private String isPurchaseSealup;
    @JsonProperty("IsSaleBizUnit")
    private String isSaleBizUnit;
    @JsonProperty("IsSaleOrgUnit")
    private String isSaleOrgUnit;
    @JsonProperty("IsSaleSealup")
    private String isSaleSealup;
    @JsonProperty("IsSealup")
    private String isSealup;
    @JsonProperty("IsStorageBizUnit")
    private String isStorageBizUnit;
    @JsonProperty("IsStorageOrgUnit")
    private String isStorageOrgUnit;
    @JsonProperty("IsStorageSealup")
    private String isStorageSealup;
    @JsonProperty("IsYHBusinessEntity")
    private String isYhBusinessEntity;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("LayerType")
    private String layerType;
    @JsonProperty("Level")
    private Integer level;
    @JsonProperty("LongNumber")
    private String longNumber;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("ProfitCenterNumber")
    private String profitCenterNumber;
    @JsonProperty("PurchaseNumber")
    private String purchaseNumber;
    @JsonProperty("SaleNumber")
    private String saleNumber;
    @JsonProperty("SourceCreateTime")
    private String sourceCreateTime;
    @JsonProperty("StorageNumber")
    private String storageNumber;

    @Override
    public String toString() {
        return "MdmOrganization{" +
                "adminNumber='" + adminNumber + '\'' +
                ", adminParentNumber='" + adminParentNumber + '\'' +
                ", code='" + code + '\'' +
                ", companyNumber='" + companyNumber + '\'' +
                ", costCenterNumber='" + costCenterNumber + '\'' +
                ", displayName='" + displayName + '\'' +
                ", englishName='" + englishName + '\'' +
                ", isAdminOrgUnit='" + isAdminOrgUnit + '\'' +
                ", isAdminSealup='" + isAdminSealup + '\'' +
                ", isCompanyBizUnit='" + isCompanyBizUnit + '\'' +
                ", isCompanyOrgUnit='" + isCompanyOrgUnit + '\'' +
                ", isCompanySealup='" + isCompanySealup + '\'' +
                ", isCostCenterBizUnit='" + isCostCenterBizUnit + '\'' +
                ", isCostCenterSealup='" + isCostCenterSealup + '\'' +
                ", isCostOrgUnit='" + isCostOrgUnit + '\'' +
                ", isleaf='" + isleaf + '\'' +
                ", isLogisticsCostCenter='" + isLogisticsCostCenter + '\'' +
                ", isProfitCenterBizUnit='" + isProfitCenterBizUnit + '\'' +
                ", isProfitCenterSealup='" + isProfitCenterSealup + '\'' +
                ", isProfitCenterUnit='" + isProfitCenterUnit + '\'' +
                ", isPurchaseBizUnit='" + isPurchaseBizUnit + '\'' +
                ", isPurchaseOrgUnit='" + isPurchaseOrgUnit + '\'' +
                ", isPurchaseSealup='" + isPurchaseSealup + '\'' +
                ", isSaleBizUnit='" + isSaleBizUnit + '\'' +
                ", isSaleOrgUnit='" + isSaleOrgUnit + '\'' +
                ", isSaleSealup='" + isSaleSealup + '\'' +
                ", isSealup='" + isSealup + '\'' +
                ", isStorageBizUnit='" + isStorageBizUnit + '\'' +
                ", isStorageOrgUnit='" + isStorageOrgUnit + '\'' +
                ", isStorageSealup='" + isStorageSealup + '\'' +
                ", isYhBusinessEntity='" + isYhBusinessEntity + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", layerType='" + layerType + '\'' +
                ", level=" + level +
                ", longNumber='" + longNumber + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", profitCenterNumber='" + profitCenterNumber + '\'' +
                ", purchaseNumber='" + purchaseNumber + '\'' +
                ", saleNumber='" + saleNumber + '\'' +
                ", sourceCreateTime='" + sourceCreateTime + '\'' +
                ", storageNumber='" + storageNumber + '\'' +
                '}';
    }
}
