package com.yhglobal.bee.mdm.data.common.service;

import com.yhglobal.bee.mdm.data.common.constant.MdmEventTypeEnum;
import com.yhglobal.bee.mdm.data.common.constant.MdmMessageType;

public interface MdmApiService<T> {

    /**
     * 主数据类型
     */
    MdmMessageType getMdmMessageType();

    /**
     * 事件类型
     */
    MdmEventTypeEnum getMdmEventTypeEnum();

    /**
     * 触发事件
     */
    default void executionEvent(T t){

    };

    /**
     * 更新事件 方便下游比对差异
     */
    default void executionUpdateEvent(T oldObject, T nowObject){

    };
}
