package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;

@Data
public class MdmEmployeeposition extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : EMPLOYEEPOSITION
     * Data : {"Code":"E059F85B3313C24EE050A8C07464E399","CreateTime":"2022-06-01T09:40:42+08:00","DeptNumber":"826601","EffDate":"2022-06-01T00:00:00+08:00","LastModificationTime":"2022-09-06T10:49:33+08:00","LeftDate":"2022-08-30T00:00:00+08:00","PersonNumber":"006095","PositionNumber":"001610"}
     */

    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("DeptNumber")
    private String deptNumber;
    @JsonProperty("EffDate")
    private String effDate;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("LeftDate")
    private String leftDate;
    @JsonProperty("PersonNumber")
    private String personNumber;
    @JsonProperty("PositionNumber")
    private String positionNumber;

    @Override
    public String toString() {
        return "MdmEmployeeposition{" +
                "code='" + code + '\'' +
                ", createTime='" + createTime + '\'' +
                ", deptNumber='" + deptNumber + '\'' +
                ", effDate='" + effDate + '\'' +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", leftDate='" + leftDate + '\'' +
                ", personNumber='" + personNumber + '\'' +
                ", positionNumber='" + positionNumber + '\'' +
                '}';
    }
}
