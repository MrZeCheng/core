package com.yhglobal.bee.mdm.data.common.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.yhglobal.bee.mdm.data.common.model.base.BaseMdmMybatisEntity;
import lombok.Data;

import java.io.Serializable;


@Data
public class MdmPosition extends BaseMdmMybatisEntity implements Serializable {

    /**
     * MasterDataTypeCode : POSITION
     * Data : {"Code":"D62A427E1D22E21DE050A8C0746449DF","CreateTime":"2022-01-22T18:33:15+08:00","DeptNumber":"07020806","IsRespPosition":0,"IsSealUp":0,"LastModificationTime":"2022-09-09T10:12:38+08:00","Name":"行政人事主管","Number":"160080","ParentId":"D62A427E1DA3E21DE050A8C0746449DF"}
     */

    @JsonProperty("Code")
    private String code;
    @JsonProperty("CreateTime")
    private String createTime;
    @JsonProperty("DeptNumber")
    private String deptNumber;
    @JsonProperty("IsRespPosition")
    private Integer isRespPosition;
    @JsonProperty("IsSealUp")
    private Integer isSealUp;
    @JsonProperty("LastModificationTime")
    private String lastModificationTime;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("Number")
    private String number;
    @JsonProperty("ParentId")
    private String parentId;

    @Override
    public String toString() {
        return "MdmPosition{" +
                "code='" + code + '\'' +
                ", createTime='" + createTime + '\'' +
                ", deptNumber='" + deptNumber + '\'' +
                ", isRespPosition=" + isRespPosition +
                ", isSealUp=" + isSealUp +
                ", lastModificationTime='" + lastModificationTime + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", parentId='" + parentId + '\'' +
                '}';
    }
}
