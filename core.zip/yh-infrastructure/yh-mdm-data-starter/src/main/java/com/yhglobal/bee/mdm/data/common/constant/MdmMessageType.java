package com.yhglobal.bee.mdm.data.common.constant;

import com.yhglobal.bee.mdm.data.common.model.*;

import java.util.HashMap;
import java.util.Map;

public enum MdmMessageType {
    /**
     * 1、 商业类型 businesstype
     */
    BUSINESS_TYPE("BUSINESSTYPE", "mdm_businesstype.sql", MdmBusinesstype.class),
    /**
     * 2、联系 contact
     */
    CONTACT_TYPE("CONTACT", "mdm_contacttype.sql", MdmContact.class),
    /**
     * 3、法人实体 corporateentity
     */
    CORPORATEENTITY("CORPORATEENTITY", "mdm_corporateentity.sql", MdmCorporateentity.class),
    /**
     * 4、法人银行 corporateentitybank
     */
    CORPORATEENTITY_BANK("CORPORATEENTITYBANK", "mdm_corporateentitybank.sql", MdmCorporateentitybank.class),
    /**
     * 5、 通货 currency
     */
    CURRENCY("CURRENCY", "mdm_currency.sql" , MdmCurrency.class),
    /**
     * 6、 顾客 customer
     */
    CUSTOMER("CUSTOMER", "mdm_customer.sql", MdmCustomer.class),
    /**
     * 8、 受雇者 employee
     */
    EMPLOYEE("EMPLOYEE", "mdm_employee.sql", MdmEmployee.class),
    /**
     * 9、 雇员微信 employeeweixin
     */
    EMPLOYEE_WEIXIN("EMPLOYEEWEIXIN", "mdm_employeeweixin.sql", MdmEmployeeweixin.class),
    /**
     * 10、雇员职位 employeeposition
     */
    EMPLOYEE_POSITION("EMPLOYEEPOSITION", "mdm_employeeposition.sql", MdmEmployeeposition.class),
    /**
     * 11、汇率 exchangerate
     */
    EXCHANGERATE("EXCHANGERATE", "mdm_exchangerate.sql", MdmExchangerate.class),
    /**
     * 12、费用 fee
     */
    FEE("FEE", "mdm_fee.sql", MdmFee.class),

    /**
     * 14、机会 opportunity
     */
    OPPORTUNITY("OPPORTUNITY", "mdm_opportunity.sql", MdmOpportunity.class),
    /**
     * 15、机会分裂 opportunitysplit
     */
    OPPORTUNITY_SPLIT("OPPORTUNITYSPLIT", "mdm_opportunitysplit.sql", MdmOpportunitysplit.class),
    /**
     * 16、组织 organization
     */
    ORGANIZATION("ORGANIZATION", "mdm_organization.sql", MdmOrganization.class),
    /**
     * 17、位置 position
     */
    POSITION("POSITION", "mdm_position.sql", MdmPosition.class),
    /**
     * 18、仓库 warehouse
     */
    WAREHOUSE("WAREHOUSE", "mdm_warehouse.sql", MdmWarehouse.class),
    /**
     * 19、部门 department
     */
    DEPARTMENT("DEPARTMENT", "mdm_department.sql", MdmDepartment.class);

    private final String msgType;
    private final String sqlFileName;
    private final Class clazz;



    public Class getClazz() {
        return clazz;
    }

    public String getSqlFileName() {
        return sqlFileName;
    }

    private final static Map<String, MdmMessageType> MAP = new HashMap<>(25);

    private final static Map<String, MdmMessageType> MDM_MESSAGE_TYPE_MAP = new HashMap<>(25);

    public static void putMdmMessageType(String type, MdmMessageType mdmMessageType){
        MDM_MESSAGE_TYPE_MAP.put(type, mdmMessageType);
    }

    public static Boolean isMdmMessageType(String mdmMessageType){
        return MDM_MESSAGE_TYPE_MAP.containsKey(mdmMessageType);
    }


    static {
        init();
    }
    public static void init(){
        for(MdmMessageType e : MdmMessageType.values()){
            MAP.put(e.msgType,e);
        }
    }

    MdmMessageType(String msgType,String sqlFileName, Class clazz) {
        this.msgType = msgType;
        this.sqlFileName = sqlFileName;
        this.clazz = clazz;
    }


    public static MdmMessageType getMessageType(String msgType) {
        return MAP.getOrDefault(msgType,null);
    }


    public String getMsgType() {
        return msgType;
    }


}
