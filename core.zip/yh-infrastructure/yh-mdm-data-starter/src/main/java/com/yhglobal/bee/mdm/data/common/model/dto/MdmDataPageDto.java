package com.yhglobal.bee.mdm.data.common.model.dto;

import com.yhglobal.bee.common.dto.PageQuery;
import com.yhglobal.bee.mdm.data.common.constant.MdmMessageType;

public class MdmDataPageDto extends PageQuery {

    private MdmMessageType mdmMessageType;

    private String code;

    private String name;

    public MdmMessageType getMdmMessageType() {
        return mdmMessageType;
    }

    public void setMdmMessageType(MdmMessageType mdmMessageType) {
        this.mdmMessageType = mdmMessageType;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
