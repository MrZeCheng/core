package com.yhglobal.bee.mdm.data.common.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.PageResponse;
import com.yhglobal.bee.mdm.data.common.service.MdmDataSelectService;
import com.yhglobal.bee.mdm.data.common.constant.MdmMessageType;
import com.yhglobal.bee.mdm.data.common.mapper.MdmDataMapper;
import com.yhglobal.bee.mdm.data.common.model.dto.MdmDataAllDto;
import com.yhglobal.bee.mdm.data.common.model.dto.MdmDataPageDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MdmDataSelectServiceImpl implements MdmDataSelectService {

    private final MdmDataMapper mdmDataMapper;

    @Override
    public MultiResponse findAllMdm(MdmDataAllDto mdmDataAllDto) {
        if(!MdmMessageType.isMdmMessageType(mdmDataAllDto.getMdmMessageType().getMsgType())){
            return MultiResponse.of(new ArrayList<>());
        }
        return MultiResponse.of(mdmDataMapper.findAll(mdmDataAllDto.getMdmMessageType().getMsgType().toLowerCase(), mdmDataAllDto.getCode(), mdmDataAllDto.getName()));
    }

    @Override
    public PageResponse findPageMdm(MdmDataPageDto mdmDataPageDto) {
        if(!MdmMessageType.isMdmMessageType(mdmDataPageDto.getMdmMessageType().getMsgType())){
            return PageResponse.of(mdmDataPageDto.getPageSize(), mdmDataPageDto.getPageIndex());
        }
        PageHelper.startPage(mdmDataPageDto.getPageIndex(), mdmDataPageDto.getPageSize());
        List<Map<String,Object>> mapList = mdmDataMapper.findAll(mdmDataPageDto.getMdmMessageType().getMsgType().toLowerCase(), mdmDataPageDto.getCode(), mdmDataPageDto.getName());
        PageInfo<Map<String,Object>> pageInfo = new PageInfo<>(mapList);
        return PageResponse.of(pageInfo.getList(),pageInfo.getTotal(),pageInfo.getPageSize(),pageInfo.getPageNum());
    }

    @Override
    public List<Map<String, Object>> customSql(String customSql) {
        return  mdmDataMapper.customSql(customSql);
    }
}
