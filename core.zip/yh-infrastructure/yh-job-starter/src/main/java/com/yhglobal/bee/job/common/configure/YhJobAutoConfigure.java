package com.yhglobal.bee.job.common.configure;

import com.xxl.job.core.executor.impl.XxlJobSpringExecutor;
import com.yhglobal.bee.job.common.properties.YhJobProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 *
 * @author weizecheng
 * @date 2021/2/4 16:43
 */
@Configuration
@EnableConfigurationProperties(YhJobProperties.class)
@ConditionalOnProperty(prefix = "yh.job",name = "enable", havingValue = "true", matchIfMissing = true)
@Slf4j
public class YhJobAutoConfigure {

    private final YhJobProperties yhJobProperties;

    private final String applicationName;

    public YhJobAutoConfigure(YhJobProperties yhJobProperties,@Value("${spring.application.name}") String applicationName){
        this.yhJobProperties = yhJobProperties;
        this.applicationName = applicationName;
    }

    @Bean
    public XxlJobSpringExecutor xxlJobExecutor() {
        log.info(">>>>>>>>>>> yh-job config init.");
        log.info("applicationName = "+applicationName);
        XxlJobSpringExecutor xxlJobSpringExecutor = new XxlJobSpringExecutor();
        xxlJobSpringExecutor.setAdminAddresses(yhJobProperties.getAdminAddresses());
        xxlJobSpringExecutor.setAppname(applicationName);
        xxlJobSpringExecutor.setAddress(yhJobProperties.getAddress());

        xxlJobSpringExecutor.setIp(yhJobProperties.getIp());
        xxlJobSpringExecutor.setPort(yhJobProperties.getPort());

        xxlJobSpringExecutor.setAccessToken(yhJobProperties.getAccessToken());
        xxlJobSpringExecutor.setLogPath(yhJobProperties.getLogPath());
        xxlJobSpringExecutor.setLogRetentionDays(yhJobProperties.getLogRetentionDays());
        return xxlJobSpringExecutor;
    }

}
