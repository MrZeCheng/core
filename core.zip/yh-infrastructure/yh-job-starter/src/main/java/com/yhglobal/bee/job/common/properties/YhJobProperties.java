package com.yhglobal.bee.job.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.StringJoiner;

/**
 * 
 * 
 * @author weizecheng
 * @date 2021/2/4 16:33
 */
@ConfigurationProperties(prefix = "yh.job")
public class YhJobProperties {

    private Boolean enable;

    private String adminAddresses;

    private String accessToken;

    private String address;
    /**
     * 此处可以设置为0
     */
    private String ip;

    private int port = 0;

    private String logPath;

    private int logRetentionDays;

    public Boolean getEnable() {
        return enable;
    }

    public YhJobProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    public String getAdminAddresses() {
        return adminAddresses;
    }

    public YhJobProperties setAdminAddresses(String adminAddresses) {
        this.adminAddresses = adminAddresses;
        return this;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public YhJobProperties setAccessToken(String accessToken) {
        this.accessToken = accessToken;
        return this;
    }


    public String getAddress() {
        return address;
    }

    public YhJobProperties setAddress(String address) {
        this.address = address;
        return this;
    }

    public String getIp() {
        return ip;
    }

    public YhJobProperties setIp(String ip) {
        this.ip = ip;
        return this;
    }

    public int getPort() {
        return port;
    }

    public YhJobProperties setPort(int port) {
        this.port = port;
        return this;
    }

    public String getLogPath() {
        return logPath;
    }

    public YhJobProperties setLogPath(String logPath) {
        this.logPath = logPath;
        return this;
    }

    public int getLogRetentionDays() {
        return logRetentionDays;
    }

    public YhJobProperties setLogRetentionDays(int logRetentionDays) {
        this.logRetentionDays = logRetentionDays;
        return this;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", YhJobProperties.class.getSimpleName() + "[", "]")
                .add("adminAddresses='" + adminAddresses + "'")
                .add("accessToken='" + accessToken + "'")
                .add("address='" + address + "'")
                .add("ip='" + ip + "'")
                .add("port=" + port)
                .add("logPath='" + logPath + "'")
                .add("logRetentionDays=" + logRetentionDays)
                .toString();
    }
}
