package com.yhglobal.bee.gateway.common.jwt;

public interface IJWTInfo {

    /**
     * 获取用户名
     * @return
     */
    String getUserName();

    /**
     * 获取用户ID
     * @return
     */
    String getUserId();

    /**
     * tokenId
     * @return
     */
    String getTokenId();

    /**
     * 过期时间 主要是用于延期
     * @return
     */
    Long getExpireDate();

    String getEmail();


}
