package com.yhglobal.bee.gateway.common.util;

import com.yhglobal.bee.gateway.common.jwt.IJWTInfo;
import com.yhglobal.bee.gateway.common.jwt.JWTHelper;
import lombok.Data;

import java.util.Date;

@Data
public class JwtTokenUtil {

    private int expire;
    private int refresh;

    private String secret;

    /**
     * 签约
     * @param jwtInfo
     * @return
     * @throws Exception
     */
    public String generateToken(IJWTInfo jwtInfo,byte[] pri) throws Exception {
        return JWTHelper.generateToken(jwtInfo, pri,new Date(),expire);
    }


    /**
     * 续签
     * @param jwtInfo
     * @return
     * @throws Exception
     */
    public String generateTokenRenew(IJWTInfo jwtInfo,byte[] pri) throws Exception {
        return JWTHelper.generateToken(jwtInfo,pri,new Date(),refresh);
    }


    public IJWTInfo getInfoFromToken(String token,byte[] pub) throws Exception {
        return JWTHelper.getInfoFromToken(token,pub);
    }

}
