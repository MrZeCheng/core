package com.yhglobal.bee.gateway.common.jwt;

import com.yhglobal.bee.common.constant.JwtConstant;
import com.yhglobal.bee.common.util.helper.RsaKeyHelper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class JWTHelper {


    private static RsaKeyHelper rsaKeyHelper = new RsaKeyHelper();
    /**
     * 秘钥加密
     *
     * @param jwtInfo
     * @param priKey
     * @param expire
     * @return
     * @throws Exception
     */
    public static String generateToken(IJWTInfo jwtInfo, byte[] priKey, Date date , int expire) throws Exception {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.SECOND, expire);
        return Jwts.builder()
                .setSubject(jwtInfo.getUserId()+"-"+jwtInfo.getUserName())
                .claim(JwtConstant.JWT_KEY_USER_ID,jwtInfo.getUserId())
                .claim(JwtConstant.JWT_KEY_USER_NAME,jwtInfo.getUserName())
                .claim(JwtConstant.JWT_KEY_TOKEN_ID,jwtInfo.getTokenId())
                .claim(JwtConstant.JWT_KEY_EXPIRE_DATE,cd.getTime().getTime())
                .claim(JwtConstant.JWT_KEY_EMAIL,jwtInfo.getEmail() == null ? "" : jwtInfo.getEmail())
                .setExpiration(cd.getTime())
                .signWith(SignatureAlgorithm.RS256, rsaKeyHelper.getPrivateKey(priKey))
                .compact();
    }

    /**
     * 公钥解析token
     *
     * @param token
     * @return
     * @throws Exception
     */
    public static Jws<Claims> parserToken(String token, byte[] pubKey) throws Exception {
        return Jwts.parser().setSigningKey(rsaKeyHelper.getPublicKey(pubKey)).parseClaimsJws(token);
    }


    /**
     * 获取token中的用户信息
     *
     * @param token
     * @param pubKey
     * @return
     * @throws Exception
     */
    public static IJWTInfo getInfoFromToken(String token, byte[] pubKey) throws Exception {
        if (token.startsWith("Bearer")) {
            token = token.replace("Bearer ","");
        }
        Jws<Claims> claimsJws = parserToken(token, pubKey);
        Claims body = claimsJws.getBody();
        return new JWTInfo(helpString(body.get(JwtConstant.JWT_KEY_USER_NAME)),
                helpString(body.get(JwtConstant.JWT_KEY_USER_ID)),
                helpString(body.get(JwtConstant.JWT_KEY_TOKEN_ID)),
                Long.parseLong(helpStringLong(body.get(JwtConstant.JWT_KEY_EXPIRE_DATE))),
                helpString(body.get(JwtConstant.JWT_KEY_EMAIL)));
    }

    private static String helpString(Object object){
        return object == null ? "": object.toString();
    }
    private static String helpStringLong(Object object){
        return object == null ? "0": object.toString();
    }

}
