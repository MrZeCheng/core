package com.yhglobal.bee.gateway.common.configure;

import com.yhglobal.bee.gateway.common.properties.YhGatewayAuthProperties;
import com.yhglobal.bee.gateway.common.util.JwtTokenUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
@EnableConfigurationProperties(YhGatewayAuthProperties.class)
@ConditionalOnProperty( prefix = "yh.gateway.auth",name = "enable", havingValue = "true", matchIfMissing = true)
@RequiredArgsConstructor
public class YhGatewayAutoConfigure {

    private final YhGatewayAuthProperties yhGatewayAuthProperties;

    @Bean
    public JwtTokenUtil jwtTokenUtil() {
        JwtTokenUtil jwtTokenUtil = new JwtTokenUtil();
        jwtTokenUtil.setExpire(yhGatewayAuthProperties.getExpire());
        jwtTokenUtil.setRefresh(yhGatewayAuthProperties.getRefresh());
        jwtTokenUtil.setSecret(yhGatewayAuthProperties.getSecret());
        return jwtTokenUtil;
    }

}
