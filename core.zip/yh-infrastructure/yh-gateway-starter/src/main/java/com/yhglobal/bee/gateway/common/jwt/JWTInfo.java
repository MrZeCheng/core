package com.yhglobal.bee.gateway.common.jwt;

import java.io.Serializable;
import java.util.StringJoiner;

public class JWTInfo implements Serializable,IJWTInfo{

    private String userId;

    private String userName;

    private String tokenId;
    /**
     * 到期时间
     */
    private Long expireDate;

    private String email;

    @Override
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public Long getExpireDate() {
        return expireDate;
    }

    public JWTInfo setExpireDate(Long expireDate) {
        this.expireDate = expireDate;
        return this;
    }

    @Override
    public String getUserId() {
        return userId;
    }

    public JWTInfo setUserId(String userId) {
        this.userId = userId;
        return this;
    }

    @Override
    public String getUserName() {
        return userName;
    }

    public JWTInfo setUserName(String userName) {
        this.userName = userName;
        return this;
    }

    @Override
    public String getTokenId() {
        return tokenId;
    }

    public JWTInfo setTokenId(String tokenId) {
        this.tokenId = tokenId;
        return this;
    }


    @Override
    public String toString() {
        return new StringJoiner(", ", JWTInfo.class.getSimpleName() + "[", "]")
                .add("userId='" + userId + "'")
                .add("userName='" + userName + "'")
                .add("tokenId='" + tokenId + "'")
                .add("expireDate=" + expireDate)
                .toString();
    }

    public JWTInfo(String userName, String userId, String tokenId, Long expireDate) {
        this.userName = userName;
        this.userId = userId;
        this.tokenId = tokenId;
        this.expireDate  = expireDate;
    }
    public JWTInfo(String userName, String userId, String tokenId, Long expireDate, String email) {
        this.userName = userName;
        this.userId = userId;
        this.tokenId = tokenId;
        this.expireDate  = expireDate;
        this.email  = email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        JWTInfo jwtInfo = (JWTInfo) o;
        if (userName != null ? !userName.equals(jwtInfo.userName) : jwtInfo.userName != null) {
            return false;
        }
        return userId != null ? userId.equals(jwtInfo.userId) : jwtInfo.userId == null;

    }

    @Override
    public int hashCode() {
        int result = userName != null ? userName.hashCode() : 0;
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        return result;
    }

}
