package com.yhglobal.bee.gateway.common.constant;

public interface JWTConstant {

    String JWT_REDIS_PUB = "CLOUD:JWT:PUB";

    String JWT_REDIS_PRI = "CLOUD:JWT:PRI";
}
