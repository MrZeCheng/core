package com.yhglobal.bee.gateway.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "yh.gateway.auth")
public class YhGatewayAuthProperties {

    /**
     * 启动秘钥
     */
    private Boolean enable = true;

    private String header = "authorization";
    /**
     * 过期十个小时
     */
    private int expire = 36000;
    /**
     * 续签时间
     */
    private int refresh = 7200;
    /**
     * 增强保护
     *
     * 若为true每个网关服务启动 都是随机的秘钥
     */
    private Boolean protection = false;
    /**
     * 服务的
     */
    private String secret = "yh-STB3GOX6";

    /**
     * 不拦截的服务 多个已
     */
    private String ignore;

    public String getIgnore() {
        return ignore;
    }

    public YhGatewayAuthProperties setIgnore(String ignore) {
        this.ignore = ignore;
        return this;
    }

    public Boolean getEnable() {
        return enable;
    }

    public YhGatewayAuthProperties setEnable(Boolean enable) {
        this.enable = enable;
        return this;
    }

    public Boolean getProtection() {
        return protection;
    }

    public YhGatewayAuthProperties setProtection(Boolean protection) {
        this.protection = protection;
        return this;
    }

    public String getHeader() {
        return header;
    }

    public YhGatewayAuthProperties setHeader(String header) {
        this.header = header;
        return this;
    }

    public int getExpire() {
        return expire;
    }

    public YhGatewayAuthProperties setExpire(int expire) {
        this.expire = expire;
        return this;
    }

    public int getRefresh() {
        return refresh;
    }

    public YhGatewayAuthProperties setRefresh(int refresh) {
        this.refresh = refresh;
        return this;
    }

    public String getSecret() {
        return secret;
    }

    public YhGatewayAuthProperties setSecret(String secret) {
        this.secret = secret;
        return this;
    }
}
