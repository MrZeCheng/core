基础设施相关
 yh_datasource_starter
 
 相关文档
 
 https://github.com/alibaba/druid/tree/master/druid-spring-boot-starter/
 https://spring.io/projects/spring-data-jpa#overview
 
 
 redis_sdk
 rabbit_sdk
 