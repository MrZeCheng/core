package com.yhglobal.bee.common.exception;

import com.yhglobal.bee.common.exception.constant.ErrorCodeI;

/**
 * 业务异常
 *
 * @author weizecheng
 * @date 2021/1/26 15:25
 */
public class BusinessException extends BaseException {

    private static final long serialVersionUID = 1L;



    public BusinessException(ErrorCodeI errorCode) {
        super(errorCode);
    }

    public BusinessException(ErrorCodeI errorCodeI, Throwable e) {
        super(errorCodeI, e);
    }

    public BusinessException(ErrorCodeI errorCodeI, Object... objects) {
        super(errorCodeI, objects);
    }

    public BusinessException(ErrorCodeI errorCodeI, Throwable e, Object... objects) {
        super(errorCodeI, e, objects);
    }
}
