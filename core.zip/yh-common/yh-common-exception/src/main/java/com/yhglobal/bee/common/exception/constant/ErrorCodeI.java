package com.yhglobal.bee.common.exception.constant;

public interface ErrorCodeI {

    String getCode();

    String getMessage();

    String getMessage(Object... objects);
}
