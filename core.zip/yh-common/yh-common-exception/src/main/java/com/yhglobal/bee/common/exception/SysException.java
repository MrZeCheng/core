package com.yhglobal.bee.common.exception;

import com.yhglobal.bee.common.exception.constant.ErrorCodeI;

public class SysException extends BaseException {

    private static final long serialVersionUID = 4355163994767354840L;


    public SysException(ErrorCodeI errorCode) {
        super(errorCode);
    }

    public SysException(ErrorCodeI errorCodeI, Throwable e) {
        super(errorCodeI, e);
    }

    public SysException(ErrorCodeI errorCodeI, Object... objects) {
        super(errorCodeI, objects);
    }

    public SysException(ErrorCodeI errorCodeI, Throwable e, Object... objects) {
        super(errorCodeI, e, objects);
    }
}