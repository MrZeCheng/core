package com.yhglobal.bee.common.exception;

import com.yhglobal.bee.common.exception.constant.ErrorCodeI;

/**
 * 基础异常
 *
 * @author weizecheng
 * @date 2021/1/29 14:25
 */
public abstract class BaseException extends RuntimeException{
    private static final long serialVersionUID = 1L;
    private String errCode;

    public BaseException(String errMessage) {
        super(errMessage);
    }

    public BaseException(ErrorCodeI errorCodeI) {
        super(errorCodeI.getMessage());
        this.errCode = errorCodeI.getCode();
    }

    public BaseException(ErrorCodeI errorCodeI, Throwable e) {
        super(errorCodeI.getMessage(), e);
        this.errCode = errorCodeI.getCode();
    }

    public BaseException(ErrorCodeI errorCodeI, Object... objects) {
        super(errorCodeI.getMessage(objects));
        this.errCode = errorCodeI.getCode();
    }

    public BaseException(ErrorCodeI errorCodeI, Throwable e, Object... objects) {
        super(errorCodeI.getMessage(objects), e);
        this.errCode = errorCodeI.getCode();
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

}
