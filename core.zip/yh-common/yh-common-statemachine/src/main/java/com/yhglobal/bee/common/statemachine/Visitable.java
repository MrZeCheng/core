package com.yhglobal.bee.common.statemachine;


public interface Visitable {
    String accept(final Visitor visitor);
}
