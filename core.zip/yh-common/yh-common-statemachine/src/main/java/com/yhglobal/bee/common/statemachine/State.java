package com.yhglobal.bee.common.statemachine;


import com.yhglobal.bee.common.statemachine.impl.TransitionType;

import java.util.Collection;
import java.util.Optional;


public interface State<S,E,C> extends Visitable{

    /**
     * Gets the state identifier.
     *
     * @return the state identifiers
     */
    S getId();

    /**
     * Add transition to the state
     * @param event the event of the Transition
     * @param target the target of the transition
     * @return
     */
    Transition<S,E,C> addTransition(E event, State<S, E, C> target, TransitionType transitionType);

    Optional<Transition<S,E,C>> getTransition(E event);

    Collection<Transition<S,E,C>> getTransitions();

}
