package com.yhglobal.bee.common.statemachine.impl;


public class StateMachineException extends RuntimeException{
    public StateMachineException(String message){
        super(message);
    }
}
