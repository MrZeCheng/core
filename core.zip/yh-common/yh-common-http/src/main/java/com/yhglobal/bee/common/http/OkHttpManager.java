package com.yhglobal.bee.common.http;

import com.fasterxml.jackson.core.type.TypeReference;
import com.yhglobal.bee.common.constant.http.YhOkHttpTypeI;
import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.http.constant.YhOkHttpBaseTypeEnum;
import com.yhglobal.bee.common.util.JacksonUtil;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import okhttp3.*;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.Objects;


/**
 * http请求工具类
 * 1. 若没显式指定超时时间，则使用默认mOkHttpClient
 * 2. 若指定了超时时间，则新创建OkHttpClient实例来发送请求
 */
public class OkHttpManager {

    private static final int OK_STATUS = 200;

    /**
     * get请求获取数据流
     * @param targetUrl 请求地址
     * @return 响应结果
     * @throws IOException
     */
    public static InputStream get(String targetUrl) throws IOException {
        Request request = new Request.Builder()
                .url(targetUrl)
                .build();
        Response httpResponse = submit(YhOkHttpBaseTypeEnum.BASE, request);
        ResponseBody body = httpResponse.body();
        Objects.requireNonNull(body, " http body is null!");
        int statusCode = httpResponse.code();
        if (statusCode == OK_STATUS) {
            return body.byteStream();
        }
        throw new BusinessException(ErrorCode.HTTP_ERROR, statusCode);
    }

    /**
     * get请求获取数据流
     * @param targetUrl 请求地址
     * @param headers 请求头
     * @return 输入流
     * @throws IOException
     */
    public static InputStream get(String targetUrl, Headers headers) throws IOException {
        Request request = new Request.Builder()
                .headers(headers)
                .url(targetUrl)
                .build();
        Response httpResponse = submit(YhOkHttpBaseTypeEnum.BASE, request);
        ResponseBody body = httpResponse.body();
        Objects.requireNonNull(body, " http body is null!");
        int statusCode = httpResponse.code();
        if (statusCode == OK_STATUS) {
            return body.byteStream();
        }
        throw new BusinessException(ErrorCode.HTTP_ERROR, statusCode);
    }

    /**
     * get请求获取数据流
     * @param targetUrl 请求地址
     * @return 响应结果
     * @throws IOException
     */
    public static InputStream get(String targetUrl, YhOkHttpTypeI yhOkHttpTypeI) throws IOException {
        Request request = new Request.Builder()
                .url(targetUrl)
                .build();
        Response httpResponse = submit(yhOkHttpTypeI, request);
        ResponseBody body = httpResponse.body();
        Objects.requireNonNull(body, " http body is null!");
        int statusCode = httpResponse.code();
        if (statusCode == OK_STATUS) {
            return body.byteStream();
        }
        throw new BusinessException(ErrorCode.HTTP_ERROR, statusCode);
    }

    /**
     * 请求头带表头
     *
     * @author zecheng.wei
     * @Date 2022/12/16 12:16
     */
    public static <T> T get(String targetUrl, Headers header, TypeReference<T> type) throws IOException {
        Request request = new Request.Builder()
                .headers(header)
                .url(targetUrl)
                .build();
        return request(request, type);
    }

    public static <T> T get(String targetUrl, Headers header, Class<T> type) throws IOException {
        Request request = new Request.Builder()
                .headers(header)
                .url(targetUrl)
                .build();
        return request(request, new TypeReference<T>(){
            @Override
            public Type getType() {
                return type;
            }
        });
    }

    public static <T> T get(String targetUrl, Class<T> type) throws IOException {
        Request request = new Request.Builder()
                .url(targetUrl)
                .build();
        return request(request, new TypeReference<T>(){
            @Override
            public Type getType() {
                return type;
            }
        });
    }

    public static <T> T get(String targetUrl, Class<T> type, YhOkHttpTypeI yhOkHttpTypeI) throws IOException {
        Request request = new Request.Builder()
                .url(targetUrl)
                .build();
        return request(request, new TypeReference<T>(){
            @Override
            public Type getType() {
                return type;
            }
        }, yhOkHttpTypeI);
    }

    public static <T> T postForm(String targetUrl, FormBody postRequest, Class<T> clazz) throws IOException {
        return post(targetUrl, clazz, postRequest);
    }

    public static <T> T postJson(String param, String targetUrl, ContentTypeEnum contentTypeEnum, Class<T> clazz) throws IOException {
        MediaType mediaType = MediaType.parse(contentTypeEnum.contentType);
        RequestBody requestBody = RequestBody.Companion.create(param, mediaType);
        return post(targetUrl, clazz, requestBody);
    }

    public static <T> T postJson(String param, String targetUrl, Class<T> clazz) throws IOException {
        MediaType mediaType = MediaType.parse(ContentTypeEnum.APPLICATION_JSON_UTF8.contentType);
        RequestBody requestBody = RequestBody.Companion.create(param, mediaType);
        return post(targetUrl, clazz, requestBody);
    }

    public static <T> T postJson(String param, String targetUrl, ContentTypeEnum contentTypeEnum, TypeReference<T> type) throws IOException {
        MediaType mediaType = MediaType.parse(contentTypeEnum.contentType);
        RequestBody requestBody = RequestBody.Companion.create(param, mediaType);
        return sendHttp(targetUrl, requestBody, type);
    }

    public static <T> T postJson(String param, String targetUrl, Class<T> clazz, YhOkHttpTypeI yhOkHttpTypeI) throws IOException {
        MediaType mediaType = MediaType.parse(ContentTypeEnum.APPLICATION_JSON_UTF8.contentType);
        RequestBody requestBody = RequestBody.Companion.create(param, mediaType);
        Request request = new Request.Builder()
                .url(targetUrl)
                .post(requestBody)
                .build();
        return request(request, new TypeReference<T>(){
            @Override
            public Type getType() {
                return clazz;
            }
        }, yhOkHttpTypeI);
    }

    /**
     * 支持接收响应结果为null、“”、“\r\n\r\n”
     * @param param json报文
     * @param targetUrl 请求地址
     * @return 响应结果
     * @throws IOException
     */
    public static String postJson(String param, String targetUrl) throws IOException {
        return postJson(param,targetUrl, String.class);
    }

    /**
     * 支持接收响应结果为null、“”、“\r\n\r\n”
     * @param requestBody 请求body
     * @param targetUrl 请求地址
     * @return 响应结果
     * @throws IOException
     */
    public static String postRequest(RequestBody requestBody, String targetUrl) throws IOException {
        return post(targetUrl, String.class,  requestBody);
    }

    /**
     * url与headers
     * @param targetUrl
     * @param headers
     * @param clazz
     * @return
     * @param <T>
     * @throws IOException
     */
    public static <T> T post(String targetUrl, Headers headers, String body, Class<T> clazz) throws IOException {
        MediaType mediaType = MediaType.parse(ContentTypeEnum.APPLICATION_JSON_UTF8.contentType);
        RequestBody requestBody = RequestBody.Companion.create(body, mediaType);
        Request request = new Request.Builder()
                .url(targetUrl)
                .headers(headers)
                .post(requestBody)
                .build();
        return request(request, new TypeReference<T>(){
            @Override
            public Type getType() {
                return clazz;
            }
        });
    }

    /**
     * 修改代码逻辑
     *
     * @author zecheng.wei
     * @Date 2023/6/19 14:59
     */
    public static <T> T post(String targetUrl,String body, TypeReference<T> type) throws IOException {
        MediaType mediaType = MediaType.parse(ContentTypeEnum.APPLICATION_JSON_UTF8.contentType);
        RequestBody requestBody = RequestBody.Companion.create(body, mediaType);
        Request request = new Request.Builder()
                .url(targetUrl)
                .post(requestBody)
                .build();
        return request(request, type);
    }


    /**
     * 增加类型
     *
     * @author zecheng.wei
     * @Date 2023/6/19 11:59
     */
    public static <T> T post(String targetUrl, Headers headers, String body, TypeReference<T> type) throws IOException {
        MediaType mediaType = MediaType.parse(ContentTypeEnum.APPLICATION_JSON_UTF8.contentType);
        RequestBody requestBody = RequestBody.Companion.create(body, mediaType);
        Request request = new Request.Builder()
                .url(targetUrl)
                .headers(headers)
                .post(requestBody)
                .build();
        return request(request,type);
    }

    /**
     * clazz 转 type 方法
     *
     * @author zecheng.wei
     * @Date 2022/12/16 11:56
     * @param targetUrl
     * @param clazz
     * @param requestBody
     * @return
     * @param <T>
     * @throws IOException
     */
    private static <T> T post(String targetUrl, Class<T> clazz, RequestBody requestBody) throws IOException {
        return sendHttp(targetUrl, requestBody, new TypeReference<T>() {
            @Override
            public Type getType() {
                return clazz;
            }
        });
    }

    /**
     *  post 根方法
     *
     * @author zecheng.wei
     * @Date 2022/12/16 11:52
     * @param targetUrl 请求url
     * @param requestBody body
     * @param type 类型
     * @return
     * @param <T>
     * @throws IOException
     */
    private static <T> T sendHttp(String targetUrl, RequestBody requestBody, TypeReference<T> type) throws IOException {
        Request request = new Request.Builder()
                .url(targetUrl)
                .post(requestBody)
                .build();
        return request(request, type);
    }

    /**
     * 根方法 基于基础资料
     *
     * @author zecheng.wei
     * @Date 2022/12/16 11:47
     * @param request 请求头
     * @param type 泛型
     * @return 返回泛型
     * @param <T>
     * @throws IOException
     */
    private static <T> T request(Request request, TypeReference<T> type)throws IOException{
        return request(request, type, YhOkHttpBaseTypeEnum.BASE);
    }

    /**
     * 根方法
     *
     * @author zecheng.wei
     * @Date 2022/12/16 11:47
     * @param request 请求头
     * @param type 泛型
     * @param yhOkHttpTypeI 基础类型
     * @return 返回泛型
     * @param <T>
     * @throws IOException
     */
    private static <T> T request(Request request, TypeReference<T> type, YhOkHttpTypeI yhOkHttpTypeI)throws IOException{
        Response httpResponse = submit(yhOkHttpTypeI, request);
        ResponseBody body = httpResponse.body();
        Objects.requireNonNull(body, " http body is null!");
        String responseBody = body.string();
        int statusCode = httpResponse.code();
        if (statusCode == OK_STATUS) {
            if (type.getType().getTypeName().equals(String.class.getTypeName())) {
                return (T)responseBody;
            }
            return JacksonUtil.json2Bean(responseBody, type);
        }
        throw new BusinessException(ErrorCode.HTTP_ERROR, statusCode);
    }

    /**
     * 选择器
     *
     * @author zecheng.wei
     * @Date 2022/12/16 11:50
     * @param yhOkHttpTypeI 类型
     * @param request 请求头
     * @return
     * @throws IOException
     */
    private static Response submit(YhOkHttpTypeI yhOkHttpTypeI, Request request) throws IOException{
        if (YhOkHttpBaseTypeEnum.BASE.getOkHttpServiceName().equals(yhOkHttpTypeI.getOkHttpServiceName())) {
            return BaseOkHttpExecuteServiceImpl.M_OK_HTTP_CLIENT.newCall(request).execute();
        }
        return YhApplicationContext.getBean(yhOkHttpTypeI.getOkHttpServiceName(), BaseOkHttpExecuteServiceI.class).execute(request);
    }

}
