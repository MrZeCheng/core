package com.yhglobal.bee.common.http.constant;

import com.yhglobal.bee.common.constant.http.YhOkHttpTypeI;

/**
 * http的基本类型
 *
 * @author zecheng.wei
 * @Date 2022/9/20 14:18
 */
public enum YhOkHttpBaseTypeEnum implements YhOkHttpTypeI {

    /**
     * 基础类型
     */
    BASE("baseOkHttpExecuteServiceImpl");

    private final String okHttpServiceName;

    YhOkHttpBaseTypeEnum(String okHttpServiceName){
        this.okHttpServiceName = okHttpServiceName;
    }

    @Override
    public String getOkHttpServiceName() {
        return okHttpServiceName;
    }
}
