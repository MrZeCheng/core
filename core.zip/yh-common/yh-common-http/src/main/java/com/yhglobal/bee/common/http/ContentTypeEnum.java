package com.yhglobal.bee.common.http;

/**
 * http 请求类型
 *
 * @author zecheng.wei
 * @Date 2022/9/14 17:24
 */
public enum ContentTypeEnum {

    /**
     * application/json
     */
    APPLICATION_JSON("application/json"),

    /**
     * text/plain
     */
    TEXT_PLAIN("text/plain"),

    /**
     * application/json; charset=utf-8
     */
    APPLICATION_JSON_UTF8("application/json; charset=utf-8"),

    /**
     * application/x-www-form-urlencoded; charset=utf-8
     */
    APPLICATION_FORM_UTF8("application/x-www-form-urlencoded; charset=utf-8"),

    /**
     * application/json-patch+json
     */
    APPLICATION_JSON_PATCH("application/json-patch+json");

    final String contentType;

    ContentTypeEnum(String contentType) {
        this.contentType = contentType;
    }

    public String getContentType() {
        return contentType;
    }

}
