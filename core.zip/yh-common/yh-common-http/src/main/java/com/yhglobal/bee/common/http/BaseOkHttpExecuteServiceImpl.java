package com.yhglobal.bee.common.http;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * 基础的http实现
 *
 * @author zecheng.wei
 * @Date 2022/9/20 15:12
 */
//@Component("baseOkHttpExecuteServiceImpl")
public class BaseOkHttpExecuteServiceImpl {
    public static final OkHttpClient M_OK_HTTP_CLIENT;

    static {
        M_OK_HTTP_CLIENT = new OkHttpClient.Builder()
                .connectTimeout(48, TimeUnit.SECONDS)
                .readTimeout(48, TimeUnit.SECONDS)
                .writeTimeout(48, TimeUnit.SECONDS)
                .build();
    }

}
