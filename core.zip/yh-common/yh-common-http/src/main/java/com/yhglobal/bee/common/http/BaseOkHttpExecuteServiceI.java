package com.yhglobal.bee.common.http;

import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;

/**
 *
 *
 * @author zecheng.wei
 * @Date 2022/9/20 14:04
 */
public interface BaseOkHttpExecuteServiceI {

    /**
     * 执行请求
     *
     * @author zecheng.wei
     * @Date 2022/9/20 14:05
     */
    Response execute(Request request) throws IOException;
}
