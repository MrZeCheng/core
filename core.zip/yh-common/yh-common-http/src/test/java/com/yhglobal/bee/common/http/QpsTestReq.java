package com.yhglobal.bee.common.http;

import lombok.Data;

@Data
public class QpsTestReq {

    private String msgType;

    private String toCode;

    private String busData;
}
