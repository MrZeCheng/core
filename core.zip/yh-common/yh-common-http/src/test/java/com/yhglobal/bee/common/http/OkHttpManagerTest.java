//package com.yhglobal.bee.common.http;
//
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.core.JsonFactory;
//import com.fasterxml.jackson.core.json.JsonReadFeature;
//import com.fasterxml.jackson.core.json.JsonWriteFeature;
//import com.fasterxml.jackson.databind.DeserializationFeature;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.databind.ObjectWriter;
//import com.fasterxml.jackson.databind.node.JsonNodeFactory;
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//import com.google.gson.JsonParser;
//import com.yhglobal.bee.common.http.constant.YhOkHttpBaseTypeEnum;
//import com.yhglobal.bee.common.util.FileUtil;
//import com.yhglobal.bee.common.util.JacksonUtil;
//import org.apache.commons.lang3.StringEscapeUtils;
//import org.junit.Assert;
//import org.junit.Test;
//
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.Map;
//
//public class OkHttpManagerTest {
//
//    private static Gson gson = null;
//    private static Gson gsonPrettyPrinting = null;
//    static {
//        gson= new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
//        gsonPrettyPrinting = new GsonBuilder().setPrettyPrinting().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
//    }
//
//    public <T> T fromJson(String json, Class<T> classOfT) {
//        return gson.fromJson(json, classOfT);
//    }
//    @Test
//    public void postJsonTest(){
//
////        try {
////            String json = FileUtil.readPathFileAsString("E:\\logs\\490ccf27f1ee454894a437d7d1929ae9_NikeSAP.YH.Wms.InventorySnapshot.Feedback_f4157faf9b8813f48a0a81192667b539.txt");
////            JsonText jsonText = fromJson(json, JsonText.class);
////            try (BufferedWriter writer = new BufferedWriter(new FileWriter("E:\\logs\\1077-0529.txt"))) {
////                writer.write(gsonPrettyPrinting.toJson(JsonParser.parseString(jsonText.getMessageData())));
////            } catch (IOException e) {
////                System.out.println("");
////            }
////
////        }catch (Exception e){
////            System.out.println(e.getMessage());
////        }
//
//    }
//
//    /**
//     * 测试get 请求
//     *
//     * @author zecheng.wei
//     * @Date 2022/12/16 14:12
//     */
//    @Test
//    public void getTest() throws IOException {
////        String json = OkHttpManager.get("http://www.baidu.com", String.class);
////        Assert.assertNotNull(json);
////        String text = OkHttpManager.get("http://www.baidu.com", String.class, YhOkHttpBaseTypeEnum.BASE);
////        Assert.assertNotNull(text);
//        String s = OkHttpManager.get(" https://ipapi.co/118.140.161.130/json",String.class);
//        System.out.println(s);
//        String jsonString = "{\"name\":\"John\",\"age\":30,\"city\":\"New York\"}";
//
//        ObjectMapper mapper = new ObjectMapper();
//        ObjectWriter writer = mapper.writerWithDefaultPrettyPrinter();
//
//        // 解析 JSON 字符串为 JsonNode 对象
//        JsonNode jsonNode = mapper.readTree(jsonString);
//
//        // 将 JsonNode 对象转换为格式化的 JSON 字符串
//        String formattedJson = writer.writeValueAsString(jsonNode);
//
//        System.out.println(formattedJson);
//    }
//
//}
