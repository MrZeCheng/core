package com.yhglobal.bee.common.constant.operation.log;

/**
 * 普通版本的操作日志
 *
 * @author zecheng.wei
 * @date 2022/10/27 14:21
 */
public interface YhOperationLogBaseI {

    String getOperationLogType();

}
