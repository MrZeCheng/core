package com.yhglobal.bee.common.constant;

import java.util.regex.Pattern;

public interface RegexpConstant {

    Pattern CHINESE = Pattern.compile("[\u4e00-\u9fa5]");
}
