package com.yhglobal.bee.common.constant.dictionary;

/**
 * 字典功能的基础接口
 *
 * @author weizecheng
 * @date 2021/9/5 10:47
 */
public interface YhDataDictionaryI {

    /**
     * 字典编码
     *
     * @author weizecheng
     * @date 2021/9/5 10:47
     */
    String getCode();

    /**
     * 描述
     * @return
     */
    String getDescription();

}
