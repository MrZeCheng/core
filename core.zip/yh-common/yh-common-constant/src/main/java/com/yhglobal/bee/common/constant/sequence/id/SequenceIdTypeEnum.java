package com.yhglobal.bee.common.constant.sequence.id;

/**
 * 枚举类型
 *
 * @author weizecheng
 * @date 2021/3/16 12:17
 */
public enum SequenceIdTypeEnum {

    /**
     * 有序Id
     */
    SEGMENT(SequenceIdExtPtConstant.SEGMENT),
    /**
     * 雪花无规则有序Id
     */
    SNOWFLAKE(SequenceIdExtPtConstant.SNOWFLAKE);

    SequenceIdTypeEnum(String type) {
        this.type = type;
    }

    private final String type;

    public String getType() {
        return type;
    }
}
