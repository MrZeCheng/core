package com.yhglobal.bee.common.constant.authority;

/**
 * 权限模块枚举类型
 *
 * @author weizecheng
 * @date 2021/11/22 11:21
 */
public interface YhAuthorityModelTypeI {

    /**
     * 模块编码
     */
    public String getCode();

    public String getSource();

    public String getParentCode();

    public String getDescription();
}
