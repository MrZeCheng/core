package com.yhglobal.bee.common.constant;

public interface ProxyConstant {

    String PROXY_OBJECT_MARK = "$$";
}
