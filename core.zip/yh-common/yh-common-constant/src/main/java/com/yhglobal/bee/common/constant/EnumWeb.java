package com.yhglobal.bee.common.constant;

public class EnumWeb {

    private Integer code;

    private String name;

    public EnumWeb(Integer code,String name){
        this.code = code;
        this.name = name;
    }

    public EnumWeb(){

    }

    public Integer getCode() {
        return code;
    }

    public EnumWeb setCode(Integer code) {
        this.code = code;
        return this;
    }

    public String getName() {
        return name;
    }

    public EnumWeb setName(String name) {
        this.name = name;
        return this;
    }
}
