package com.yhglobal.bee.common.constant.operation.log;

/**
 * 多语言的枚举
 *
 * @author zecheng.wei
 * @date 2022/10/27 14:31
 */
public interface YhOperationLogI18nBaseI {

    String getOperationLogType();
}
