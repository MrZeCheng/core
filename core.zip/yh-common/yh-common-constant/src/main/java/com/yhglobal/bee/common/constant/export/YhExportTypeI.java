package com.yhglobal.bee.common.constant.export;

/**
 * 导出扩展点类型
 *
 * @author weizecheng
 * @date 2021/11/18 11:30
 */
public interface YhExportTypeI {


    /**
     * 导出类型
     */
    String getExportType();

    /**
     * 扩展名
     */
    String getExtensionName();

}
