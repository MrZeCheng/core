package com.yhglobal.bee.common.constant;

/**
 * @Description TODO
 * @Date 2022-12-06 11:00:36
 * @Created by wangsheng
 */
public class BeeGlobalConstant {
    public static final String _Blank ="";
    public static final String SEPARATOR_01 ="-";
    public static final String SPRING_PROFILES_ACTIVE ="spring.profiles.active";
}
