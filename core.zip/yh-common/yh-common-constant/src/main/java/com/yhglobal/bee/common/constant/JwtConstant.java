package com.yhglobal.bee.common.constant;


/**
 * jwt的静态类
 *
 * @author weizecheng
 * @date 2021/2/5 16:20
 */
public interface JwtConstant {

       String JWT_KEY_USER_ID = "userId";

       String JWT_KEY_USER_NAME ="name";

       String JWT_KEY_TOKEN_ID = "id";

       String JWT_KEY_EXPIRE_DATE = "expire";

       String JWT_KEY_EMAIL = "email";

       String JWT_REDIS_KEY = "JWT:USER:ID:";

}
