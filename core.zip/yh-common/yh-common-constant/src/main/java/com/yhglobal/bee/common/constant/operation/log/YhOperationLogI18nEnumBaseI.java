package com.yhglobal.bee.common.constant.operation.log;

/**
 * 多语言操作日志枚举
 *
 * @author zecheng.wei
 * @date 2022/10/27 14:30
 */
public interface YhOperationLogI18nEnumBaseI {

    Integer getCode();

    String getMessage();

    String getMessage(Object... objects);

}
