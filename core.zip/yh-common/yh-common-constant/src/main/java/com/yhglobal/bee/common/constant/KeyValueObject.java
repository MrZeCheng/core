package com.yhglobal.bee.common.constant;

public  class KeyValueObject {

    private String key;

    private String value;


    public KeyValueObject(String key,String value){
        this.key = key;
        this.value = value;
    }

    public KeyValueObject(){

    }

    public String getKey() {
        return key;
    }

    public KeyValueObject setKey(String key) {
        this.key = key;
        return this;
    }

    public String getValue() {
        return value;
    }

    public KeyValueObject setValue(String value) {
        this.value = value;
        return this;
    }
}
