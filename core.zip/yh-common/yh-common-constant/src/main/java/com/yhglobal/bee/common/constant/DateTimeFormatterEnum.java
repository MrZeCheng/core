package com.yhglobal.bee.common.constant;

/**
 * 枚举时间戳
 *
 * @author weizecheng
 * @date 2021/3/10 15:56
 */
public enum DateTimeFormatterEnum {


    /**
     *
     */
    yyMMdd,


    yyMMddHHmmss,
    /**
     *
     */
    yyyyMMdd;

}
