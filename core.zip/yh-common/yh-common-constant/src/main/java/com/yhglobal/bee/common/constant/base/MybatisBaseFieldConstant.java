package com.yhglobal.bee.common.constant.base;

/**
 *
 *
 * @author zecheng.wei
 * @Date 2022/10/28 10:13
 */
public interface MybatisBaseFieldConstant {

    String BASE = "id, createdDate, createdName, modifiedDate, modifiedName, deleteFlag, dataVersion, ";

}
