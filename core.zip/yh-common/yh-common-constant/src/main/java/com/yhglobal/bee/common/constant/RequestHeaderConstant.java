package com.yhglobal.bee.common.constant;

public interface RequestHeaderConstant {

    String COMMON_HEADER = "Authorization";

    String DATA_PERMISSION = "data-permission";

    String GATE_WAY_PREFIX = "/api/v1";

    String REDIS_JWT_KEY = "REDIS:USER:ID:";

    String FAIL_URL = "fail";

    String I18N_HEADER = "yh-lang";
}
