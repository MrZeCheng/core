package com.yhglobal.bee.common.constant;

public interface ScanConstant {


    String BASE_SCAN_ADDRESS = "com.yhglobal";
}
