package com.yhglobal.bee.common.constant.sequence.id;

public class SequenceIdExtPtConstant {

    public final static String SEGMENT = "SEGMENT";

    public final static String SNOWFLAKE = "SNOWFLAKE";

}
