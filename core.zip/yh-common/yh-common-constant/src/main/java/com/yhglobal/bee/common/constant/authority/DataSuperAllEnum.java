package com.yhglobal.bee.common.constant.authority;

/**
 * 数据权限单个权限点所有
 *
 * @author weizecheng
 * @date 2021/3/26 9:21
 */
public enum  DataSuperAllEnum {

    /**
     * 所有
     */
    ALL(1),
    /**
     * 未拥有所有
     */
    NOT(2);

    DataSuperAllEnum(Integer status){
        this.status = status;
    }

    private Integer status;

    public Integer getStatus() {
        return status;
    }

}
