package com.yhglobal.bee.common.constant.oss;

/**
 * oss枚举类型
 *
 * @author zecheng.wei
 * @date 2022/7/6 17:16
 */
public interface YhOssBaseI {

    public String getOssType();

}
