//package com.yhglobal.bee.common.constant.authority;
//
///**
// * 权限描述
// *
// * @author weizecheng
// * @date 2021/11/22 11:22
// */
//public interface YhAuthorityTypeI {
//
//    /**
//     * 模块编码
//     */
//    public String getCodeModel();
//
//    /**
//     * 模块描述 用于支持国际化
//     */
//    public String getMessage();
//
//}
