package com.yhglobal.bee.common.constant.http;

/**
 * http 客户端类型
 *
 * @author zecheng.wei
 * @Date 2022/9/20 14:10
 */
public interface YhOkHttpTypeI {

    public String getOkHttpServiceName();
}
