package com.yhglobal.bee.common.constant.base;


import java.util.Date;


/**
 * 基础信息表
 *
 * @author weizecheng
 * @date 2021/8/14 15:24
 */
public abstract class BaseSqlEntity {

    private Long id;
    /**
     * 创建时间
     */
    private Date createdDate;
    /**
     * 创建人
     */
    private String createdName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }
}
