package com.yhglobal.bee.common.constant.sequence.id;

import com.yhglobal.bee.common.constant.DateTimeFormatterEnum;

public interface BizNumberI {

    /**
     *  获取最大长度
     */
     Integer getMaxLength();

    /**
     * 获取步长
     * @return
     */
     Integer getStep();

    /**
     * 获取业务名称
     * @return
     */
    String getBizName();

    /**
     * 获取前缀
     * @return
     */
    String getPrefix();

    /**
     * 获取时间戳格式
     * @return
     */
    DateTimeFormatterEnum getDateTimeFormatterEnum();

}
