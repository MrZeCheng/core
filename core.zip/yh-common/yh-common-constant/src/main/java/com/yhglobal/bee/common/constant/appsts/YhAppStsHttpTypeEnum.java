package com.yhglobal.bee.common.constant.appsts;

import com.yhglobal.bee.common.constant.http.YhOkHttpTypeI;

/**
 *
 *
 * @author zecheng.wei
 * @Date 2022/9/20 14:44
 */
public enum YhAppStsHttpTypeEnum implements YhOkHttpTypeI {
    /**
     * appStsOkHttpExecuteServiceImpl
     */
    APP_STS("appStsOkHttpExecuteServiceImpl");

    private final String okHttpServiceName;

    YhAppStsHttpTypeEnum(String okHttpServiceName){
        this.okHttpServiceName = okHttpServiceName;
    }

    @Override
    public String getOkHttpServiceName() {
        return okHttpServiceName;
    }
}
