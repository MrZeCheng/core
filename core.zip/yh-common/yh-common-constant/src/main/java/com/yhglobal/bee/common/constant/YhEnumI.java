package com.yhglobal.bee.common.constant;

/**
 * 枚举类型的基础接口
 *
 * @author weizecheng
 * @date 2021/9/1 9:45
 */
public interface YhEnumI {

    String getMessage();

    Integer getStatus();
}
