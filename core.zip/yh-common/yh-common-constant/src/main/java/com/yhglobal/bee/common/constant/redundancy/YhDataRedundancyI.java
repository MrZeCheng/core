package com.yhglobal.bee.common.constant.redundancy;

public interface YhDataRedundancyI {

    String getCode();
    /**
     * 描述
     */
    String getDescription();
    /**
     * 获取冗余服务url
     */
    String getUrl();

    /**
     * 字段是否国际化
     */
    Boolean getGlobalization();
}
