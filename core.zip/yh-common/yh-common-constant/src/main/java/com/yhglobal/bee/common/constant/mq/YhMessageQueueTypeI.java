package com.yhglobal.bee.common.constant.mq;

/**
 * 消息队列类型
 *
 * @author weizecheng
 * @date 2021/11/9 15:32
 */
public interface YhMessageQueueTypeI {

    /**
     * 关键Key
     */
    String getKey();
    /**
     *  队列名称
     */
    String getQueueName();
    /**
     * 交换器名称
     */
    String getExchangeName();
    /**
     * 交换器类型
     */
    String getExchangeTypes();
    /**
     * 过期时间
     */
    Long getExpiration();

    /**
     * 重试次数
     */
    Long getRetryNumber();

    /**
     * 是否推送死信队列
     */
    Boolean getPushDead();
}
