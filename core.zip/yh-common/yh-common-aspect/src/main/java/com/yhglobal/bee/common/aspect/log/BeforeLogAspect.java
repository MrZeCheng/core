package com.yhglobal.bee.common.aspect.log;


import com.yhglobal.bee.common.util.JacksonUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * 简单输出前置日志作用
 *
 * @author weizecheng
 * @date 2021/3/20 11:49
 */
@Aspect
@Slf4j
public class BeforeLogAspect {

    @Pointcut("@within(com.yhglobal.bee.common.annotation.BeforeLog) && execution(public * *(..))")
    private void pointcutBefore(){
    }


    @Before(value = "pointcutBefore()")
    public void doAccessCheck(JoinPoint joinPoint) {
        String method = joinPoint.getSignature().getDeclaringTypeName()+"."+joinPoint.getSignature().getName();
        MethodSignature methodSignature = (MethodSignature)joinPoint.getSignature();
        Object[] objects = joinPoint.getArgs();
        String[] strings = methodSignature.getParameterNames();
        if(objects.length == strings.length && objects.length > 0){
            Map<String,String> requestMap = new HashMap<>((int)(objects.length / .75f)+1);
            for (int i = 0; i < strings.length; i++) {
                if (objects[i] instanceof ServletRequest || objects[i] instanceof ServletResponse) {
                    continue;
                }
                requestMap.put(strings[i], JacksonUtil.bean2Json(objects[i]));
            }
            log.info("Before：method:{} args:{}", method, JacksonUtil.bean2Json(requestMap));
        }
    }
}
