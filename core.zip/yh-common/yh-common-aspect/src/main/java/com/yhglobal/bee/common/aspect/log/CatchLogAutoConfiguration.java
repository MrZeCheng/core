package com.yhglobal.bee.common.aspect.log;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * 阿里 cole 架构的切面
 *
 * @author weizecheng
 * @date 2021/1/29 14:56
 */
@Configuration
@EnableAspectJAutoProxy
public class CatchLogAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(CatchLogAspect.class)
    public CatchLogAspect catchLogAspect() {
        return new CatchLogAspect();
    }


    @Bean
    @ConditionalOnMissingBean(BeforeLogAspect.class)
    public BeforeLogAspect beforeLogAspect() {
        return new BeforeLogAspect();
    }
}
