package com.yhglobal.bee.common.aspect;


import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.exception.BaseException;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public class ResponseHandler {

    public static Object handle(Class returnType, String errCode, String errMsg){
        if (isResponse(returnType)){
            return handleColaResponse(returnType, errCode, errMsg);
        }
        return null;
    }

    public static Object handle(Class returnType, BaseException e){
        return handle(returnType, e.getErrCode(), e.getMessage());
    }

    private static Object handleColaResponse(Class returnType, String errCode, String errMsg) {
        try {
            YhResponse response = (YhResponse) returnType.getDeclaredConstructor().newInstance();
            response.setSuccess(false);
            response.setErrCode(errCode);
            response.setErrMessage(errMsg);
            return response;
        }
        catch (Exception ex){
            log.error(ex.getMessage(), ex);
            return  null;
        }
    }
    private static boolean isResponse(Class returnType) {
        return  returnType == YhResponse.class || returnType.getGenericSuperclass() == YhResponse.class;
    }
}
