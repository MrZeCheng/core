package com.yhglobal.bee.common.dto;


public abstract class Query extends Command {

    private static final long serialVersionUID = 1L;

}
