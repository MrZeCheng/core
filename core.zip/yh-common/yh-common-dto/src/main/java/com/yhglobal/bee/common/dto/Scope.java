package com.yhglobal.bee.common.dto;


public abstract class Scope extends DTO {

}
