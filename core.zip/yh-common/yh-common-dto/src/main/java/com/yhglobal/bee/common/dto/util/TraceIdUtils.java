package com.yhglobal.bee.common.dto.util;

import com.yhglobal.bee.common.dto.YhResponse;
import org.slf4j.MDC;

/**
 * 从线程里寻找 traceId
 *
 * @author zecheng.wei
 * @Date 2022/12/21 10:24
 */
public class TraceIdUtils {

    public static void setTraceId(YhResponse yhResponse){
        yhResponse.setTraceId(MDC.get("traceId"));
        yhResponse.setApmTraceId(MDC.get("trace.id"));
    }
}
