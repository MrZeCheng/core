package com.yhglobal.bee.common.dto.request;

public class RequestUserThreadLocal {

    private static final ThreadLocal<RequestYhUser> REQUEST_USER_THREAD_LOCAL = new ThreadLocal<>();

    public static RequestYhUser getRequestYhUser() {
        return REQUEST_USER_THREAD_LOCAL.get();
    }

    public static void setRequestYhUser(RequestYhUser requestYhUser){
        REQUEST_USER_THREAD_LOCAL.set(requestYhUser);
    }

    public static void remove(){
        REQUEST_USER_THREAD_LOCAL.remove();
    }

}
