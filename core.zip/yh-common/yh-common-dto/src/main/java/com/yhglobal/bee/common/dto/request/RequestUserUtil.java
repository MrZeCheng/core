package com.yhglobal.bee.common.dto.request;

import com.yhglobal.bee.common.dto.constant.DefaultUserConstant;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 获取用户信息
 *
 * @author weizecheng
 * @date 2021/8/6 10:32
 */
@Component
public class RequestUserUtil {

    @Value("${spring.application.name}")
    private String applicationName;

    public String getUserId(){
        RequestYhUser requestYhUser = RequestUserThreadLocal.getRequestYhUser();
        return  requestYhUser == null ? DefaultUserConstant.DEFAULT_USER : requestYhUser.getUserId();
    }

    public String getUserName(){
        RequestYhUser requestYhUser = RequestUserThreadLocal.getRequestYhUser();
        return  requestYhUser == null ? applicationName: requestYhUser.getUserName();
    }

    public String getEmail(){
        RequestYhUser requestYhUser = RequestUserThreadLocal.getRequestYhUser();
        return  requestYhUser == null ? "" : requestYhUser.getEmail();
    }

}
