package com.yhglobal.bee.common.dto;

import com.yhglobal.bee.common.dto.util.TraceIdUtils;
import com.yhglobal.bee.common.exception.constant.ErrorCodeI;

public class YhResponse extends DTO {

    private static final long serialVersionUID = 1L;

    /**
     * 是否成功
     */
    private Boolean success;

    /**
     * 异常编码
     */
    private String errCode;

    /**
     * 错误消息
     */
    private String errMessage;

    /**
     * 成功返回的message
     */
    private String successMessage;

    /**
     * 业务的 traceId
     */
    private String traceId;

    /**
     * apm traceId
     */
    private String apmTraceId;

    public String getApmTraceId() {
        return apmTraceId;
    }

    public void setApmTraceId(String apmTraceId) {
        this.apmTraceId = apmTraceId;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }

    public Boolean isSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    @Override
    public String toString() {
        return "YhResponse{" +
                "success=" + success +
                ", errCode='" + errCode + '\'' +
                ", errMessage='" + errMessage + '\'' +
                ", successMessage='" + successMessage + '\'' +
                ", traceId='" + traceId + '\'' +
                '}';
    }

    public static YhResponse buildSuccess() {
        YhResponse response = new YhResponse();
        response.setSuccess(true);
        response.setSuccessMessage("success!");
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static YhResponse buildFailure(String errCode, String errMessage) {
        YhResponse response = new YhResponse();
        response.setSuccess(false);
        response.setErrCode(errCode);
        response.setErrMessage(errMessage);
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static YhResponse buildFailure(ErrorCodeI errorCodeI) {
        YhResponse response = new YhResponse();
        response.setSuccess(false);
        response.setErrCode(errorCodeI.getCode());
        response.setErrMessage(errorCodeI.getMessage());
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static YhResponse buildFailure(ErrorCodeI errorCodeI, Object... objects) {
        YhResponse response = new YhResponse();
        response.setSuccess(false);
        response.setErrCode(errorCodeI.getCode());
        response.setErrMessage(errorCodeI.getMessage(objects));
        TraceIdUtils.setTraceId(response);
        return response;
    }

}
