package com.yhglobal.bee.common.dto;


public abstract class Command extends DTO {

    private static final long serialVersionUID = 1L;
}
