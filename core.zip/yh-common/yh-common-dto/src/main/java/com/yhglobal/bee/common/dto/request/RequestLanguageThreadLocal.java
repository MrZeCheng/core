package com.yhglobal.bee.common.dto.request;

/**
 * 线程语言上下文
 *
 * @author weizecheng
 * @date 2021/11/19 11:40
 */
public class RequestLanguageThreadLocal {

    private static final ThreadLocal<String> REQUEST_LANGUAGE_THREAD_LOCAL = new ThreadLocal<>();

    public static String getRequestLanguage() {
        return REQUEST_LANGUAGE_THREAD_LOCAL.get();
    }

    public static void setRequestLanguage(String language){
        REQUEST_LANGUAGE_THREAD_LOCAL.set(language);
    }

    public static void remove(){
        REQUEST_LANGUAGE_THREAD_LOCAL.remove();
    }

}
