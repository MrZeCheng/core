package com.yhglobal.bee.common.dto.request;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * api之间调用 或者网关调用api产生的对象
 *
 * @author weizecheng
 * @date 2021/2/8 14:23
 */
@Data
@Accessors(chain = true)
public class RequestYhUser implements Cloneable{

    /**
     * 用户Id
     */
    private String userId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 邮箱
     */
    private String email;

    @Override
    public RequestYhUser clone(){
        try {
            return (RequestYhUser)super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }


}
