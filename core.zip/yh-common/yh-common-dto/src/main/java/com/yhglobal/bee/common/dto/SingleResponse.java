package com.yhglobal.bee.common.dto;


import com.yhglobal.bee.common.dto.util.TraceIdUtils;
import com.yhglobal.bee.common.exception.constant.ErrorCodeI;

public class SingleResponse<T> extends YhResponse {

    private T data;

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public static SingleResponse buildSuccess() {
        SingleResponse response = new SingleResponse();
        response.setSuccess(true);
        response.setSuccessMessage("success!");
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static SingleResponse buildFailure(String errCode, String errMessage) {
        SingleResponse response = new SingleResponse();
        response.setSuccess(false);
        response.setErrCode(errCode);
        response.setErrMessage(errMessage);
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static <T> SingleResponse<T> ofFailure(String errCode, String errMessage) {
        SingleResponse<T> response = new SingleResponse<>();
        response.setSuccess(false);
        response.setErrCode(errCode);
        response.setErrMessage(errMessage);
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static <T> SingleResponse<T> ofFailure(ErrorCodeI errorCodeI) {
        SingleResponse<T> response = new SingleResponse<>();
        response.setSuccess(false);
        response.setErrCode(errorCodeI.getCode());
        response.setErrMessage(errorCodeI.getMessage());
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static <T> SingleResponse<T> ofFailure(ErrorCodeI errorCodeI, Object... objects) {
        SingleResponse<T> response = new SingleResponse<>();
        response.setSuccess(false);
        response.setErrCode(errorCodeI.getCode());
        response.setErrMessage(errorCodeI.getMessage(objects));
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static <T> SingleResponse<T> of(T data) {
        SingleResponse<T> response = new SingleResponse<>();
        response.setSuccess(data != null);
        response.setSuccessMessage("success!");
        response.setData(data);
        if (data == null) {
            response.setErrCode("A00101");
            response.setErrMessage("Data is null!");
        }
        TraceIdUtils.setTraceId(response);
        return response;
    }
}
