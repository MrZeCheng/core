package com.yhglobal.bee.common.dto.constant;

public interface DefaultUserConstant {

    String DEFAULT_USER = "system";
}
