package com.yhglobal.bee.common.dto;

import java.io.Serializable;


public abstract class DTO implements Serializable {

    private static final long serialVersionUID = 1L;

}
