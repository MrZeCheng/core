package com.yhglobal.bee.common.dto;

import com.yhglobal.bee.common.dto.util.TraceIdUtils;
import com.yhglobal.bee.common.exception.constant.ErrorCodeI;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;


public class MultiResponse<T> extends YhResponse {

    private static final long serialVersionUID = 1L;

    private Collection<T> data;

    public List<T> getData() {
        return null == data ? Collections.emptyList() : new ArrayList<>(data);
    }

    public void setData(Collection<T> data) {
        this.data = data;
    }

    private boolean empty;

    private boolean notEmpty;

    public boolean isEmpty() {
        return data == null || data.size() == 0;
    }

    public boolean isNotEmpty() {
        return !isEmpty();
    }

    public static MultiResponse buildSuccess() {
        MultiResponse response = new MultiResponse();
        response.setSuccess(true);
        response.setSuccessMessage("success!");
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static MultiResponse buildFailure(String errCode, String errMessage) {
        MultiResponse response = new MultiResponse();
        response.setSuccess(false);
        response.setErrCode(errCode);
        response.setErrMessage(errMessage);
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static MultiResponse buildFailure(ErrorCodeI errorCodeI) {
        MultiResponse response = new MultiResponse();
        response.setSuccess(false);
        response.setErrCode(errorCodeI.getCode());
        response.setErrMessage(errorCodeI.getMessage());
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static MultiResponse buildFailure(ErrorCodeI errorCodeI, Object... objects) {
        MultiResponse response = new MultiResponse();
        response.setSuccess(false);
        response.setErrCode(errorCodeI.getCode());
        response.setErrMessage(errorCodeI.getMessage(objects));
        TraceIdUtils.setTraceId(response);
        return response;
    }

    public static <T> MultiResponse<T> of(Collection<T> data) {
        MultiResponse<T> response = new MultiResponse<>();
        response.setSuccess(true);
        response.setSuccessMessage("success!");
        response.setData(data);
        TraceIdUtils.setTraceId(response);
        return response;
    }

}
