package com.yhglobal.bee.common.dto;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.MDC;

public class YhResponseTest {

    @Test
    public void buildSuccessTest(){
        MDC.put("traceId","1324");
        YhResponse yhResponse = YhResponse.buildSuccess();
//        Assert.assertTrue(yhResponse.getSuccess());
        Assert.assertEquals(yhResponse.getTraceId(),"1324");
    }

}
