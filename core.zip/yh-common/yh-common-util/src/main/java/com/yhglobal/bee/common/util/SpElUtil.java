package com.yhglobal.bee.common.util;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

import java.math.BigDecimal;

public class SpElUtil {

    public static final String SPRING_PEL ="R";

    public static BigDecimal getSpElBigDecimal(BigDecimal bigDecimal, String spel){
        try {
            spel = spel.replaceAll(SPRING_PEL,bigDecimal.toString());
            ExpressionParser parser = new SpelExpressionParser();
            Expression exp = parser.parseExpression(spel);
            Double result =  exp.getValue(Double.class);
            return  result == null ? bigDecimal : new BigDecimal(result.toString());
        }catch (Exception e){
            return bigDecimal;
        }
    }

}
