package com.yhglobal.bee.common.util;

import com.yhglobal.bee.common.dto.context.YhApplicationContext;
import com.yhglobal.bee.common.dto.request.RequestLanguageThreadLocal;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

import java.util.Locale;

/**
 * 国际化工具
 *
 * @author weizecheng
 * @date 2021/11/19 14:12
 */
public class I18nUtil {

    private static volatile MessageSource messageSource = null;

    public static String I18N_DELIMITER = ".";


    public static Locale getYhLocale(String language){
        if (StringUtils.isBlank(language)) {
            // 默认中国区
            return Locale.SIMPLIFIED_CHINESE;
        }
        // 中文
        if (language.equals(Locale.SIMPLIFIED_CHINESE.toString())) {
            return Locale.SIMPLIFIED_CHINESE;
        }
        // 英文
        if (language.equals(Locale.ENGLISH.getLanguage())) {
            return Locale.ENGLISH;
        }
        // 繁体中文
        if (language.equals(Locale.TRADITIONAL_CHINESE.toString())) {
            return Locale.TRADITIONAL_CHINESE;
        }
        // 中文
        return Locale.SIMPLIFIED_CHINESE;
    }

    private static MessageSource getMessageSource(){
        if (messageSource == null) {
            synchronized (I18nUtil.class){
                if (messageSource == null) {
                    messageSource = YhApplicationContext.getBean(MessageSource.class);
                }
            }
        }
        return messageSource;
    }

    public static String getMessage(Class className, String key){
        return getMessageSource().getMessage( className.getSimpleName() + I18N_DELIMITER + key.toUpperCase(),null, getYhLocale(RequestLanguageThreadLocal.getRequestLanguage()));
    }

    public static String getMessage(Class className, String key, Object[] var2){
        return getMessageSource().getMessage( className.getSimpleName() + I18N_DELIMITER + key.toUpperCase(),var2, getYhLocale(RequestLanguageThreadLocal.getRequestLanguage()));
    }

    public static String getMessage(String key){
        return getMessageSource().getMessage(key,null, getYhLocale(RequestLanguageThreadLocal.getRequestLanguage()));
    }

    public static String getMessage(String key, Object[] var2){
        return getMessageSource().getMessage(key, var2, getYhLocale(RequestLanguageThreadLocal.getRequestLanguage()));
    }

    public static String getMessage(String key, Object var1){
        return getMessageSource().getMessage(key, new Object[]{var1}, getYhLocale(RequestLanguageThreadLocal.getRequestLanguage()));
    }
}
