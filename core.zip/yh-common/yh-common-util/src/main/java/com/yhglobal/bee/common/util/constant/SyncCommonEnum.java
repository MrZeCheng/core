package com.yhglobal.bee.common.util.constant;

import com.yhglobal.bee.common.constant.YhEnumI;
import com.yhglobal.bee.common.util.I18nUtil;

/**
 * 这里就不做国际化了 直接英文吧
 *
 * @author weizecheng
 * @date 2021/11/19 10:58
 */
public enum SyncCommonEnum implements YhEnumI{
    /**
     * 无需同步
     */
    INIT(1),
    /**
     * 未处理/待同步
     */
    UNHANDLED(2),
    /**
     * 同步进行中
     */
    HANDLING(3),
    /**
     * 同步完成
     */
    HANDLED(4),

    UNKNOWN(5);

    private Integer status;

    public static String getEnumMessage(Integer status){
        for(SyncCommonEnum syncCommonEnum : SyncCommonEnum.values()){
            if(syncCommonEnum.getStatus().equals(status)){
                return syncCommonEnum.getMessage();
            }
        }
        return "";
    }

    @Override
    public String getMessage() {
        return I18nUtil.getMessage(this.getClass(),this.name());
    }


    SyncCommonEnum(Integer status) {
        this.status = status;
    }

    @Override
    public Integer getStatus() {
        return status;
    }

}
