package com.yhglobal.bee.common.util;

import java.math.BigDecimal;

/**
 * 自定义Function
 *
 * @author weizecheng
 * @date 2019/7/25 9:51
 */
@FunctionalInterface
public interface ToBigDecimalFunction <T> {

    BigDecimal applyAsBigDecimal(T value);

}