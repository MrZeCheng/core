package com.yhglobal.bee.common.util;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SqlHelpUtil {
    private static final String SQL_STRING = "'";

    private static final String SQL_LIKE = "LIKE";

    private static final String SQL_OR = "OR";

    private static final String SQL_LIKE_PERCENT = "%";

    private static final String SQL_BLANK_SPACE = " ";

    public static final String SEGMENTATION_SYMBOLS = ",";

    public static final String RIGHT_PARENTHESES = ")";


    /**
     * 返回true 执行方法
     *
     * 返回false 不执行方法
     *
     * @author weizecheng
     * @date 2021/8/16 10:38
     */
    public static boolean methodsFilter(String[] methods,String[] excludeMethods ,String id){
        if(methods.length == 0 && excludeMethods.length == 0){
            return false;
        }
        String methodName = StringUtils.substringAfterLast(id, ".");
        for (String method : excludeMethods) {
            if (StringUtils.equals(method, methodName)) {
                return true;
            }
        }
        for (String method : methods) {
            if (StringUtils.equals(method, methodName)) {
                return false;
            }
        }
        // 如果是true 代表方法不在拦截之内
        return true;
    }


    public static String getSelectInSql(String orderNoList,String beginSql,String endSql){
        // 这里可能需要判断 orderNoList  但是进这个方法都必须为空
        String[] array = orderNoList.split(SEGMENTATION_SYMBOLS);
        return beginSql +
                Arrays.stream(array).filter(StringUtils::isNotBlank).map(a -> String.join(a, SQL_STRING, SQL_STRING)).collect(Collectors.joining(SqlHelpUtil.SEGMENTATION_SYMBOLS)) +
                endSql;
    }

    public static String getSelectInSql(List<String> list){
        // 这里可能需要判断 orderNoList  但是进这个方法都必须为空
        return list.stream().map(a -> String.join(a,SQL_STRING,SQL_STRING)).collect(Collectors.joining(SqlHelpUtil.SEGMENTATION_SYMBOLS));
    }
    public static String getSelectNumInSql(List<Long> list){
        // 这里可能需要判断 orderNoList  但是进这个方法都必须为空

        return list.stream().map(Object::toString).collect(Collectors.joining(SqlHelpUtil.SEGMENTATION_SYMBOLS));
    }
    public static String getSelectNumStringInSql(List<String> list){
        // 这里可能需要判断 orderNoList  但是进这个方法都必须为空
        return String.join(SqlHelpUtil.SEGMENTATION_SYMBOLS, list);
    }

    public static String getSelectNumInSql(String orderNoList,String beginSql,String endSql){
        String[] array = orderNoList.split(SEGMENTATION_SYMBOLS);
        return beginSql + String.join(SqlHelpUtil.SEGMENTATION_SYMBOLS, array) + endSql;
    }

    /**
     *  对某个字段批量模糊查询
     *
     * @author weizecheng
     * @date 2019/1/28 12:14
     * @param orderNoList
     * @param fieldName
     * @return
     */
    public static String getSelectLikeSql(String orderNoList,String fieldName){

        String[] array = orderNoList.split(SEGMENTATION_SYMBOLS);
        int length = array.length;
        int endLength = array.length-1;
        StringBuilder sqlBuilder = new StringBuilder();
        for (int i =0;i<length;i++){
            if(StringUtils.isBlank(array[i].trim())){
                continue;
            }
            sqlBuilder.append(fieldName);
            sqlBuilder.append(SQL_BLANK_SPACE);
            sqlBuilder.append(SQL_LIKE);
            sqlBuilder.append(SQL_BLANK_SPACE);
            sqlBuilder.append(SQL_STRING);
            sqlBuilder.append(SQL_LIKE_PERCENT);
            sqlBuilder.append(array[i].trim());
            sqlBuilder.append(SQL_LIKE_PERCENT);
            sqlBuilder.append(SQL_STRING);
            sqlBuilder.append(SQL_BLANK_SPACE);
            // 最后一个不加上,
            if(i != endLength){
                sqlBuilder.append(SQL_OR);
                sqlBuilder.append(SQL_BLANK_SPACE);
            }
        }
        return sqlBuilder.toString();
    }
}
