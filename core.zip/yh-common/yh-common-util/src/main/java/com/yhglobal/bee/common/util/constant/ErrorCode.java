package com.yhglobal.bee.common.util.constant;

import com.yhglobal.bee.common.exception.constant.ErrorCodeI;
import com.yhglobal.bee.common.util.I18nUtil;

/**
 * 错误信息 编码
 *
 * @author weizecheng
 * @date 2021/11/19 17:06
 */
public enum ErrorCode implements ErrorCodeI{

    /**
     * 数据不存在
     */
    DATA_ABNORMAL("A00101"),

    DATA_ABNORMAL_MESSAGE("A00102"),
//    LINKED_DATA_EXISTS("A00102","Linked data exists!"),
    /**
     * 登录失败
     */
    LOGIN_FAIL("401"),

    BIZ_ERROR("BIZ_ERROR"),

    SYS_ERROR("SYS_ERROR"),

    EXCEL_FAIL("A00103"),

    UPLOAD_FAILED("A00104"),

//    NOT_EDITABLE("A00105", " data not editable!"),
//
    NO_PERMISSION("403"),
//
//    DATA_ABNORMAL_ITEM("A00106", "item data does not exist!"),
//    /**
//     * 数据已存在
//     */
//    DATA_ALREADY_EXISTS("A00107", " data already exists!"),
//
//    PARAMETER_ERROR("A00108", " Parameter error!"),
//    /**
//     * 初始化失败
//     */
//    INIT_FAILURE("A00109",  " failed to initialize data!"),
//
//    USER_LOGIN_FAIL("A00110","wrong password!"),
//
//
//    GET_TOKEN_ERROR("A00111", " get token error!"),

    HTTP_ERROR("A00112"),
    /**
     * 企业微信通知失败
     */
    WECHAT_WORK_NOTICE_FAILED("A00113"),
//    /**
//     * 添加操作日志失败
//     */
//    QUERY_OPERATION_LOG_FAILED("A00114", " query operation log failed"),
//    /**
//     * 查询操作日志失败
//     */
//    ADD_OPERATION_LOG_FAILED("A00115", " add operation log failed"),
    /**
     * 参数无效
     */
    ARG_NOT_VALID("A00116"),

    OPEN_FEIGN_ERROR("A00117"),

    OPEN_FEIGN_RESULT_ERROR("A00118"),

    UPLOAD_EXCEPTION("A00119"),

    DOWNLOAD_EXCEPTION("A00120");

    private String code;


    ErrorCode(String code){
        this.code = code;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return I18nUtil.getMessage(this.getClass(), this.name());
    }

    @Override
    public String getMessage(Object... objects) {
        return I18nUtil.getMessage(this.getClass(), this.name(),objects);
    }


}
