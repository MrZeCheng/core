package com.yhglobal.bee.common.util;

import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.util.constant.ErrorCode;


public class YhObjectUtil {

    public static <T> T requireNonNull(T obj, String message) {
        if (obj == null){
            throw new BusinessException(ErrorCode.DATA_ABNORMAL_MESSAGE,message);
        }
        return obj;
    }


    public static <T extends YhResponse> T requireYhResponseNonNull(T obj) {
        requireNonNull(obj);
        if(!obj.isSuccess()){
            throw new BusinessException(ErrorCode.OPEN_FEIGN_RESULT_ERROR,obj.getErrMessage());
        }
        return obj;
    }

    public static <T> T requireNonNull(T obj) {
        if (obj == null){
            throw new BusinessException(ErrorCode.DATA_ABNORMAL);
        }
        return obj;
    }
}
