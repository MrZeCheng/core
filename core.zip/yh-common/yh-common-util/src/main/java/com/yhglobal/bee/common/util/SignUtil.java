package com.yhglobal.bee.common.util;

import java.util.Base64;

/**
 * 参数类: 主要是用来拼装推送tms携带参数
 *
 * @author wengjunwei
 * @date 2022/2/11 17:48
 */
public class SignUtil {

    /**
     * 拼装推送tms携带参数
     *
     * @author wengjunwei
     * @date 2022/2/11 17:48
     */
    public static String signUrl(String json, String key, String secret) {
        String msgType = "1005";
        String toCode = "ETMS";
        String requestUrl = "?appKey=%s&msgType=%s&ts=%s&toCode=%s&sign=";
        String date = String.valueOf(System.currentTimeMillis());
        String url = String.format(requestUrl, key, msgType, date, toCode);
        String stringJoiner = key + msgType + toCode + date + json + secret;
        String md5 = Md5Util.md5(stringJoiner);
        String sign = Base64Util.encode(md5);
        return url + sign;
    }
}