package com.yhglobal.bee.common.util;

import org.springframework.core.io.ClassPathResource;

import java.io.*;

/**
 * 文件读取工具类
 */
public class FileUtil {

    /**
     * 读取文件内容，作为字符串返回
     */
    public static String readFileAsString(String filePath) throws IOException {
        ClassPathResource classPathResource = new ClassPathResource(filePath);
        StringBuilder sb = new StringBuilder();
        try(InputStream inputStream = classPathResource.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {
            String data = bufferedReader.readLine();
            while (data!=null){
                sb.append(data);
                data = bufferedReader.readLine();
            }
        }
        return sb.toString();
    }
}
