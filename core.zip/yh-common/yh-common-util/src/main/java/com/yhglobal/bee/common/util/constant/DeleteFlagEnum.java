package com.yhglobal.bee.common.util.constant;

import com.yhglobal.bee.common.constant.YhEnumI;
import com.yhglobal.bee.common.util.I18nUtil;

/**
 * 是否删除枚举
 *
 * @author weizecheng
 * @date 2021/3/26 13:19
 */
public enum  DeleteFlagEnum implements YhEnumI{
    /**
     * 存在
     */
    EXITS(0),
    /**
     * 删除
     */
    DELETE(1);

    DeleteFlagEnum(Integer status){
        this.status = status;
    }


    @Override
    public String getMessage() {
        return I18nUtil.getMessage(this.getClass(), this.name());
    }

    private Integer status;

    @Override
    public Integer getStatus() {
        return status;
    }

}
