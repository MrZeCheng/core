package com.yhglobal.bee.common.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * 64位加密
 *
 * @author weizecheng
 * @date 2021/2/23 18:51
 */
public class Base64Util {

//    private final static Base64.Encoder ENCODER = Base64.getEncoder();
//    private final static Base64.Decoder DECODER = Base64.getDecoder();

    /**
     * 给字符串加密
     * @param text
     * @return
     */
    public static String encode(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }


    /**
     * 解密
     * @param encodedText
     * @return
     */
    public static String decode(String encodedText) {
        return new String(Base64.getDecoder().decode(encodedText), StandardCharsets.UTF_8);
    }

//    public static void main(String[] args) {
//        System.out.println(encode("client_id:client_secret"));
//        System.out.println(decode("Y2xpZW50X2lkOmNsaWVudF9zZWNyZXQ="));
//    }

}
