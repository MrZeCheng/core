package com.yhglobal.bee.common.util;

import org.apache.commons.lang3.StringUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    public static String DATE_FORMAT = "yyyy-MM-dd";
    public static String DATE_FORMAT_YYYY_MM_DD = "yyyyMMdd";

    public static String DATE_FORMATS = "yyyy-MM-dd HH:mm:ss";

    public static String getCurrentDate() {
        return DateTimeFormatter.ofPattern(DATE_FORMAT).format(LocalDateTime.now());
    }

    public static String getCurrentDate2() {
        return DateTimeFormatter.ofPattern(DATE_FORMATS).format(LocalDateTime.now());
    }


    public static Date stringToDate(String string,String pattern){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        LocalDate localDate = LocalDate.parse(string, formatter);
        Instant instant = localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
        return Date.from(instant);
    }




    /**
     * 在输入日期上增加（+）或减去（-）天数
     *
     * @param date 输入日期
     * @param iday 要增加或减少的天数
     */
    public static Date addDay(Date date, int iday) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.DAY_OF_MONTH, iday);
        return cd.getTime();
    }

    public static long getDayLocalByMinusDate(Date batchDate,Date date) {
        if (null == date) {
            return 0L;
        }
        return ChronoUnit.DAYS.between(batchDate.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime(),date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime());
    }

    public static Date addMonth(Date date, int month) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.MONTH, month);
        return cd.getTime();
    }



    public static Date addDayHourMinute(Date date, int iday,int hour,int minute) {
        Calendar cd = Calendar.getInstance();
        cd.setTime(date);
        cd.add(Calendar.DAY_OF_MONTH, iday);
        cd.add(Calendar.HOUR_OF_DAY, hour);
        cd.add(Calendar.MINUTE,minute);
        return cd.getTime();
    }



    public static String date2str(Date date,String pattern) {
        if (StringUtils.isBlank(pattern)) {
            pattern = DATE_FORMAT;
        }
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
        Instant instant = date.toInstant();
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zoneId);
        return dateTimeFormatter.format(localDateTime);
    }

//    public static String dateToString(Date date,String pattern) {
//        if(StringUtils.isBlank(pattern)){
//            pattern = DATE_FORMAT;
//        }
//        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
//        Instant instant = date.toInstant();
//        ZoneId zoneId = ZoneId.systemDefault();
//        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, zoneId);
//        return dateTimeFormatter.format(localDateTime);
//    }

}
