package com.yhglobal.bee.common.util.constant;

import com.yhglobal.bee.common.constant.YhEnumI;
import com.yhglobal.bee.common.util.I18nUtil;

/**
 * 禁用 启用枚举
 *
 * @author weizecheng
 * @date 2021/8/15 14:56
 */
public enum EnableEnum implements YhEnumI {

    /**
     * 启用
     */
    ENABLE(0),
    /**
     * 禁用
     */
    DISABLE(1);

    private Integer status;


    EnableEnum(Integer status) {
        this.status = status;
    }

    @Override
    public Integer getStatus() {
        return status;
    }

    @Override
    public String getMessage() {
        return I18nUtil.getMessage(this.getClass(), this.name());
    }

    public static String getMessage(Integer status) {
        return EnableEnum.ENABLE.getStatus().equals(status) ? EnableEnum.ENABLE.getMessage() : EnableEnum.DISABLE.getMessage();
    }
}
