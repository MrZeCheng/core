
yh_common_annotation 自定义注解模块

yh_common_constant 自定义常量

yh_common_exception 自定义异常

yh_common_handler 自定义拦截handler

yh_common_utils 自定义工具包

yh_common_core 包含以上所有Jar包

