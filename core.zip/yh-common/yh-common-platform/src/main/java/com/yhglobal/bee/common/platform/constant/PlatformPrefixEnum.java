package com.yhglobal.bee.common.platform.constant;


import java.util.HashMap;

/**
 * 平台枚举
 *
 * 用于分表 - 根据平台分表
 */
public enum PlatformPrefixEnum {
    JD("JD",   "京东" ),
    DUO_DUO_MAI_CAI("DDMC",   "多多买菜" ),
    MEI_TUAN_YOU_XUAN("MTYX",   "美团优选" ),
    SCHY( "SCHY", "客户线下" ),
    BTL("BTL", "越海线下" ),
    GROUP_BUY_CXYX("CXYX", "橙心优选" ),
    GROUP_BUY_HMSX("HMSX", "盒马生鲜" ),
    WDT("WDT", "旺店通" ),
    ;
    private String platformCode;
    private String desc;

    private static HashMap<String, PlatformPrefixEnum> map = new HashMap<>();


    static {
        for (PlatformPrefixEnum value : PlatformPrefixEnum.values()) {
            map.put(value.platformCode, value);
        }
    }

    public static PlatformPrefixEnum getPlatformPrefixEnumByCode(String platformCode) {
        if (map.containsKey(platformCode)) {
            return map.get(platformCode);
        }
        throw new RuntimeException("平台枚举值不存在:"+platformCode);
    }



    PlatformPrefixEnum(String platformCode, String desc) {
        this.platformCode = platformCode;
        this.desc = desc;
    }

    public String getPlatformCode() {
        return platformCode;
    }

    public String getDesc() {
        return desc;
    }


}
