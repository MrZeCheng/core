package com.yhglobal.bee.common.platform.constant;

/**
 * @Description 通知平台信息的类型
 * @Date 2022-06-28 16:58:01
 * @Created by wangsheng
 */
public enum NotifyPlatformMessageType {


    OMS_ORDER_ACCEPT("1", "越海OMS系统已经接单"),
    CUSTOMS_CLEARANCE_BEGIN("2", "开始清关"),
    CUSTOMS_CLEARANCE_FAIL("3", "清关失败"),
    CUSTOMS_CLEARANCE_FINISH("4", "清关完成"),
    NOTIFY_YH_WAREHOUSE("5", "仓库开始接单"),
    NOTIFY_YH_WAREHOUSE_PRINT_ORDER("6", "仓库-打单"),
    NOTIFY_YH_WAREHOUSE_PACKAGE_ORDER("7", "仓库-打包"),
    NOTIFY_YH_WAREHOUSE_ORDER_OUTBOUND("8", "仓库-出库完成"),
    ;

    private String code;

    private String message;

    NotifyPlatformMessageType(String code, String message){
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
