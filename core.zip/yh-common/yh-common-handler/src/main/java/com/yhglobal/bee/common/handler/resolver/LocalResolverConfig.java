package com.yhglobal.bee.common.handler.resolver;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;

/**
 * 配置
 *
 * @author weizecheng
 * @date 2021/11/20 18:43
 */
@Configuration
public class LocalResolverConfig {

    @Bean
    public LocaleResolver localeResolver(){
        return new YhLocalResolver();
    }
}
