package com.yhglobal.bee.common.handler;

import com.yhglobal.bee.common.constant.ScanConstant;
import com.yhglobal.bee.common.dto.YhResponse;
import com.yhglobal.bee.common.exception.BaseException;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.exception.SysException;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;

/**
 * 控制层 切面异常处理
 *
 * @author weizecheng
 * @date 2021/2/5 14:54
 */
@ControllerAdvice(ScanConstant.BASE_SCAN_ADDRESS)
@ResponseBody
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(BaseException.class)
    public YhResponse baseExceptionHandler(HttpServletResponse response, BaseException ex) {
        response.setStatus(HttpStatus.OK.value());
        log.error(ex.getMessage(),ex);
        return YhResponse.buildFailure(ex.getErrCode(),ex.getMessage());
    }

    @ExceptionHandler(BusinessException.class)
    public YhResponse businessExceptionHandler(HttpServletResponse response, BusinessException ex) {
        response.setStatus(HttpStatus.OK.value());
        log.error(ex.getMessage(),ex);
        return YhResponse.buildFailure(ex.getErrCode(),ex.getMessage());
    }

    @ExceptionHandler(SysException.class)
    public YhResponse sysExceptionHandler(HttpServletResponse response, SysException ex) {
        response.setStatus(HttpStatus.OK.value());
        log.error(ex.getMessage(),ex);
        return YhResponse.buildFailure(ex.getErrCode(),ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public YhResponse methodArgumentException(HttpServletResponse response, MethodArgumentNotValidException ex) {
        log.error(ex.getMessage(),ex);
        response.setStatus(HttpStatus.OK.value());
        FieldError fieldError = ex.getBindingResult().getFieldError();
        if (fieldError != null) {
            String message = fieldError.getDefaultMessage();
            if (StringUtils.isNotBlank(message)) {
                return YhResponse.buildFailure(ErrorCode.ARG_NOT_VALID.getCode(), message);
            }
        }
        return YhResponse.buildFailure(ErrorCode.ARG_NOT_VALID.getCode(), ErrorCode.ARG_NOT_VALID.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public YhResponse otherExceptionHandler(HttpServletResponse response, Exception ex) {
        response.setStatus(HttpStatus.OK.value());
        log.error(ex.getMessage(),ex);
        return YhResponse.buildFailure(ErrorCode.SYS_ERROR.getCode(), ErrorCode.SYS_ERROR.getMessage(ex.getMessage()));
    }

}
