package com.yhglobal.bee.common.handler.interceptors;

import com.yhglobal.bee.common.constant.RequestHeaderConstant;
import com.yhglobal.bee.common.dto.constant.DefaultUserConstant;
import com.yhglobal.bee.common.dto.request.RequestLanguageThreadLocal;
import com.yhglobal.bee.common.dto.request.RequestUserThreadLocal;
import com.yhglobal.bee.common.dto.request.RequestYhUser;
import com.yhglobal.bee.common.util.JacksonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

@Slf4j
@Component
public class YhHandlerInterceptor implements HandlerInterceptor {

    @Value("${spring.application.name}")
    private String applicationName;

    private static final RequestYhUser REQUEST_YH_USER = new RequestYhUser().setUserId(DefaultUserConstant.DEFAULT_USER);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 存入本地ThreadLocal
        RequestLanguageThreadLocal.setRequestLanguage(LocaleContextHolder.getLocale().toString());
        String headerJson = request.getHeader(RequestHeaderConstant.COMMON_HEADER);
        // 来源头部为空
        RequestYhUser requestYhUser = REQUEST_YH_USER.clone();
        if (StringUtils.isBlank(headerJson)) {
            requestYhUser.setUserId(DefaultUserConstant.DEFAULT_USER);
            requestYhUser.setUserName(applicationName);
            requestYhUser.setEmail("");
        }else {
            try {
                RequestYhUser common = JacksonUtil.json2Bean(URLDecoder.decode(headerJson, StandardCharsets.UTF_8), RequestYhUser.class);
                Objects.requireNonNull(common,"header is no exits !");
                requestYhUser.setUserId(common.getUserId());
                requestYhUser.setUserName(common.getUserName());
                requestYhUser.setEmail(common.getEmail());
            }catch (Exception e){
                requestYhUser.setUserId(DefaultUserConstant.DEFAULT_USER);
                requestYhUser.setUserName(applicationName);
            }
        }
        RequestUserThreadLocal.setRequestYhUser(requestYhUser);
        // 用户Id
        log.debug("请求地址={}",request.getServletPath());
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        RequestUserThreadLocal.remove();
        RequestLanguageThreadLocal.remove();
    }
}
