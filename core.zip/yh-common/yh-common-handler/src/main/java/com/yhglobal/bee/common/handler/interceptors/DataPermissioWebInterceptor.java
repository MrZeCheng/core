package com.yhglobal.bee.common.handler.interceptors;


import com.yhglobal.bee.beans.authority.AuthorityDataBO;
import com.yhglobal.bee.beans.authority.constant.DataPermissionLocal;
import com.yhglobal.bee.common.constant.RequestHeaderConstant;
import com.yhglobal.bee.common.util.JacksonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

@Component
@Slf4j
public class DataPermissioWebInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String headerJson =request.getHeader(RequestHeaderConstant.DATA_PERMISSION);
        // 来源头部为空
        if (StringUtils.isNotBlank(headerJson)) {
            try {
                log.info("DataPermissio = {}",headerJson);
                AuthorityDataBO authorityDataBO = JacksonUtil.json2Bean(URLDecoder.decode(headerJson, StandardCharsets.UTF_8.name()), AuthorityDataBO.class);
                Objects.requireNonNull(authorityDataBO,"header is no exits !");
                DataPermissionLocal.setDataPermission(authorityDataBO);
            }catch (Exception e){
                log.error(" DataPermissioWeb error = {}",e.getMessage());
            }
        }
        // 用户Id
        log.debug("请求地址={}",request.getServletPath());
        return true;
    }


    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        DataPermissionLocal.remove();
    }

}
