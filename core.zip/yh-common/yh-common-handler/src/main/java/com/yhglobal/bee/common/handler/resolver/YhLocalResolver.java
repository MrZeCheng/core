package com.yhglobal.bee.common.handler.resolver;

import com.yhglobal.bee.common.constant.RequestHeaderConstant;
import com.yhglobal.bee.common.util.I18nUtil;
import org.springframework.web.servlet.LocaleResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Locale;

public class YhLocalResolver implements LocaleResolver {
    @Override
    public Locale resolveLocale(HttpServletRequest httpServletRequest) {
        String lang = httpServletRequest.getHeader(RequestHeaderConstant.I18N_HEADER);
        // 获取表头
        return I18nUtil.getYhLocale(lang);
    }

    @Override
    public void setLocale(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Locale locale) {

    }
}
