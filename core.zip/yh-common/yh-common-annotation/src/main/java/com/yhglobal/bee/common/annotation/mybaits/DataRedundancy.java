package com.yhglobal.bee.common.annotation.mybaits;

import com.yhglobal.bee.common.constant.redundancy.YhDataRedundancyI;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Documented
@Retention(RUNTIME)
@Target(TYPE)///接口、类、枚举、注解、方法
public @interface DataRedundancy {

    /**
     * 冗余的表
     *
     * @author weizecheng
     * @date 2021/8/28 12:59
     */
    String tableName();

    /**
     * 冗余字段的关键字
     *
     * @author weizecheng
     * @date 2021/8/28 12:59
     */
    String redundancyCode();

    /**
     * 冗余字段属性
     */
    Class< ? extends YhDataRedundancyI> redundancyName();
}
