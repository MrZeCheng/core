package com.yhglobal.bee.common.annotation.mybaits;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 数据权限注解
 *
 * @author weizecheng
 * @date 2021/3/24 17:14
 */
@Documented
@Retention(RUNTIME)
@Target(TYPE)///接口、类、枚举、注解、方法
public @interface DataPermission {


    /**
     * 拦截的方法名称
     * @return
     */
    String[] methods() default {};

    /**
     * 数据权限关联字段
     * 目前系统数据权限通过dept_id关联
     *
     * @return String
     */
    DataPermissionField[] value()default {};
    /**
     * 数据权限关联字段
     * 目前系统数据权限通过dept_id关联
     *
     * @return String
     */
//    String[] field() default {};
}
