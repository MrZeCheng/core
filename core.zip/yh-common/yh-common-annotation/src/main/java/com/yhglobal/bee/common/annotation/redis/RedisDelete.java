package com.yhglobal.bee.common.annotation.redis;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 删除缓存的注解
 *
 * @author weizecheng
 * @date 2021/2/18 17:07
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RedisDelete {

    /**
     * redis key
     */
    String redisKey() default "";

    /**
     * 是否使用参数拼接到key中
     */
    boolean parameter() default false;

    /**
     * 第几个参数
     */
    int parameterLocation() default 0;

    /**
     * SPEL 表达式
     */
    String SPEL() default "";

}
