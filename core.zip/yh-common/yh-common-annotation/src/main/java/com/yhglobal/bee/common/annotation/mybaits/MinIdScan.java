package com.yhglobal.bee.common.annotation.mybaits;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;


/**
 * 注意 目前暂时不支持分表的
 */
@Documented
@Retention(RUNTIME)
@Target(METHOD)
public @interface MinIdScan {
     /**
      * 表名 正则表达式 ， 如果没有分表直接是表名 ，如果分表的使用正则表达式     例如：  [a-zA-Z0-9_]*product_inventory
      * @return
      */
     String tableName();

     /**
      * 扫描多少天的数据
      * @return
      */
     int scanDays();

     /**
      * 主键列名
      * @return
      */
     String primaryKeyColumn();

     /**
      * 日期类型的字段
      * @return
      */
     String createTimeColumn();

}
