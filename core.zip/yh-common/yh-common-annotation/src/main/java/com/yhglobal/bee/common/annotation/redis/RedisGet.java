package com.yhglobal.bee.common.annotation.redis;

import java.lang.annotation.*;

@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RedisGet {

    /**
     * redis key
     */
    String redisKey();

    /**
     * 过期时间 秒作为单位
     */
    long expire() default 0L;

    /**
     * 是否使用参数拼接到key中
     */
    boolean parameter() default false;

    /**
     * 第几个参数
     */
    int parameterLocation() default 0;

    /**
     * 空值是否传入
     * @return
     */
    String SPEL() default "";

    /**
     * 空值是否存入redis
     * @return
     */
    boolean isNull() default false;

}
