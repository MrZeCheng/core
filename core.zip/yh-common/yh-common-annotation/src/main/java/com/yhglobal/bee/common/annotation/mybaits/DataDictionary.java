package com.yhglobal.bee.common.annotation.mybaits;

import com.yhglobal.bee.common.constant.dictionary.YhDataDictionaryI;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 数据权限注解
 *
 * @author weizecheng
 * @date 2021/3/24 17:14
 */
@Documented
@Retention(RUNTIME)
@Target(TYPE)///接口、类、枚举、注解、方法
public @interface DataDictionary {
    /**
     * 数据字典 对象
     * @return
     */
    Class< ? extends YhDataDictionaryI>[] dictionarys();

}
