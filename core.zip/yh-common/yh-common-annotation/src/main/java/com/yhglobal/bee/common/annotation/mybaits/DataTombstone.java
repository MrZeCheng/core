package com.yhglobal.bee.common.annotation.mybaits;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Documented
@Retention(RUNTIME)
@Target(TYPE)///接口、类、枚举、注解、方法
public @interface DataTombstone {

    String[] methods() default {};

    String[] excludeMethods() default {};

    String deleteFlag() default "deleteFlag";
}
