package com.yhglobal.bee.common.annotation.mybaits;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 明细注解
 *
 * @author weizecheng
 * @date 2021/3/24 17:14
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({})
public @interface DataPermissionField {

    Type type() default Type.STRING;

    String field();

    String fieldAlias();

    enum Type {
        /**
         * 原始SQL，分页插件执行前，先执行这个类型
         */
        STRING,
        /**
         * count SQL，第二个执行这里
         */
        NUM
    }
}
