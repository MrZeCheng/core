package com.yhglobal.bee.common.annotation.mybaits;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Documented
@Retention(RUNTIME)
@Target(TYPE)///接口、类、枚举、注解、方法
public @interface DataInsertAndUpdate {

    String[] updateMethods() default {};

    String[] excludeUpdateMethods() default {};

    String[] insertMethods() default {};

    String[] excludeInsertMethods() default {};

    String modifiedName() default "modifiedName";

    String modifiedDate() default "modifiedDate";

    String createdName() default "createdName";

    String createdDate() default "createdDate";

    String deleteFlag() default "deleteFlag";

    String dataVersion() default "dataVersion";

    /**
     * true 插入更新存id  false 插入更新存名称
     */
    boolean depositIdFlag() default true;
}
