package com.yhglobal.bee.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 重复提交枚举
 * 适用于：接口、类、枚举、注解、方法
 * @author junwei.weng
 */
@Documented
@Retention(RUNTIME)
@Target(METHOD)
public @interface RepeatedSubmitValidate {

    /**
     * 提示信息
     */
    String message() default "提交过于频繁,请稍后提交!";

    /**
     * 重复提交间隔
     */
    long overdueTime() default 800L;
}
