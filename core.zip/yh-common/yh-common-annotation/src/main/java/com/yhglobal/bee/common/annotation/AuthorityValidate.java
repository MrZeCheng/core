package com.yhglobal.bee.common.annotation;



import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 防止重复提交注解
 *
 * @author weizecheng
 * @date 2020/5/26 12:19
 */
@Documented
@Retention(RUNTIME)
@Target(METHOD)///接口、类、枚举、注解、方法
public @interface AuthorityValidate {


    String code() default "";

    String source() default "";

    String parentCode() default "";

    String description() default "";

    String level() default "1";

    String[] url() default {};

//    Class< ? extends YhAuthorityModelTypeI> authority();

    /**
     * 描述此方法的的内容
     */
//    String message();
//    /**
//     * 名称 通常用方法名称
//     */
//    String name()  default "";
}
