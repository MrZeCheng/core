package com.yhglobal.bee.common.annotation;

import java.lang.annotation.*;

/**
 * @author wangsheng
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface MethodLog {
    /**
     * 描述
     * @return
     */
    String description() default "" ;
}
