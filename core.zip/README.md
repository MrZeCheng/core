
# core
=======
# yh-beans

 ### yh-bean-authority(权限DTO依赖)

 ### yh-bean-common(公共DTO依赖)

-----------------------------------

# yh-common

### yh-common-annotation(自定义注解)
###
### yh-common-aspect(切面 入参日志等等)
###
### yh-common-constant(公共常量)
###
### yh-common-dto(统一 DTO 入参,返回值等等)
###
### yh-common-exception(公共异常)
###
### yh-common-extension(扩展点 用于接口多实现)
###
### yh-common-handler(统一异常拦截,以及web统一拦截器)
###
### yh-common-http( okhttp3 http调用)
###
### yh-common-statemachine (状态机)
###
### yh-common-utils (公用工具类 Jackson工具类等等)

-----------------------------------

# yh-infrastructure

### yh-authority-starter (权限点注册 用于cloud项目)
###
### yh-datasource-starter (spring data jpa)
###
### yh-eas-starter(eas 相关 暂时无用)
###
### yh-elk-starter (elk配置)
###
### yh-excel-starter (excel 解析)
###
### yh-gateway-starter (网关层使用)
###
### yh-i18n-starter (暂时无用)
###
### yh-job-starter (定时任务)
###
### yh-mongodb-starter （spring data mongodb）
###
### yh-mybatis-datasource-starter （mybatis orm）
###
### yh-oss-starter （oss 上传下载文件）
###
### yh-redis-starter （redis）
###
### yh-swagger-starter (接口文档)
###
### yh-tx-lcn-starter(暂时无用)
###
### yh-validate-starter (统一校验)
###
### yh-wechat-work-starter (企业微信通知)

-----------------------------------

# yh-server-api

### api-common (api层公共依赖)
    

-----------------------------------
    
# yh-authority-starter

```yml
yh:
  authority:
    registration:
      url: XXXX  #服务名称
```


# yh-datasource-starter

```yml
spring:
  jpa:
    hibernate:
      naming:
        physical-strategy: com.yhgolbal.bee.jpa.common.interceptors.YhSubTableStrategy # 命名规则 
      ddl-auto: update #自动更新
    # show-sql: true  #日志中显示sql语句
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/XXXXX?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
    username: ROOT
    password: 1234
    driver-class-name: com.mysql.cj.jdbc.Driver
```

# yh-elk-starter

 引入logback-spring.xml文件
```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

    <property name="LOGS" value="logs"/>

    <springProperty scope="context" name="SPRING_LOG_NAME" source="spring.application.name" />
    <springProperty scope="context" name="SPRING_CLOUD_CONFIG" source="spring.profiles.active" />
    <!--<springProperty scope="context" name="ES_USER_NAME" source="es.user"  />-->
    <!--<springProperty scope="context" name="ES_PASSWORD" source="es.password" />-->


    <appender name="Console"
              class="ch.qos.logback.core.ConsoleAppender">
        <layout class="ch.qos.logback.classic.PatternLayout">
            <Pattern>
                %black(%d{ISO8601}) %highlight(%-5level) [%green(%t)][%green(${SPRING_LOG_NAME},%X{traceId},%X{spanId})] %yellow(%C{1.}): %msg%n%throwable
                <!--[%X{traceId}/%X{spanId}] %-5p [%t] %C{2} - %m%n-->
            </Pattern>
            <!--<charset>UTF-8</charset>-->
        </layout>
    </appender>

    <appender name="RollingFile"
              class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOGS}/${SPRING_LOG_NAME}.log</file>
        <encoder
                class="ch.qos.logback.classic.encoder.PatternLayoutEncoder">
            <Pattern> %d{ISO8601} %-5level [%t][${SPRING_LOG_NAME},%X{traceId},%X{spanId}] %C{1.}: %msg%n%throwable</Pattern>
            <charset>UTF-8</charset>
        </encoder>
        <rollingPolicy
                class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <!-- rollover daily and when the file reaches 10 MegaBytes -->
            <fileNamePattern>${LOGS}/%d{yyMM}/%d{dd}/${SPRING_LOG_NAME}-%i.log
            </fileNamePattern>
            <timeBasedFileNamingAndTriggeringPolicy
                    class="ch.qos.logback.core.rolling.SizeAndTimeBasedFNATP">
                <maxFileSize>100MB</maxFileSize>
            </timeBasedFileNamingAndTriggeringPolicy>
        </rollingPolicy>
    </appender>
    <appender name="ELASTIC" class="com.internetitem.logback.elasticsearch.ElasticsearchAppender">
        <url>http://scmp:XbK9CVwZ79pTZEYG@es.platform.yhglobal.cn/scmp.scp.${SPRING_CLOUD_CONFIG}/_bulk</url>
        <index>scmp.scp.${SPRING_LOG_NAME}.${SPRING_CLOUD_CONFIG}-%date{yyyy-MM-dd}</index>
        <type>scp</type>
        <loggerName>linkanyway-logger</loggerName> <!-- optional -->
        <errorLoggerName>linkanyway-error-logger</errorLoggerName> <!-- optional -->
        <connectTimeout>30000</connectTimeout> <!-- optional (in ms, default 30000) -->
        <errorsToStderr>false</errorsToStderr> <!-- optional (default false) -->
        <includeCallerData>false</includeCallerData> <!-- optional (default false) -->
        <logsToStderr>false</logsToStderr> <!-- optional (default false) -->
        <maxQueueSize>104857600</maxQueueSize> <!-- optional (default 104857600) -->
        <maxRetries>3</maxRetries> <!-- optional (default 3) -->
        <readTimeout>30000</readTimeout> <!-- optional (in ms, default 30000) -->
        <sleepTime>250</sleepTime> <!-- optional (in ms, default 250) -->
        <rawJsonMessage>false</rawJsonMessage> <!-- optional (default false) -->
        <includeMdc>false</includeMdc> <!-- optional (default false) -->
        <maxMessageSize>100</maxMessageSize> <!-- optional (default -1 -->
        <authentication class="com.internetitem.logback.elasticsearch.config.BasicAuthentication"/> <!-- optional -->
        <properties>
            <property>
                <name>host</name>
                <value>${HOSTNAME}</value>
                <allowEmpty>false</allowEmpty>
            </property>
            <property>
                <name>level</name>
                <value>%level</value>
            </property>
            <property>
                <name>traceId</name>
                <value>%X{traceId}</value>
            </property>
            <property>
                <name>thread</name>
                <value>%thread</value>
            </property>
            <property>
                <name>stacktrace</name>
                <value>%ex</value>
            </property>
            <property>
                <name>logger</name>
                <value>%logger</value>
            </property>
        </properties>
        <headers>
            <header>
                <name>Content-Type</name>
                <value>application/json</value>
            </header>
        </headers>
    </appender>

    <!-- LOG everything at INFO level -->
    <root level="info">
        <appender-ref ref="RollingFile"/>
        <appender-ref ref="Console"/>
        <!--所有的日志都会通过ELASTIC为名的appender计入es-->
        <appender-ref ref="ELASTIC"/>
    </root>

    <!-- LOG "com.baeldung*" at TRACE level -->
    <!--<logger name="com.baeldung" level="trace" additivity="false">-->
    <!--<appender-ref ref="RollingFile"/>-->
    <!--<appender-ref ref="ELASTIC"/>-->
    <!--</logger>-->

    <logger name="com.internetitem.logback.elasticsearch" level="OFF">

    </logger>

    <!--<logger name="es-logger" level="OFF" additivity="false">-->
    <!--<appender-ref ref="ELASTIC"/>-->
    <!--</logger>-->

    <!--<logger name="es-logger" level="OFF" additivity="true">-->
    <!--<appender-ref ref="Console"/>-->
    <!--</logger>-->



    <!--<logger name="com.internetitem.logback.elasticsearch" level="OFF">-->
    <!--<appender-ref ref="Console"/>-->
    <!--</logger>-->

    <!--<logger name="es-logger" level="OFF" additivity="true">-->
    <!--<appender-ref ref="Console"/>-->
    <!--<appender-ref ref="RollingFile"/>-->
    <!--</logger>-->

</configuration>
```

# yh-excel-starter

文档地址:https://www.yuque.com/easyexcel/doc/easyexcel

# yh-job-starter

文档地址:https://www.xuxueli.com/xxl-job/
```yml
yh:
  job:
    admin-addresses: https://job.yhglobal.cn/xxl-job-admin/xxl-job-admin ### 调度中心部署跟地址 [选填]：如调度中心集群部署存在多个地址则用逗号分隔。执行器将会使用该地址进行"执行器心跳注册"和"任务结果回调"；为空则关闭自动注册；
    enable: true
    port: 0 ### 看源码会9999减1 一个一个去获取端口
    log-path: /logs/joblog ### 保存日志路径 需要读写权限
    log-retention-days: 3 ### 执行器日志文件保存天数 [选填] ： 过期日志自动清理, 限制值大于等于3时生效; 否则, 如-1, 关闭自动清理功能；
```

# yh-mongodb-starter

```yml
spring:
  data:
    mongodb:
      uri: mongodb://mongo:aX2eis_d@mongodb.platform.development.yhglobal.cn:27017/wms_cost_calculation
```

# yh-mybatis-datasource-starter

```yml
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/XXXXX?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
    username: root
    password: 1234
    driver-class-name: com.mysql.cj.jdbc.Driver
    type: com.alibaba.druid.pool.DruidDataSource
    
yh:
  mybatis:
    data-permission: true  # 为true 开启数据权限 
```

# yh-oss-starter

```yml
yh:
  oss:
    bucket: yhglobal-bms
    url: https://oss-cn-shenzhen.aliyuncs.com
    key-id: XXXXX
    key-secret: XXXXX
```

# yh-redis-starter

```yml
spring:
  redis:
    port: 6379
    database: 0
    host: XXXX
    password: XXXX
    lettuce: # 这里标明使用lettuce配置
      pool:
        max-active: 10   #连接池最大连接数（使用负值表示没有限制）
        max-wait: -1ms  #连接池最大阻塞等待时间（使用负值表示没有限制）
        max-idle: 5     #连接池中的最大空闲连接
        min-idle: 0     #连接池中的最小空闲连接
    timeout: 10000ms    #连接超时时间（毫秒）
```

# yh-swagger-starter

```yml
yh:
  swagger:
    enable: true
    author: weizecheng
    description: api服务
```

# yh-wechat-work-starter
```yml
yh:
  wechat:
    notice:
      host: http://gw.api.production.yhglobal.cn
      kfptzsApi: /workweixinmanagement/api/v1/sendMsg/sendAlarm
      yhxmsApi: /workweixinmanagement/api/v1/sendMsg/sendMessageToUserByTemplate
      agentId: 1000021
      templateCode: success_info
      subject: BMS
      alarmLevel: 1
      defaultUsers: zecheng.wei,huangjl,hanyj
    threadPool:
      corePoolSize: 1
      maxPoolSize: 1
      queueCapacity: 200
      threadNamePrefix: thread-pool-wechat-
```

