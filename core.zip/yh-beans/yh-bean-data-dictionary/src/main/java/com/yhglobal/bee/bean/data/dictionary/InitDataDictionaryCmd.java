package com.yhglobal.bee.bean.data.dictionary;


import com.yhglobal.bee.common.dto.DTO;

public class InitDataDictionaryCmd extends DTO {

    private String dictionaryCode;

    private String dictionaryItemId;

    /**
     *  语言
     */
    private String language;

    public String getLanguage() {
        return language;
    }

    public InitDataDictionaryCmd setLanguage(String language) {
        this.language = language;
        return this;
    }

    public String getDictionaryCode() {
        return dictionaryCode;
    }

    public InitDataDictionaryCmd setDictionaryCode(String dictionaryCode) {
        this.dictionaryCode = dictionaryCode;
        return this;
    }

    public String getDictionaryItemId() {
        return dictionaryItemId;
    }

    public InitDataDictionaryCmd setDictionaryItemId(String dictionaryItemId) {
        this.dictionaryItemId = dictionaryItemId;
        return this;
    }
}
