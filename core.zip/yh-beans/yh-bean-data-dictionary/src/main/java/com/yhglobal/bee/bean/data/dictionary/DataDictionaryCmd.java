package com.yhglobal.bee.bean.data.dictionary;


import com.yhglobal.bee.common.dto.DTO;

import java.util.List;

public class DataDictionaryCmd extends DTO {

    private List<String> dataDictionaryItemCmds;


    public List<String> getDataDictionaryItemCmds() {
        return dataDictionaryItemCmds;
    }

    public DataDictionaryCmd setDataDictionaryItemCmds(List<String> dataDictionaryItemCmds) {
        this.dataDictionaryItemCmds = dataDictionaryItemCmds;
        return this;
    }
}
