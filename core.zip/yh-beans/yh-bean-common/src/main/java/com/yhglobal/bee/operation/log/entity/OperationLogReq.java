//package com.yhglobal.bee.operation.log.entity;
//
//import com.yhglobal.bee.common.dto.DTO;
//
//import javax.validation.constraints.NotBlank;
//import java.util.StringJoiner;
//
///**
// * 操作日志请求
// * @author yangkaiyun
// * @date 2021/5/13 12:36
// */
//public class OperationLogReq extends DTO {
//
//    @NotBlank(message = "bizNumber, 业务单号不能为空")
//    private String bizNumber;
//
//    @NotBlank(message = "descreption, 操作说明不能为空")
//    private String description;
//
//    private String spareBizNumber;
//
//    @Override
//    public String toString() {
//        return new StringJoiner(", ", OperationLogReq.class.getSimpleName() + "[", "]")
//                .add("bizNumber='" + bizNumber + "'")
//                .add("description='" + description + "'")
//                .add("spareBizNumber='" + spareBizNumber + "'")
//                .toString();
//    }
//
//    public static OperationLogReq valueOf(String bizNumber, String description){
//        OperationLogReq operationLogReq = new OperationLogReq();
//        operationLogReq.bizNumber = bizNumber;
//        operationLogReq.description = description;
//        operationLogReq.spareBizNumber = "";
//        return operationLogReq;
//    }
//
//
//    public static OperationLogReq valueOf(String bizNumber, String description, String spareBizNumber){
//        OperationLogReq operationLogReq = new OperationLogReq();
//        operationLogReq.bizNumber = bizNumber;
//        operationLogReq.description = description;
//        operationLogReq.spareBizNumber = spareBizNumber;
//        return operationLogReq;
//    }
//
//
//    public String getBizNumber() {
//        return bizNumber;
//    }
//
//    public OperationLogReq setBizNumber(String bizNumber) {
//        this.bizNumber = bizNumber;
//        return this;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public OperationLogReq setDescription(String description) {
//        this.description = description;
//        return this;
//    }
//
//    public String getSpareBizNumber() {
//        return spareBizNumber;
//    }
//
//    public OperationLogReq setSpareBizNumber(String spareBizNumber) {
//        this.spareBizNumber = spareBizNumber;
//        return this;
//    }
//}
