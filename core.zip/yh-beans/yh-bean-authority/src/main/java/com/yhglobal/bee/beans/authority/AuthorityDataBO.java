package com.yhglobal.bee.beans.authority;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 *
 * @author weizecheng
 * @date 2021/3/25 18:13
 */
public class AuthorityDataBO implements Serializable {

    /**
     * 用户Id
     */
    private String userId;

    /**
     * 用户名称
     */
    private String userName;

    /**
     * 是否超级管理员 使用基础类型 默认 false;
     */
    private Boolean adminFlag;

    public Boolean getAdminFlag() {
        return adminFlag;
    }

    public AuthorityDataBO setAdminFlag(Boolean adminFlag) {
        this.adminFlag = adminFlag;
        return this;
    }

    /**
     * 超级权限字段
     */
    private Set<String> superColumnSet;

    /**
     * 字段值
     */
    private Map<String, List<String>>  columnValue;

    public String getUserId() {
        return userId;
    }

    public AuthorityDataBO setUserId(String userId) {
        this.userId = userId;
        return this;
    }

    public String getUserName() {
        return userName;
    }

    public AuthorityDataBO setUserName(String userName) {
        this.userName = userName;
        return this;
    }


    public Set<String> getSuperColumnSet() {
        return superColumnSet;
    }

    public AuthorityDataBO setSuperColumnSet(Set<String> superColumnSet) {
        this.superColumnSet = superColumnSet;
        return this;
    }

    public Map<String, List<String>> getColumnValue() {
        return columnValue;
    }

    public AuthorityDataBO setColumnValue(Map<String, List<String>> columnValue) {
        this.columnValue = columnValue;
        return this;
    }

    @Override
    public String toString() {
        return "AuthorityDataBO{" +
                "userId='" + userId + '\'' +
                ", userName='" + userName + '\'' +
                ", adminFlag=" + adminFlag +
                ", superColumnSet=" + superColumnSet +
                ", columnValue=" + columnValue +
                '}';
    }
}
