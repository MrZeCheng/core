package com.yhglobal.bee.beans.authority;

public class AuthorityCheckItemDto {

    /**
     * 关键key
     */
    private String autKey;
    /**
     * 是否拥有权限
     */
    private Integer enableStatus;

    public String getAutKey() {
        return autKey;
    }

    public void setAutKey(String autKey) {
        this.autKey = autKey;
    }

    public Integer getEnableStatus() {
        return enableStatus;
    }

    public void setEnableStatus(Integer enableStatus) {
        this.enableStatus = enableStatus;
    }
}
