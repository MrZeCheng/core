package com.yhglobal.bee.beans.authority;

public class AuthorityCheckUrlDto {

    private String autKey;
    /**
     * 描述
     */
    private String url;

    public String getAutKey() {
        return autKey;
    }

    public void setAutKey(String autKey) {
        this.autKey = autKey;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
