package com.yhglobal.bee.beans.authority;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 权限信息 对外的模型对象
 *
 * @author weizecheng
 * @date 2021/2/19 11:04
 */
@Data
@Accessors(chain = true)
public class AuthorityMainBO implements Serializable {

    /**
     * 描述
     */
    private String url;

    /**
     * 方法名称类型
     */
    private String method;
    /**
     * 凭证
     */
    private String autKey;

    /**
     * 描述 这里可能多语言
     */
    private String functionPermission;

//    /**
//     * 来源模块
//     */
//    private String sourceModel;
//
//    /**
//     * 模块登记
//     */
//    private Integer modelLevel;
//
//    /**
//     * 父模块
//     */
//    private String parentModel;


//    private Long id;
//    /**
//     * 创建时间
//     */
//    private Date createdDate;
//    /**
//     * 最后修改时间
//     */
//    private Date modifiedDate;
//    /**
//     * 版本号
//     */
//    private Long dataVersion;

}
