package com.yhglobal.bee.beans.authority;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class AuthorityCheckDto {

    private Integer adminFlag;

    private Map<String, AuthorityCheckItemDto> itemDtos;

    private  List<AuthorityCheckUrlDto> urlDtos;

    public Integer getAdminFlag() {
        return adminFlag;
    }

    public void setAdminFlag(Integer adminFlag) {
        this.adminFlag = adminFlag;
    }

    public Map<String, AuthorityCheckItemDto> getItemDtos() {
        return itemDtos;
    }

    public void setItemDtos(Map<String, AuthorityCheckItemDto> itemDtos) {
        this.itemDtos = itemDtos;
    }

    public List<AuthorityCheckUrlDto> getUrlDtos() {
        return urlDtos;
    }

    public void setUrlDtos(List<AuthorityCheckUrlDto> urlDtos) {
        this.urlDtos = urlDtos;
    }
}
