package com.yhglobal.bee.beans.authority.constant;

import com.yhglobal.bee.beans.authority.AuthorityDataBO;

public class DataPermissionLocal {

    private static final ThreadLocal<AuthorityDataBO> DATA_PERMISSION_THREAD_LOCAL = new ThreadLocal<>();

    public static AuthorityDataBO getDataPermission() {
        return DATA_PERMISSION_THREAD_LOCAL.get();
    }

    public static void setDataPermission(AuthorityDataBO dataPermissionModel){
        DATA_PERMISSION_THREAD_LOCAL.set(dataPermissionModel);
    }

    public static void remove(){
        DATA_PERMISSION_THREAD_LOCAL.remove();
    }

}
