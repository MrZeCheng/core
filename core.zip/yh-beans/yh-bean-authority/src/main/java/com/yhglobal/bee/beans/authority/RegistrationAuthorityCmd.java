package com.yhglobal.bee.beans.authority;

import com.yhglobal.bee.common.dto.DTO;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * 增加提交的对象
 *
 * @author weizecheng
 * @date 2021/3/28 16:31
 */
@Data
@Accessors(chain = true)
public class RegistrationAuthorityCmd  extends DTO {


    private String projectName;


    private List<AuthorityMainBO> authorityMainBOList;

}
