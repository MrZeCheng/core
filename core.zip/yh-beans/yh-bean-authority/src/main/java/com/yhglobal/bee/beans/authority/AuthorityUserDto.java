package com.yhglobal.bee.beans.authority;

import com.yhglobal.bee.common.dto.DTO;

/**
 * 
 *
 * @author zecheng.wei
 * @Date 2022/11/1 10:42
 */
public class AuthorityUserDto extends DTO {
    
    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
