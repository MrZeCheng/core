package com.yhglobal.scp.sequence.id.dao;

import com.yhglobal.scp.sequence.id.entity.LeafSnowflake;
import com.yhglobal.scp.sequence.id.repository.LeafSnowflakeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class LeafSnowflakeDao {

    private final LeafSnowflakeRepository leafSnowflakeRepository;

    public LeafSnowflake save(LeafSnowflake leafSnowflake){
        return leafSnowflakeRepository.save(leafSnowflake);
    }

    public Optional<LeafSnowflake> findByHostAddress(String hostAddress){
        return leafSnowflakeRepository.findByHostAddress(hostAddress);
    }

}
