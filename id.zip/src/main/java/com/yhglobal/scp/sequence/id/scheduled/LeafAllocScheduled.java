package com.yhglobal.scp.sequence.id.scheduled;

import com.yhglobal.scp.sequence.id.service.LeafAllocService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LeafAllocScheduled {
    private final LeafAllocService leafAllocService;
    @Scheduled(cron = "0 0 3-7 * * ?")
    public void deleteAndInsertSegment(){
        leafAllocService.deleteAndAdd();
    }

}
