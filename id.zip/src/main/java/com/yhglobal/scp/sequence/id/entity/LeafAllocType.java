package com.yhglobal.scp.sequence.id.entity;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Data
@Accessors(chain = true)
@Table(name="yh_segment_id_type",uniqueConstraints ={@UniqueConstraint(columnNames ="idType")})
@EntityListeners(AuditingEntityListener.class)
public class LeafAllocType {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    Long id;

    @Column(name="idType",columnDefinition="varchar(64) BINARY COMMENT '唯一类型'")
    String idType;

    @Column(name = "prefix",columnDefinition="varchar(64) COMMENT '前缀'")
    String prefix;

    @Column(name = "timeFormat",columnDefinition="varchar(64) COMMENT '时间格式'")
    String timeFormat;

    @Column(name = "step",columnDefinition="int(11) COMMENT '号段'")
    Integer step;

    @Column(name = "maxLength",columnDefinition="int(11) COMMENT '最大长度'")
    Integer maxLength;

}
