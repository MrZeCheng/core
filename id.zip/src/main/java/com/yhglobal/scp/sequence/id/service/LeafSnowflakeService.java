package com.yhglobal.scp.sequence.id.service;

public interface LeafSnowflakeService {

    /**
     * 获取机器Id
     *
     * @author weizecheng
     * @date 2021/3/16 15:35
     */
    long getServerIdAsLong();
}
