package com.yhglobal.scp.sequence.id.runner;


import com.yhglobal.bee.common.constant.sequence.id.SequenceIdTypeEnum;
import com.yhglobal.bee.common.dto.extension.BizScenario;
import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.extension.ExtensionExecutor;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.scp.sequence.id.service.SequenceIdServiceExtPt;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Order(-1000)
@Component
@RequiredArgsConstructor
@Slf4j
public class SequenceIdRunner implements CommandLineRunner {

    private final ExtensionExecutor extensionExecutor;

    @Override
    public void run(String... args) {
        try {
            for(SequenceIdTypeEnum sequenceIdTypeEnum : SequenceIdTypeEnum.values()){
                BizScenario bizScenario = BizScenario.valueOf(sequenceIdTypeEnum.name());
                // 获取url
                Boolean aBoolean = extensionExecutor.execute(SequenceIdServiceExtPt.class,bizScenario,SequenceIdServiceExtPt::init);
                if(aBoolean){
                    log.info("{} Service Init Successfully",sequenceIdTypeEnum.name());
                }else {
                    throw new BusinessException(ErrorCode.DATA_ABNORMAL);
                }
            }
        }catch (Exception e){
            log.error("Sequence Id server init fail ! message = {}",e.getMessage());
            System.exit(0);
        }
    }
}
