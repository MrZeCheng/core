package com.yhglobal.scp.sequence.id.domain;


import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.dto.extension.BizScenario;
import com.yhglobal.bee.common.extension.ExtensionExecutor;
import com.yhglobal.bee.common.util.DateUtil;
import com.yhglobal.scp.sequence.id.client.SequenceIdCmd;
import com.yhglobal.scp.sequence.id.model.SingleIdResponse;
import com.yhglobal.scp.sequence.id.service.SequenceIdServiceExtPt;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@RequiredArgsConstructor
@Slf4j
public class SequenceIdDomain {
    private final ExtensionExecutor extensionExecutor;
    public SingleIdResponse<String> getSequenceId(SequenceIdCmd sequenceIdCmd, Boolean overflow) {
        BizScenario bizScenario = BizScenario.valueOf(sequenceIdCmd.getSequenceIdTypeEnum().name());
        String idType = sequenceIdCmd.getKey() + "-" + sequenceIdCmd.getTimeFormat();
        String indexKey;
        if ("YH".equals(sequenceIdCmd.getTimeFormat())){
            indexKey = sequenceIdCmd.getKey() + "-YH";
        }else {
            indexKey = sequenceIdCmd.getKey() + "-" + (sequenceIdCmd.getDateKey() != null ? sequenceIdCmd.getDateKey() : DateUtil.date2str(new Date(), sequenceIdCmd.getTimeFormat()));
        }
        SingleResponse<String> singleResponse = extensionExecutor.execute(SequenceIdServiceExtPt.class, bizScenario, extension -> extension.get(indexKey, idType, sequenceIdCmd.getDateKey()));
        // 获取ur
        SingleResponse<String> stringSingleResponse = extensionExecutor.execute(SequenceIdServiceExtPt.class, bizScenario, extension -> extension.processingId(singleResponse, indexKey, sequenceIdCmd.getPrefix(), sequenceIdCmd.getSuffix(), sequenceIdCmd.getMaxLength(), sequenceIdCmd.getTotalLength()));
        log.info("get data = {}",stringSingleResponse.getData());
        SingleIdResponse<String> singleIdRespons = SingleIdResponse.of(stringSingleResponse.getData(), singleResponse.getData());
        if (sequenceIdCmd.getTotalLength() > 0) {
            if (singleIdRespons.getData().length() != sequenceIdCmd.getTotalLength()) {
                if (overflow) {
                    singleIdRespons.setSuccess(false);
                    singleIdRespons.setErrMessage("长度已溢出");
                    singleIdRespons.setErrCode("BIZ_ERROR");
                }
            }
        }
        return singleIdRespons;
    }
    public SingleResponse<String> getSequenceXpsId(SequenceIdCmd sequenceIdCmd) {
        BizScenario bizScenario = BizScenario.valueOf(sequenceIdCmd.getSequenceIdTypeEnum().name());
        String idType = sequenceIdCmd.getKey() + "-" + sequenceIdCmd.getTimeFormat();
        String format = sequenceIdCmd.getDateKey() != null ? sequenceIdCmd.getDateKey() : DateUtil.date2str(new Date(), sequenceIdCmd.getTimeFormat());
        String indexKey = sequenceIdCmd.getKey() + "-" + format;
        SingleResponse<String> singleResponse = extensionExecutor.execute(SequenceIdServiceExtPt.class,bizScenario, extension -> extension.get(indexKey, idType, sequenceIdCmd.getDateKey()));
        if(!singleResponse.isSuccess()){
            return singleResponse;
        }
        String beginId =  StringUtils.isBlank(sequenceIdCmd.getPrefix()) ?  sequenceIdCmd.getSuffix() + format : sequenceIdCmd.getPrefix() + "_" + sequenceIdCmd.getSuffix() + format;
        StringBuilder stringJoiner = new StringBuilder(beginId);
        String id = singleResponse.getData();
        // 首先前缀等各种长度超过 最大长度
        if(id.length() + stringJoiner.length()  >= 20){
            stringJoiner.append(id);
            return SingleResponse.of(stringJoiner.toString());
        }
        int length = 20 - id.length() - stringJoiner.length();
        stringJoiner.append("0".repeat(Math.max(0, length)));
        stringJoiner.append(id);
        return SingleResponse.of(stringJoiner.toString());
    }
    public MultiResponse<String> getSequenceIdBatchNumber(SequenceIdCmd sequenceIdCmd) {
        BizScenario bizScenario = BizScenario.valueOf(sequenceIdCmd.getSequenceIdTypeEnum().name());
        String idType = sequenceIdCmd.getKey() + "-" + sequenceIdCmd.getTimeFormat();
        String indexKey;
        if ("YH".equals(sequenceIdCmd.getTimeFormat())){
            indexKey = sequenceIdCmd.getKey() + "-YH";
        }else {
            indexKey = sequenceIdCmd.getKey() + "-" + DateUtil.date2str(new Date(), sequenceIdCmd.getTimeFormat());
        }
        return extensionExecutor.execute(SequenceIdServiceExtPt.class,bizScenario, extension -> extension.getBatchNumber(indexKey, idType, sequenceIdCmd));
    }

}
