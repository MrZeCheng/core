package com.yhglobal.scp.sequence.id.service.impl;

import com.yhglobal.bee.common.constant.sequence.id.SequenceIdExtPtConstant;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.extension.Extension;
import com.yhglobal.scp.sequence.id.client.SequenceIdCmd;
import com.yhglobal.scp.sequence.id.service.LeafSnowflakeService;
import com.yhglobal.scp.sequence.id.service.SequenceIdServiceExtPt;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;


/**
 * 雪花算法的实现
 *
 * @author weizecheng
 * @date 2021/3/16 15:55
 */
@Extension(bizId = SequenceIdExtPtConstant.SNOWFLAKE)
@RequiredArgsConstructor
@Slf4j
public class SequenceIdSnowflakeServiceExt implements SequenceIdServiceExtPt {

    private final LeafSnowflakeService leafSnowflakeService;

    @Override
    public boolean init() {
        SHARD_ID = leafSnowflakeService.getServerIdAsLong();
        return true;
    }

    @Override
    public SingleResponse<String> get(String key, String idType, String dateKey) {
        return SingleResponse.of(String.valueOf(nextId()));
    }


    @Override
    public MultiResponse<String> getBatchNumber(String key, String idType, SequenceIdCmd sequenceIdCmd) {
        List<String> orderNo = new ArrayList<>(sequenceIdCmd.getBatchNumber().intValue());
        for (int i = 0 ; i < sequenceIdCmd.getBatchNumber() ; i++) {
            SingleResponse<String> singleResponse = processingId(get(key, idType, null),key,sequenceIdCmd.getPrefix(), sequenceIdCmd.getSuffix(), sequenceIdCmd.getMaxLength(), sequenceIdCmd.getTotalLength());
            orderNo.add(singleResponse.getData() == null ? "" : singleResponse.getData());
        }
        return MultiResponse.of(orderNo);
    }

    private static final long OFFSET = LocalDate.of(2000, 1, 1).atStartOfDay(ZoneId.of("Z")).toEpochSecond();

    private static final long MAX_NEXT = 0b11111_11111111_111L;

    private static long SHARD_ID;

    private static long offset = 0;

    private static long lastEpoch = 0;

    public static long nextId() {
        return nextId(System.currentTimeMillis() / 1000);
    }



    private static synchronized long nextId(long epochSecond) {
        if (epochSecond < lastEpoch) {
            // warning: clock is turn back:
            log.warn("clock is back: " + epochSecond + " from previous:" + lastEpoch);
            epochSecond = lastEpoch;
        }
        if (lastEpoch != epochSecond) {
            lastEpoch = epochSecond;
            reset();
        }
        offset++;
        long next = offset & MAX_NEXT;
        if (next == 0) {
            log.warn("maximum id reached in 1 second in epoch: " + epochSecond);
            return nextId(epochSecond + 1);
        }
        return generateId(epochSecond, next);
    }

    /**
     *  雪花的算法 不算单号长度
     *
     * @author weizecheng
     * @date 2021/3/17 10:02
     */
    @Override
    public SingleResponse<String> processingId(SingleResponse<String> singleResponse, String key, String prefix, String suffix, Integer maxLength, Integer totalLength) {
        return singleResponse;
    }

    private static void reset() {
        offset = 0;
    }


    private static long generateId(long epochSecond, long next) {
        return ((epochSecond - OFFSET) << 21) | (next << 5) | SHARD_ID;
    }
}
