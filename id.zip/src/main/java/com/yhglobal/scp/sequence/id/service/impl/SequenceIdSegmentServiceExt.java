package com.yhglobal.scp.sequence.id.service.impl;


import com.yhglobal.bee.common.constant.sequence.id.SequenceIdExtPtConstant;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.extension.Extension;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.scp.sequence.id.client.SequenceIdCmd;
import com.yhglobal.scp.sequence.id.entity.LeafAlloc;
import com.yhglobal.scp.sequence.id.entity.LeafAllocType;
import com.yhglobal.scp.sequence.id.model.Segment;
import com.yhglobal.scp.sequence.id.model.SegmentBuffer;
import com.yhglobal.scp.sequence.id.service.LeafAllocService;
import com.yhglobal.scp.sequence.id.service.SequenceIdServiceExtPt;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;


/**
 *
 *
 * @author weizecheng
 * @date 2021/3/15 18:50
 */
@Extension(bizId = SequenceIdExtPtConstant.SEGMENT)
@RequiredArgsConstructor
@Slf4j
public class SequenceIdSegmentServiceExt implements SequenceIdServiceExtPt {

    private final LeafAllocService leafAllocService;

    /**
     * 最大步长不超过100,0000
     */
    private static final int MAX_STEP = 1000000;
    /**
     * 一个Segment维持时间为15分钟
     */
    private static final long SEGMENT_DURATION = 15 * 60 * 1000L;

    private ExecutorService service = new ThreadPoolExecutor(5, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), new UpdateThreadFactory());
    private volatile boolean initOK = false;

    private Map<String, SegmentBuffer> cache = new ConcurrentHashMap<>(256);

    private Map<String, LeafAllocType> leafAllocTypeMap = new ConcurrentHashMap<>(256);

    /**
     * 线程工厂名称
     *
     * @author weizecheng
     * @date 2021/3/16 10:41
     */
    public static class UpdateThreadFactory implements ThreadFactory {

        private static int threadInitNumber = 0;

        private static synchronized int nextThreadNum() {
            return threadInitNumber++;
        }

        @Override
        public Thread newThread(Runnable r) {
            return new Thread(r, "Thread-Segment-Update-" + nextThreadNum());
        }
    }


    @Override
    public MultiResponse<String> getBatchNumber(String key, String idType, SequenceIdCmd sequenceIdCmd) {
        List<String> orderNo = new ArrayList<>(sequenceIdCmd.getBatchNumber().intValue());
        for (int i = 0 ; i < sequenceIdCmd.getBatchNumber() ; i++) {
            SingleResponse<String> singleResponse = processingId(get(key,idType, null), key, sequenceIdCmd.getPrefix(), sequenceIdCmd.getSuffix(), sequenceIdCmd.getMaxLength(), sequenceIdCmd.getTotalLength());
            orderNo.add(singleResponse.getData() == null ? "" : singleResponse.getData());
        }
        return MultiResponse.of(orderNo);
    }

    @Override
    public SingleResponse<String> get(String key, String idType, String dateKey) {
        if (!initOK) {
            return SingleResponse.ofFailure(ErrorCode.DATA_ABNORMAL);
        }
        boolean bool = cache.containsKey(key);
        if (!bool){
            if (leafAllocTypeMap.containsKey(idType)) {
                // 这里需要锁key
                synchronized (key.intern()) {
                    if(!cache.containsKey(key)){
                        if (dateKey != null) {
                            leafAllocService.initBizIdBeforeType(key);
                            updateCacheFromDb();
                        }
                    }
                }
            }else {
                // 这里锁类型
                synchronized (idType.intern()) {
                    if (!leafAllocTypeMap.containsKey(idType)) {
                        if (dateKey != null) {
                            leafAllocService.initBizIdBeforeAndType(leafAllocTypeMap, idType, dateKey);
                        }else {
                            leafAllocService.initBizIdType(leafAllocTypeMap, idType);
                        }
                        updateCacheFromDb();
                    }
                }
            }
        }
        SegmentBuffer buffer = cache.get(key);
        if (!buffer.isInitOk()) {
            synchronized (buffer) {
                if (!buffer.isInitOk()) {
                    try {
                        updateSegmentFromDb(key, buffer.getCurrent());
                        log.info("Init buffer. Update leafkey {} {} from db", key, buffer.getCurrent());
                        buffer.setInitOk(true);
                    } catch (Exception e) {
                        log.warn("Init buffer {} exception", buffer.getCurrent(), e);
                    }
                }
            }
        }
        return getIdFromSegmentBuffer(cache.get(key));
    }


    public SingleResponse<String> getIdFromSegmentBuffer(final SegmentBuffer buffer) {
        while (true) {
            buffer.rLock().lock();
            try {
                final Segment segment = buffer.getCurrent();
                if (!buffer.isNextReady() && (segment.getIdle() < 0.9 * segment.getStep()) && buffer.getThreadRunning().compareAndSet(false, true)) {
                    service.execute(() -> {
                        Segment next = buffer.getSegments()[buffer.nextPos()];
                        boolean updateOk = false;
                        try {
                            updateSegmentFromDb(buffer.getKey(), next);
                            updateOk = true;
                            log.info("update segment {} from db {}", buffer.getKey(), next);
                        } catch (Exception e) {
                            log.warn(buffer.getKey() + " updateSegmentFromDb exception", e);
                        } finally {
                            if (updateOk) {
                                buffer.wLock().lock();
                                buffer.setNextReady(true);
                                buffer.getThreadRunning().set(false);
                                buffer.wLock().unlock();
                            } else {
                                buffer.getThreadRunning().set(false);
                            }
                        }
                    });
                }
                long value = segment.getValue().getAndIncrement();
                if (value < segment.getMax()) {
                    return SingleResponse.of(String.valueOf(value));
                }
            } finally {
                buffer.rLock().unlock();
            }
            waitAndSleep(buffer);
            buffer.wLock().lock();
            try {
                final Segment segment = buffer.getCurrent();
                long value = segment.getValue().getAndIncrement();
                if (value < segment.getMax()) {
                    return SingleResponse.of(String.valueOf(value));
                }
                if (buffer.isNextReady()) {
                    buffer.switchPos();
                    buffer.setNextReady(false);
                } else {
                    log.error("Both two segments in {} are not ready!", buffer);
                    return SingleResponse.buildFailure(ErrorCode.DATA_ABNORMAL.getCode(),ErrorCode.DATA_ABNORMAL.getMessage());
                }
            } finally {
                buffer.wLock().unlock();
            }
        }
    }

    public void updateSegmentFromDb(String key, Segment segment) {
        SegmentBuffer buffer = segment.getBuffer();
        LeafAlloc leafAlloc;
        if (!buffer.isInitOk()) {
            leafAlloc = leafAllocService.updateMaxIdAndGetLeafAlloc(key);
            buffer.setStep(leafAlloc.getStep());
            buffer.setMinStep(leafAlloc.getStep());//leafAlloc中的step为DB中的step
        } else if (buffer.getUpdateTimestamp() == 0) {
            leafAlloc = leafAllocService.updateMaxIdAndGetLeafAlloc(key);
            buffer.setUpdateTimestamp(System.currentTimeMillis());
            buffer.setStep(leafAlloc.getStep());
            buffer.setMinStep(leafAlloc.getStep());//leafAlloc中的step为DB中的step
        } else {
            long duration = System.currentTimeMillis() - buffer.getUpdateTimestamp();
            int nextStep = buffer.getStep();
            if (duration < SEGMENT_DURATION) {
                if (nextStep * 2 > MAX_STEP) {
                    //do nothing
                } else {
                    nextStep = nextStep * 2;
                }
            } else if (duration < SEGMENT_DURATION * 2) {
                //do nothing with nextStep
            } else {
                nextStep = nextStep / 2 >= buffer.getMinStep() ? nextStep / 2 : nextStep;
            }
            log.info("leafKey[{}], step[{}], duration[{}mins], nextStep[{}]", key, buffer.getStep(), String.format("%.2f",((double)duration / (1000 * 60))), nextStep);

            leafAlloc = leafAllocService.updateMaxIdByCustomStepAndGetLeafAlloc(key,nextStep);
            buffer.setUpdateTimestamp(System.currentTimeMillis());
            buffer.setStep(nextStep);
            buffer.setMinStep(leafAlloc.getStep());//leafAlloc的step为DB中的step
        }
        // must set value before set max
        long value = leafAlloc.getMaxId() - buffer.getStep();
        if (value == 0L) {
            value = 1L;
        }
        segment.getValue().set(value);
        segment.setMax(leafAlloc.getMaxId());
        segment.setStep(buffer.getStep());
    }


    private void updateCacheFromDb() {
        log.info("update cache from db");
//        StopWatch sw = new Slf4JStopWatch();
        try {
            List<String> dbTags = leafAllocService.findAllId();
            if (dbTags == null || dbTags.isEmpty()) {
                return;
            }
            List<String> cacheTags = new ArrayList<String>(cache.keySet());
            Set<String> insertTagsSet = new HashSet<>(dbTags);
            Set<String> removeTagsSet = new HashSet<>(cacheTags);
            //db中新加的tags灌进cache
            for(int i = 0; i < cacheTags.size(); i++){
                String tmp = cacheTags.get(i);
                if(insertTagsSet.contains(tmp)){
                    insertTagsSet.remove(tmp);
                }
            }
            for (String tag : insertTagsSet) {
                SegmentBuffer buffer = new SegmentBuffer();
                buffer.setKey(tag);
                Segment segment = buffer.getCurrent();
                segment.setValue(new AtomicLong(0));
                segment.setMax(0);
                segment.setStep(0);
                cache.put(tag, buffer);
                log.info("Add tag {} from db to IdCache, SegmentBuffer {}", tag, buffer);
            }
            //cache中已失效的tags从cache删除
            for(int i = 0; i < dbTags.size(); i++){
                String tmp = dbTags.get(i);
                if(removeTagsSet.contains(tmp)){
                    removeTagsSet.remove(tmp);
                }
            }
            for (String tag : removeTagsSet) {
                cache.remove(tag);
                log.info("Remove tag {} from IdCache", tag);
            }
        } catch (Exception e) {
            log.warn("update cache from db exception", e);
        }
    }

    private void waitAndSleep(SegmentBuffer buffer) {
        int roll = 0;
        while (buffer.getThreadRunning().get()) {
            roll += 1;
            if(roll > 10000) {
                try {
                    TimeUnit.MILLISECONDS.sleep(10);
                    break;
                } catch (InterruptedException e) {
                    log.warn("Thread {} Interrupted",Thread.currentThread().getName());
                    break;
                }
            }
        }
    }


    @Override
    public boolean init() {
        leafAllocService.initBiz(leafAllocTypeMap);
        updateCacheFromDb();
        initOK = true;
        updateCacheFromDbAtEveryMinute();
        return initOK;
    }

    @Override
    public SingleResponse<String> processingId(SingleResponse<String> singleResponse, String key, String prefix, String suffix, Integer maxLength, Integer totalLength) {
        if(!singleResponse.isSuccess()){
            return singleResponse;
        }
        key = key.replace("-","");
        if (key.endsWith("YH")) {
            key = key.substring(0,key.length() -2);
        }
        String beginId = StringUtils.isBlank(prefix) ? key : (prefix + key);
        StringBuilder stringJoiner = new StringBuilder(beginId);
        if (totalLength > 0) {
            String id = singleResponse.getData();
            int suffixLength = StringUtils.isBlank(suffix) ? 0 : suffix.length();
            if( (id.length() + beginId.length() + suffixLength) >= totalLength){
                stringJoiner.append(id);
                if (StringUtils.isNotBlank(suffix)) {
                    stringJoiner.append(suffix);
                }
                return SingleResponse.of(stringJoiner.toString());
            }

            int length = totalLength - id.length() - beginId.length() - suffixLength;
            stringJoiner.append("0".repeat(Math.max(0, length)));
            stringJoiner.append(id);
            if (StringUtils.isNotBlank(suffix)) {
                stringJoiner.append(suffix);
            }
            return SingleResponse.of(stringJoiner.toString());
        }else {
            String id = singleResponse.getData();
            // 首先前缀等各种长度超过 最大长度
            if(id.length() >= maxLength){
                stringJoiner.append(id);
                if (StringUtils.isNotBlank(suffix)) {
                    stringJoiner.append(suffix);
                }
                return SingleResponse.of(stringJoiner.toString());
            }
            int length = maxLength - id.length();
            stringJoiner.append("0".repeat(length));
            stringJoiner.append(id);
            if (StringUtils.isNotBlank(suffix)) {
                stringJoiner.append(suffix);
            }
            return SingleResponse.of(stringJoiner.toString());
        }
    }

    private void updateCacheFromDbAtEveryMinute() {
        // 单线程执行
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r);
            t.setName("check-idCache-thread");
            t.setDaemon(true);
            return t;
        });
        service.scheduleWithFixedDelay(this::updateCacheFromDb, 60, 60, TimeUnit.SECONDS);
    }
}
