package com.yhglobal.scp.sequence.id.client;

import com.yhglobal.bee.common.constant.sequence.id.SequenceIdTypeEnum;
import com.yhglobal.bee.common.dto.Command;
import lombok.Data;

/**
 * 唯一Id生成对象
 *
 * @author zecheng.wei
 * @Date 2022/9/6 14:58
 */
@Data
public class SequenceIdCmd extends Command {

    /**
     * 关键的key
     */
    private String key;
    /**
     * 日期格式
     */
    private String timeFormat;
    /**
     * 雪花或者唯一id 枚举
     */
    private SequenceIdTypeEnum sequenceIdTypeEnum;
    /**
     * 前缀
     */
    private String prefix;
    /**
     * 后缀
     */
    private String suffix;
    /**
     * 批量生成编码
     */
    private Long batchNumber;
    /**
     * 单号长度
     */
    private Integer maxLength;
    /**
     * 总长度
     */
    private Integer totalLength;
    /**
     * 日期参数
     */
    private String dateKey;
}
