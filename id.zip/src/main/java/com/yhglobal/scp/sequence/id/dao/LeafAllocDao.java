package com.yhglobal.scp.sequence.id.dao;

import com.yhglobal.scp.sequence.id.entity.LeafAlloc;
import com.yhglobal.scp.sequence.id.repository.LeafAllocRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 
 *
 * @author zecheng.wei
 * @Date 2022/9/6 14:58
 */
@Repository
@RequiredArgsConstructor
public class LeafAllocDao {

    private final LeafAllocRepository leafAllocRepository;


    public Optional<LeafAlloc> findByKey(String key){
        return leafAllocRepository.findByKey(key);
    }

    public boolean existsByKey(String key){
        return leafAllocRepository.existsByKey(key);
    }

    public LeafAlloc save(LeafAlloc leafAlloc){
        return leafAllocRepository.save(leafAlloc);
    }

    public void saveAll(List<LeafAlloc> leafAlloc){
        leafAllocRepository.saveAll(leafAlloc);
    }

    public int updateMaxId(String key){
        return leafAllocRepository.updateMaxId(key);
    }

    public int updateMaxIdByCustomStep(String key, Integer step){
        return leafAllocRepository.updateMaxIdByCustomStep(key, step.longValue());
    }

    public List<String> findAllId(Integer deleteFlag){
        return leafAllocRepository.findAllKey(deleteFlag);
    }

    public List<String> findAllExpireKey(String keyValueLike,
                                      String keyValue,
                                      Integer deleteFlag,
                                         Integer keyValueLength){
        return leafAllocRepository.findAllExpireKey(keyValueLike, keyValue, deleteFlag, keyValueLength);
    }

    public List<String> findYHExpireKey(String keyValueLike,
                                        LocalDateTime localDateTime,
                                         Integer deleteFlag){
        return leafAllocRepository.findYHExpireKey(keyValueLike, localDateTime, deleteFlag);
    }


}
