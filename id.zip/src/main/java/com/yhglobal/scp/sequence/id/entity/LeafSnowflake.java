package com.yhglobal.scp.sequence.id.entity;

import com.yhglobal.bee.jpa.common.entity.BaseEntity;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

/**
 * 算法确定机器Id
 *
 * @author weizecheng
 * @date 2021/3/16 15:24
 */
@Entity
@Data
@Accessors(chain = true)
@Table(name="yh_leaf_snowflake_id",uniqueConstraints ={@UniqueConstraint(columnNames ="hostAddress")})
@EntityListeners(AuditingEntityListener.class)
public class LeafSnowflake extends BaseEntity {

    @Column(name = "hostAddress",columnDefinition="varchar(12) COMMENT '平台Id'")
    private String hostAddress;

}
