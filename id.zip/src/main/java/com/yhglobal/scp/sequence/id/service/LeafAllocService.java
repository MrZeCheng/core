package com.yhglobal.scp.sequence.id.service;

import com.yhglobal.scp.sequence.id.entity.LeafAlloc;
import com.yhglobal.scp.sequence.id.entity.LeafAllocType;

import java.util.List;
import java.util.Map;

/**
 * 相关的数据库实现
 *
 * @author weizecheng
 * @date 2021/3/16 14:39
 */
public interface LeafAllocService {

     LeafAlloc updateMaxIdAndGetLeafAlloc(String id);

     LeafAlloc updateMaxIdByCustomStepAndGetLeafAlloc(String id, Integer step);

     List<String> findAllId();

     void initBiz(Map<String, LeafAllocType> map);

     /**
      * 初始化 idType且当天的
      * @param map
      * @param idType
      */
     void initBizIdType(Map<String, LeafAllocType> map,String idType);

     /**
      * 初始化 idType 且历史的
      *
      * @author zecheng.wei
      * @Date 2022/12/29 10:41
      */
     void initBizIdBeforeAndType(Map<String, LeafAllocType> map,String idType, String dateKey);
     /**
      *
      * 不需要初始化 但历史的
      *
      * @author zecheng.wei
      * @Date 2022/12/29 10:41
      */
     void initBizIdBeforeType(String key);

     void deleteAndAdd();
}
