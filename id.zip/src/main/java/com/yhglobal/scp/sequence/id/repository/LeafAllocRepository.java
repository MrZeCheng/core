package com.yhglobal.scp.sequence.id.repository;

import com.yhglobal.scp.sequence.id.entity.LeafAlloc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


/**
 * 相关接口
 *
 * @author weizecheng
 * @date 2021/3/15 17:18
 */
public interface LeafAllocRepository extends JpaRepository<LeafAlloc, Long> {

    @Modifying(clearAutomatically = true)
    @Query("update LeafAlloc l set l.maxId = l.maxId + l.step  where l.key = :key")
    int updateMaxId(@Param("key")String key);
    Optional<LeafAlloc> findByKey(String key);
    boolean existsByKey(String key);
    @Modifying(clearAutomatically = true)
    @Query("update LeafAlloc l set l.maxId = l.maxId + :step  where l.key = :key")
    int updateMaxIdByCustomStep(@Param("key")String key, @Param("step")Long step);
    @Query("select l.key  from LeafAlloc l where l.deleteFlag = :deleteFlag")
    List<String> findAllKey(@Param("deleteFlag")Integer deleteFlag);

    @Query("select l.key from LeafAlloc l where l.key LIKE :keyValueLike  AND LENGTH(l.key) = :keyValueLength AND l.deleteFlag = :deleteFlag AND l.key < :keyValue")
    List<String> findAllExpireKey(@Param("keyValueLike") String keyValueLike,
                                     @Param("keyValue") String keyValue,
                                     @Param("deleteFlag")Integer deleteFlag,
                                    @Param("keyValueLength")Integer keyValueLength);

    @Query("select l.key from LeafAlloc l where l.key LIKE :keyValueLike AND l.deleteFlag = :deleteFlag AND l.updateTime < :updateTime ")
    List<String> findYHExpireKey(@Param("keyValueLike") String keyValueLike,
                                  @Param("updateTime") LocalDateTime localDateTime,
                                  @Param("deleteFlag")Integer deleteFlag);
}
