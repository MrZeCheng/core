package com.yhglobal.scp.sequence.id.repository;

import com.yhglobal.scp.sequence.id.entity.LeafSnowflake;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LeafSnowflakeRepository extends JpaRepository<LeafSnowflake, Long> {
    Optional<LeafSnowflake> findByHostAddress(String hostAddress);
}
