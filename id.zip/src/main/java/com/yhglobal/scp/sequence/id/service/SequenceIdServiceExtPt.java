package com.yhglobal.scp.sequence.id.service;

import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.extension.ExtensionPointI;
import com.yhglobal.scp.sequence.id.client.SequenceIdCmd;

public interface SequenceIdServiceExtPt extends ExtensionPointI {

    public SingleResponse<String> get(String key, String idType, String dateKey);

    MultiResponse<String> getBatchNumber(String key, String idType, SequenceIdCmd sequenceIdCmd);

    public boolean init();

    public SingleResponse<String> processingId(SingleResponse<String> singleResponse, String key, String prefix, String suffix, Integer maxLength, Integer totalLength);
}
