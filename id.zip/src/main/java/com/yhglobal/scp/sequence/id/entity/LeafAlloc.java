package com.yhglobal.scp.sequence.id.entity;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Accessors(chain = true)
@Table(name="yh_leaf_segment_id",uniqueConstraints ={@UniqueConstraint(columnNames ="keyValue")})
@EntityListeners(AuditingEntityListener.class)
public class LeafAlloc {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id")
    Long id;

    @Column(name="keyValue",columnDefinition="varchar(256) BINARY COMMENT '主键Id'")
    String key;

    @Column(name = "maxId",columnDefinition="bigint(20) COMMENT '最大id'")
    Long maxId;

    @Column(name = "step",columnDefinition="int(11) COMMENT '号段'")
    Integer step;

    @LastModifiedDate
    @Column(name = "updateTime",columnDefinition = "datetime COMMENT '更新时间'")
    LocalDateTime updateTime;

    @Column(name = "deleteFlag",columnDefinition="int(11) COMMENT '是否删除'")
    Integer deleteFlag;

}
