package com.yhglobal.scp.sequence.id.service.impl;

import com.yhglobal.bee.common.exception.BusinessException;
import com.yhglobal.bee.common.util.DateUtil;
import com.yhglobal.bee.common.util.constant.DeleteFlagEnum;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.scp.sequence.id.dao.LeafAllocDao;
import com.yhglobal.scp.sequence.id.dao.LeafAllocTypeDao;
import com.yhglobal.scp.sequence.id.entity.LeafAlloc;
import com.yhglobal.scp.sequence.id.entity.LeafAllocType;
import com.yhglobal.scp.sequence.id.service.LeafAllocService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class LeafAllocServiceImpl implements LeafAllocService {

    private final LeafAllocDao leafAllocDao;

    private final LeafAllocTypeDao leafAllocTypeDao;

    @Override
    public List<String> findAllId() {
        return leafAllocDao.findAllId(0);
    }

    @Override
    @Transactional
    public LeafAlloc updateMaxIdAndGetLeafAlloc(String id) {
        leafAllocDao.updateMaxId(id);
        return leafAllocDao.findByKey(id).orElseThrow(()->new BusinessException(ErrorCode.DATA_ABNORMAL));
    }

    @Override
    @Transactional
    public LeafAlloc updateMaxIdByCustomStepAndGetLeafAlloc(String id, Integer step) {
        leafAllocDao.updateMaxIdByCustomStep(id,step);
        return leafAllocDao.findByKey(id).orElseThrow(()->new BusinessException(ErrorCode.DATA_ABNORMAL));
    }

    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public void initBiz(Map<String, LeafAllocType> map) {
        List<LeafAllocType> leafAllocTypes = leafAllocTypeDao.findAll();
        if (leafAllocTypes != null && !leafAllocTypes.isEmpty()) {
            Date date = new Date();
            Date addOneDate = DateUtil.addDay(date,1);
            leafAllocTypes.forEach( leafAllocType -> {
                map.put(leafAllocType.getIdType(), leafAllocType);
                saveData(date, leafAllocType);
                saveData(addOneDate, leafAllocType);
            });
        }
    }

    private void saveData(Date date, LeafAllocType leafAllocType){
        String key;
        if ("YH".equals(leafAllocType.getTimeFormat())) {
            key = leafAllocType.getPrefix() + "-YH";
        }else {
            key = leafAllocType.getPrefix() + "-" + DateUtil.date2str(date, leafAllocType.getTimeFormat());
        }
        if(!leafAllocDao.existsByKey(key)){
            try {
                LeafAlloc leafAlloc = new LeafAlloc();
                leafAlloc.setKey(key);
                leafAlloc.setMaxId(0L);
                leafAlloc.setStep(leafAllocType.getStep());
                leafAlloc.setDeleteFlag(0);
                leafAllocDao.save(leafAlloc);
            }catch (RuntimeException e){
                log.error("sql error message = {}",e.getMessage());
            }
        }

    }

    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public void deleteAndAdd() {
        Date date = new Date();
        List<LeafAllocType> leafAllocTypes = leafAllocTypeDao.findAll();
        if (leafAllocTypes != null && !leafAllocTypes.isEmpty()) {
            Date addOneDate = DateUtil.addDay(date,1);
            leafAllocTypes.forEach( leafAllocType -> {
                saveData(addOneDate, leafAllocType);
            });
            Date deductOneDate = DateUtil.addDay(date,-1);
            Date deductOneMonthDate = DateUtil.addMonth(date,-1);
            leafAllocTypes.forEach( leafAllocType -> {
                if (leafAllocType.getTimeFormat().contains("dd")) {
                    String key = leafAllocType.getPrefix() + "-" + DateUtil.date2str(deductOneDate, leafAllocType.getTimeFormat());
                    delete(key);
                    List<String> leafAllocs = leafAllocDao.findAllExpireKey(leafAllocType.getPrefix() + "-%", key, DeleteFlagEnum.EXITS.getStatus(), key.length());
                    // 检查历史删除
                    if (!leafAllocs.isEmpty()) {
                        leafAllocs.forEach(this::delete);
                    }
                }else if (leafAllocType.getTimeFormat().contains("MM")) {
                    String key = leafAllocType.getPrefix() + "-" + DateUtil.date2str(deductOneMonthDate, leafAllocType.getTimeFormat());
                    delete(key);
                    // 检查历史删除
                    List<String> leafAllocs = leafAllocDao.findAllExpireKey(leafAllocType.getPrefix() + "-%", key, DeleteFlagEnum.EXITS.getStatus(), key.length());
                    if (!leafAllocs.isEmpty()) {
                        leafAllocs.forEach(this::delete);
                    }
                }
            });

            // 删除一个月没更新的常量key
            List<String> list = leafAllocDao.findYHExpireKey("%-YH%", LocalDateTime.now().plusMonths(-1), DeleteFlagEnum.EXITS.getStatus());
            if (!list.isEmpty()) {
                list.forEach(this::delete);
            }
        }
    }

    private void delete(String key){
        Optional<LeafAlloc> leafAlloc = leafAllocDao.findByKey(key);
        if (leafAlloc.isPresent()) {
            LeafAlloc leafAlloc1 = leafAlloc.get();
            if (DeleteFlagEnum.EXITS.getStatus().equals(leafAlloc1.getDeleteFlag())) {
                leafAlloc1.setDeleteFlag(DeleteFlagEnum.DELETE.getStatus());
                leafAllocDao.save(leafAlloc1);
            }
        }
    }



    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public void initBizIdType(Map<String, LeafAllocType> map, String idType) {
        log.info("initBizIdType = {}",idType);
        LeafAllocType leafAllocType = new LeafAllocType();
        leafAllocType.setIdType(idType);
        leafAllocType.setStep(1000);
        leafAllocType.setMaxLength(8);
        int firstIndex = idType.indexOf("-");
        leafAllocType.setPrefix(idType.substring(0,firstIndex));
        leafAllocType.setTimeFormat(idType.substring(firstIndex + 1));
        map.put(idType,leafAllocType);
        try {
            if(!leafAllocTypeDao.existsByIdType(idType)){
                leafAllocTypeDao.save(leafAllocType);
                Date nowDate = new Date();
                Date lastDate = DateUtil.addDay(nowDate, 1);
                List<LeafAlloc> leafAllocs = new ArrayList<>(2);

                LeafAlloc leafAlloc = new LeafAlloc();
                leafAlloc.setKey(leafAllocType.getPrefix() + "-" + ("YH".equals(leafAllocType.getTimeFormat()) ? "YH" : DateUtil.date2str(nowDate,leafAllocType.getTimeFormat())));
                leafAlloc.setMaxId(0L);
                leafAlloc.setStep(leafAllocType.getStep());
                leafAlloc.setDeleteFlag(0);

                LeafAlloc leafAlloc1 = new LeafAlloc();
                leafAlloc1.setKey(leafAllocType.getPrefix() + "-" + ("YH".equals(leafAllocType.getTimeFormat()) ? "YH" : DateUtil.date2str(lastDate,leafAllocType.getTimeFormat())));
                leafAlloc1.setMaxId(0L);
                leafAlloc1.setStep(leafAllocType.getStep());
                leafAlloc1.setDeleteFlag(0);
                leafAllocs.add(leafAlloc);
                if (!leafAlloc1.getKey().equals(leafAlloc.getKey())) {
                    leafAllocs.add(leafAlloc1);
                }
                leafAllocDao.saveAll(leafAllocs);
            }
        }catch (RuntimeException e){
            log.error("sql error message = {}",e.getMessage());
        }
    }

    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public void initBizIdBeforeAndType(Map<String, LeafAllocType> map, String idType, String dateKey) {
        log.info("initBizIdBeforeAndType  idType = {}, dateKey = {}", idType, dateKey);
        LeafAllocType leafAllocType = new LeafAllocType();
        leafAllocType.setIdType(idType);
        leafAllocType.setStep(1000);
        leafAllocType.setMaxLength(8);
        int firstIndex = idType.indexOf("-");
        leafAllocType.setPrefix(idType.substring(0,firstIndex));
        leafAllocType.setTimeFormat(idType.substring(firstIndex + 1));
        map.put(idType,leafAllocType);
        try {
            if(!leafAllocTypeDao.existsByIdType(idType)){
                leafAllocTypeDao.save(leafAllocType);
                Date nowDate = new Date();
                Date lastDate = DateUtil.addDay(nowDate, 1);
                List<LeafAlloc> leafAllocs = new ArrayList<>(2);

                LeafAlloc leafAlloc = new LeafAlloc();
                leafAlloc.setKey(leafAllocType.getPrefix() + "-" + ("YH".equals(leafAllocType.getTimeFormat()) ? "YH" : DateUtil.date2str(nowDate,leafAllocType.getTimeFormat())));
                leafAlloc.setMaxId(0L);
                leafAlloc.setStep(leafAllocType.getStep());
                leafAlloc.setDeleteFlag(0);
                leafAllocs.add(leafAlloc);

                LeafAlloc leafAlloc1 = new LeafAlloc();
                leafAlloc1.setKey(leafAllocType.getPrefix() + "-" + ("YH".equals(leafAllocType.getTimeFormat()) ? "YH" : DateUtil.date2str(lastDate,leafAllocType.getTimeFormat())));
                leafAlloc1.setMaxId(0L);
                leafAlloc1.setStep(leafAllocType.getStep());
                leafAlloc1.setDeleteFlag(0);
                if (!leafAlloc1.getKey().equals(leafAlloc.getKey())) {
                    leafAllocs.add(leafAlloc1);
                }
                // 注入历史日期的逻辑
                String key = leafAllocType.getPrefix() + "-" +dateKey;
                Optional<LeafAlloc> leafAlloc2 = leafAllocDao.findByKey(key);
                if (leafAlloc2.isEmpty()) {
                    LeafAlloc leafAlloc3 = new LeafAlloc();
                    leafAlloc3.setKey(key);
                    leafAlloc3.setMaxId(0L);
                    leafAlloc3.setStep(leafAllocType.getStep());
                    leafAlloc3.setDeleteFlag(0);
                    if (!leafAlloc3.getKey().equals(leafAlloc.getKey())) {
                        leafAllocs.add(leafAlloc3);
                    }
                }else {
                    LeafAlloc leafAlloc3 = leafAlloc2.get();
                    leafAlloc3.setDeleteFlag(DeleteFlagEnum.EXITS.getStatus());
                    leafAllocDao.save(leafAlloc3);
                }
                leafAllocDao.saveAll(leafAllocs);
            }
        }catch (RuntimeException e){
            log.error("sql error message = {}",e.getMessage());
        }
    }

    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public void initBizIdBeforeType(String key) {
        log.info("initBizIdBeforeType  key = {}", key);
        Optional<LeafAlloc> leafAlloc = leafAllocDao.findByKey(key);
        if (leafAlloc.isEmpty()) {
            LeafAlloc leafAllocSave = new LeafAlloc();
            leafAllocSave.setKey(key);
            leafAllocSave.setMaxId(0L);
            leafAllocSave.setStep(1000);
            leafAllocSave.setDeleteFlag(0);
            try {
                leafAllocDao.save(leafAllocSave);
            }catch (RuntimeException e){
                log.error("sql error message = {}",e.getMessage());
            }
        }else {
            LeafAlloc leafAllocUpdate = leafAlloc.get();
            leafAllocUpdate.setDeleteFlag(DeleteFlagEnum.EXITS.getStatus());
            leafAllocDao.save(leafAllocUpdate);
        }
    }



}

