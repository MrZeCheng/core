package com.yhglobal.scp.sequence.id.model;

import com.yhglobal.bee.common.dto.SingleResponse;

public class SingleIdResponse<T> extends SingleResponse<T> {

    private String number;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public SingleIdResponse() {
    }

    public static <T> SingleIdResponse<T> of(T data,String number) {
        SingleIdResponse<T> response = new SingleIdResponse<>();
        response.setSuccess(data != null);
        response.setSuccessMessage("success!");
        response.setData(data);
        if (data == null) {
            response.setErrCode("A00101");
            response.setErrMessage("Data is null!");
        }
        response.setNumber(number);
        return response;
    }

}
