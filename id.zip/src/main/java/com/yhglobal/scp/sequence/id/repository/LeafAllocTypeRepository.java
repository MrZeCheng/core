package com.yhglobal.scp.sequence.id.repository;

import com.yhglobal.scp.sequence.id.entity.LeafAllocType;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 * 相关接口
 *
 * @author weizecheng
 * @date 2021/3/15 17:18
 */
public interface LeafAllocTypeRepository extends JpaRepository<LeafAllocType, Long> {
    boolean existsByIdType(String idType);
}
