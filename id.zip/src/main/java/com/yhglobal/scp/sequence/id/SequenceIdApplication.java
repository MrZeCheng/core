package com.yhglobal.scp.sequence.id;

import com.alibaba.nacos.spring.context.annotation.config.EnableNacosConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableJpaAuditing
@ComponentScan(value = "com.yhglobal")
@EnableTransactionManagement
@EnableScheduling
@EnableNacosConfig
public class SequenceIdApplication {

    public static void main(String[] args) {
        SpringApplication.run(SequenceIdApplication.class, args);
    }
    
}
