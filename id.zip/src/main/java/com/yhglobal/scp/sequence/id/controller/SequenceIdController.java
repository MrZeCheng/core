package com.yhglobal.scp.sequence.id.controller;


import com.yhglobal.bee.common.constant.sequence.id.SequenceIdTypeEnum;
import com.yhglobal.bee.common.dto.MultiResponse;
import com.yhglobal.bee.common.dto.SingleResponse;
import com.yhglobal.bee.common.util.constant.ErrorCode;
import com.yhglobal.scp.sequence.id.client.SequenceIdCmd;
import com.yhglobal.scp.sequence.id.domain.SequenceIdDomain;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 有学Id Api
 *
 * @author weizecheng
 * @Date 2022/9/6 14:42
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("sequence/id")
public class SequenceIdController {

    private final SequenceIdDomain sequenceIdDomain;

    /**
     * 获取单个单号
     *
     * @author zecheng.wei
     * @Date 2022/12/29 10:18
     */
    @GetMapping("segment")
    public SingleResponse<String> getSegmentPrefix(String key,
                                                   @RequestParam(defaultValue = "YH") String dateFormat,
                                                   String prefix,
                                                   String suffix,
                                                   @RequestParam(defaultValue = "8") Integer maxLength,
                                                   @RequestParam(defaultValue = "0") Integer totalLength,
                                                   @RequestParam(defaultValue = "false") Boolean overflow,
                                                   String dateKey) {
        if (key == null) {
            return SingleResponse.ofFailure(ErrorCode.DATA_ABNORMAL.getCode(),"key为空");
        }
        SequenceIdCmd sequenceIdCmd = new SequenceIdCmd();
        sequenceIdCmd.setSequenceIdTypeEnum(SequenceIdTypeEnum.SEGMENT);
        sequenceIdCmd.setTimeFormat(dateFormat);
        sequenceIdCmd.setKey(key.replaceAll("-","_"));
        sequenceIdCmd.setPrefix(prefix);
        sequenceIdCmd.setSuffix(suffix);
        sequenceIdCmd.setMaxLength(maxLength);
        sequenceIdCmd.setTotalLength(totalLength);
        sequenceIdCmd.setDateKey(dateKey);
        return sequenceIdDomain.getSequenceId(sequenceIdCmd,overflow);
    }

    /**
     * xps 获取单号
     *
     * @author zecheng.wei
     * @Date 2022/12/29 10:19
     */
    @GetMapping("xps/segment")
    public SingleResponse<String> getXpsSegmentPrefix(String key,
                                                      String dateFormat,
                                                      String prefix,
                                                      String suffix,
                                                      String dateKey) {
        if (key == null || dateFormat == null) {
            return SingleResponse.ofFailure(ErrorCode.DATA_ABNORMAL.getCode(),"key 或 dateFormat 为空");
        }
        SequenceIdCmd sequenceIdCmd = new SequenceIdCmd();
        sequenceIdCmd.setSequenceIdTypeEnum(SequenceIdTypeEnum.SEGMENT);
        sequenceIdCmd.setTimeFormat(dateFormat);
        sequenceIdCmd.setKey(key);
        sequenceIdCmd.setPrefix(prefix);
        sequenceIdCmd.setSuffix(suffix);
        sequenceIdCmd.setMaxLength(8);
        sequenceIdCmd.setTotalLength(0);
        sequenceIdCmd.setDateKey(dateKey);
        return sequenceIdDomain.getSequenceXpsId(sequenceIdCmd);
    }

    /**
     * 批量获取单号
     *
     * @author zecheng.wei
     * @Date 2022/12/29 10:19
     */
    @GetMapping("segment/batch")
    public MultiResponse<String> getSegmentBatch(String key,
                                                 @RequestParam(defaultValue = "YH") String dateFormat,
                                                 String prefix,
                                                 String suffix,
                                                 Long batchNumber,
                                                 @RequestParam(defaultValue = "8") Integer maxLength,
                                                 @RequestParam(defaultValue = "0") Integer totalLength) {
        if (key == null || batchNumber == null) {
            return MultiResponse.buildFailure(ErrorCode.DATA_ABNORMAL.getCode(),"key 或 batchNumber 为空");
        }
        SequenceIdCmd sequenceIdCmd = new SequenceIdCmd();
        sequenceIdCmd.setSequenceIdTypeEnum(SequenceIdTypeEnum.SEGMENT);
        sequenceIdCmd.setTimeFormat(dateFormat);
        sequenceIdCmd.setKey(key.replaceAll("-","_"));
        sequenceIdCmd.setPrefix(prefix);
        sequenceIdCmd.setSuffix(suffix);
        sequenceIdCmd.setBatchNumber(batchNumber);
        sequenceIdCmd.setMaxLength(maxLength);
        sequenceIdCmd.setTotalLength(totalLength);
        return sequenceIdDomain.getSequenceIdBatchNumber(sequenceIdCmd);
    }

    /**
     * 获取雪花Id
     *
     * @author zecheng.wei
     * @Date 2022/12/29 10:20
     */
    @GetMapping("snowflake")
    public SingleResponse<String> getSnowflake() {
        SequenceIdCmd sequenceIdCmd = new SequenceIdCmd();
        sequenceIdCmd.setSequenceIdTypeEnum(SequenceIdTypeEnum.SNOWFLAKE);
        sequenceIdCmd.setTimeFormat("YH");
        sequenceIdCmd.setKey("YH");
        sequenceIdCmd.setPrefix("");
        sequenceIdCmd.setSuffix("");
        sequenceIdCmd.setMaxLength(8);
        sequenceIdCmd.setTotalLength(0);
        return sequenceIdDomain.getSequenceId(sequenceIdCmd,false);
    }

}
