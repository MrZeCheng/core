package com.yhglobal.scp.sequence.id.dao;

import com.yhglobal.scp.sequence.id.entity.LeafAllocType;
import com.yhglobal.scp.sequence.id.repository.LeafAllocTypeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class LeafAllocTypeDao {

    private final LeafAllocTypeRepository leafAllocTypeRepository;

    public List<LeafAllocType> findAll(){
        return leafAllocTypeRepository.findAll();
    }

    public void save(LeafAllocType leafAllocType){
        leafAllocTypeRepository.save(leafAllocType);
    }

    public boolean existsByIdType(String idType){
        return leafAllocTypeRepository.existsByIdType(idType);
    }

}
