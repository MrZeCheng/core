package com.yhglobal.scp.sequence.id.service.impl;

import com.yhglobal.scp.sequence.id.dao.LeafSnowflakeDao;
import com.yhglobal.scp.sequence.id.entity.LeafSnowflake;
import com.yhglobal.scp.sequence.id.service.LeafSnowflakeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.InetAddress;

/**
 * 雪花算法获取机器Id
 *
 * @author weizecheng
 * @date 2021/3/16 15:53
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class LeafSnowflakeServiceImpl implements LeafSnowflakeService {

    private final LeafSnowflakeDao leafSnowflakeDao;

    @Override
    public long getServerIdAsLong() {
        try {
            String ip = InetAddress.getLocalHost().getHostAddress();
            long id = leafSnowflakeDao.findByHostAddress(ip)
                    .orElseGet(()->leafSnowflakeDao.save(new LeafSnowflake().setHostAddress(ip)))
                    .getId();
            // 除以1024的余数
            return id % 1024;
        }catch (Exception e){
            log.warn("unable to get host name. set server id = 0.");
        }
        return 0L;
    }
}
