# id 生成服务 只依赖mysql 表自动生成

## 单个获取单号
### 1.1 功能描述
    单个获取单号
### 1.2 请求说明
> 请求方式：GET  <br>
请求URL ：[/sequence/id/segment](#)
### 1.3 参数
字段       |字段类型       | 是否必填|字段说明
------------|-----------|------|-----
key |String|<font color="red">是</font>|关键字
dateFormat |String|<font color="red">是</font>|时间格式 yyyyMMdd,yyMMdd等等
prefix |String|否| 单号前缀
suffix |String|否| 单号后缀

### 1.4 返回结果
```json
{
	"success": true,
	"errCode": null,
	"errMessage": null,
	"successMessage": "success!",
	"data": "AO2022010400002000"
}
```


## 批量获取单号
### 2.1 功能描述
    批量获取单号
### 2.2 请求说明
> 请求方式：GET  <br>
请求URL ：[/sequence/id/segment/batch](#)
### 2.3 参数
字段       |字段类型       | 是否必填|字段说明
------------|-----------|------|-----
key |String|<font color="red">是</font>|关键字
dateFormat |String|<font color="red">是</font>|时间格式 yyyyMMdd,yyMMdd等等
batchNumber |Long|<font color="red">是</font>| 获取数量
prefix |String|否| 单号前缀
suffix |String|否| 单号后缀

### 2.4 返回结果
```json
{
	"success": true,
	"errCode": null,
	"errMessage": null,
	"successMessage": "success!",
	"data": ["AO2022010400000020", "AO2022010400000067"],
	"empty": false,
	"notEmpty": true
}
```


## 获取雪花单号
### 3.1 功能描述
    获取雪花单号
### 3.2 请求说明
> 请求方式：GET  <br>
请求URL ：[/sequence/id/snowflake](#)

### 3.3 返回结果
```json
{
	"success": true,
	"errCode": null,
	"errMessage": null,
	"successMessage": "success!",
	"data": "1456672430096417"
}
```

## 单个获取单号
### 4.1 功能描述
    单个获取单号
### 4.2 请求说明
> 请求方式：GET  <br>
请求URL ：[/sequence/id/xps/segment](#)
### 4.3 参数
字段       |字段类型       | 是否必填|字段说明
------------|-----------|------|-----
key |String|<font color="red">是</font>|关键字
dateFormat |String|<font color="red">是</font>|时间格式 yyyyMMdd,yyMMdd等等
prefix |String|否| 单号前缀
suffix |String|否| 单号后缀

### 4.4 返回结果
```json
{
  "success": true,
  "errCode": null,
  "errMessage": null,
  "successMessage": "success!",
  "data": "PHFX_PUR220328000022"
}
```


